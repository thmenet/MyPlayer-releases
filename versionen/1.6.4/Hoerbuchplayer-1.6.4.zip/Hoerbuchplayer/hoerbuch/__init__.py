VERSION = "1.6.4"
APP_NAME = "MyPlayer"
