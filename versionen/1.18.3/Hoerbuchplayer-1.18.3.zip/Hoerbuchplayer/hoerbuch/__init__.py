VERSION = "1.18.3"
APP_NAME = "MyPlayer"
