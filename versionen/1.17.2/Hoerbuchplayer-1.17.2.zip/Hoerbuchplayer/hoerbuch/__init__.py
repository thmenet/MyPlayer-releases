VERSION = "1.17.2"
APP_NAME = "MyPlayer"
