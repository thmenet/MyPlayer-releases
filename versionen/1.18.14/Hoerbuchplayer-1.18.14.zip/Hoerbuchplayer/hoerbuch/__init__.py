VERSION = "1.18.14"
APP_NAME = "MyPlayer"
