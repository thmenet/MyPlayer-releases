VERSION = "1.18.12"
APP_NAME = "MyPlayer"
