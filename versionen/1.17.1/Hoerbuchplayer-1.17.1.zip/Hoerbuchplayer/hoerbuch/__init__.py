VERSION = "1.17.1"
APP_NAME = "MyPlayer"
