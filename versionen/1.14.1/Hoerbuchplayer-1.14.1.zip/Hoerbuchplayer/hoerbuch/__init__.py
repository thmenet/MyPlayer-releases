VERSION = "1.14.1"
APP_NAME = "MyPlayer"
