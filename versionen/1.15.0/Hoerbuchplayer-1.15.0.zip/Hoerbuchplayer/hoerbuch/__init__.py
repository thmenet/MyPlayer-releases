VERSION = "1.15.0"
APP_NAME = "MyPlayer"
