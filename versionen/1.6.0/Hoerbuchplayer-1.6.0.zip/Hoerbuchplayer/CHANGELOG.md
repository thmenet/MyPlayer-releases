# Änderungen MyPlayer (PC)

## 1.6.0
- **Musik (Apple Music):** In den Einstellungen «Musik anzeigen» einschalten – dann gibt es oben den Bereich «Musik». Einmal mit der Apple-ID anmelden (Apple-Music-Abo nötig), danach: zuletzt Gehörtes, eigene Playlists und Suche in ganz Apple Music. Braucht die Verbindung zu player.menet.ch.
- Musik und Hörbuch laufen nie gleichzeitig: Startet das eine, hält das andere an.

## 1.5.0
- **Neuer Name: MyPlayer.** Fenster, Startmenü, Desktop-Verknüpfung und «Öffnen mit» heissen jetzt «MyPlayer». Die Verknüpfungen werden beim Update selbst umbenannt.
- **Handy-Bedienung auch hier:** Auf Touch-Bildschirmen öffnet Antippen den Titel, lange drücken wählt aus.

## 1.4.3
- **Verbinden mit player.menet.ch, solange green.ch das richtige Zertifikat noch nicht eingespielt hat:** Der Player akzeptiert vorübergehend nur für player.menet.ch das Zertifikat von green.ch («*.servicehoster.ch»). Die Echtheit wird weiterhin geprüft. In den Einstellungen steht dann ein Hinweis; sobald das richtige Zertifikat da ist, wird wieder normal geprüft.

## 1.4.2
- **Verbinden mit player.menet.ch klappt auch, wenn Windows das neue Sicherheitszertifikat noch nicht kennt** (zusätzliche Zertifikatsliste «certifi»).
- Bei Verbindungsproblemen steht jetzt der genaue Grund in der Meldung.

## 1.4.1
- **Verständliche Fehlermeldungen** beim Verbinden mit player.menet.ch (statt nur einer Nummer wie «400»).

## 1.4.0
- **Verbindung zu player.menet.ch:** In den Einstellungen mit einem Code verbinden (Code auf player.menet.ch → Geräte).
- **Hochladen fürs Handy:** Rechtsklick auf einen oder mehrere Titel → «Auf player.menet.ch hochladen». Läuft im Hintergrund, setzt nach einem Abbruch fort.
- **Gemeinsamer Hörstand:** Position, Lesezeichen, Favoriten und Archiv werden mit player.menet.ch abgeglichen – am PC geht es dort weiter, wo du im Auto aufgehört hast.
- Titel auf dem Server tragen ein Wolken-Zeichen.

## 1.3.0
- **Automatische Updates:** Der Player schaut beim Start auf GitHub nach einer neuen Version und kann sich mit einem Klick selbst aktualisieren. Danach geht es an derselben Stelle weiter.
- In den Einstellungen: **Nach Updates suchen**.

## 1.2.0
- **Mehrfachauswahl:** mehrere Titel auf einmal als Podcast/Hörbuch markieren, zu Favoriten, ins Archiv.
- **Installation** mit Eintrag im Startmenü (`installieren.bat`) und eigener `Hoerbuchplayer.exe`.
- **Standard-Player für .m4b:** Doppelklick auf eine .m4b-Datei öffnet sie im Player.

## 1.1.0
- Podcasts nach Sendung gruppiert und **auf-/zuklappbar**, Knopf «Weiterhören».
- Folgen nach Folgennummer sortiert.

## 1.0.0
- Erste Version: Bibliothek, Player mit Kapiteln, Lesezeichen, Favoriten, Archiv, Schlaf-Timer.
