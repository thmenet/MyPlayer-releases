VERSION = "1.18.11"
APP_NAME = "MyPlayer"
