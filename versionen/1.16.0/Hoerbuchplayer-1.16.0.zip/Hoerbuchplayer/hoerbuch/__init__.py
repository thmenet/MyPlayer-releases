VERSION = "1.16.0"
APP_NAME = "MyPlayer"
