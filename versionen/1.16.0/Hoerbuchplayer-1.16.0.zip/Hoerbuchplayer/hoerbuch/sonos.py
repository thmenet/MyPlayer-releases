"""Sonos: Hörbücher und «Meine Musik» vom Heimserver auf Sonos-Boxen abspielen.

Sonos-Boxen lassen sich im Heimnetz über ihre eingebaute Schnittstelle (UPnP/SOAP, Port 1400) steuern.
Die Box holt den Ton selbst vom Heimserver (http://<server>:48219/media/… bzw. /musik/datei/…) – Handy oder PC sind nur Fernbedienung.

- Finden: Rundruf im Heimnetz (SSDP) oder fest eingetragene Adressen (Einstellung sonos_hosts), dann von einer Box die Raum-Übersicht
  (ZoneGroupState): Räume/Gruppen mit «Chef»-Box (Coordinator). Fest verbundene Geräte (Sub, Rücklautsprecher) erscheinen nicht einzeln.
- Eine Sitzung je Profil: Liste von Dateien (Hörbuch = seine Dateien, Musik = gewählte Titel), aktueller Titel, Stelle.
  Ein Hintergrund-Faden fragt jede Sekunde den Stand ab, startet nach dem Ende eines Titels den nächsten und speichert beim Hörbuch den Hörstand.
- Übernimmt jemand die Box mit der Sonos-App (anderer Inhalt), endet die Sitzung still.
"""
import html
import logging
import re
import socket
import threading
import time
import urllib.error
import urllib.request

log = logging.getLogger("sonos")

SSDP_ADDR = ("239.255.255.250", 1900)
AVT = ("/MediaRenderer/AVTransport/Control", "urn:schemas-upnp-org:service:AVTransport:1")
GRC = ("/MediaRenderer/GroupRenderingControl/Control", "urn:schemas-upnp-org:service:GroupRenderingControl:1")
ZGT = ("/ZoneGroupTopology/Control", "urn:schemas-upnp-org:service:ZoneGroupTopology:1")
# ohne Proxy: die Boxen sind immer direkt im Heimnetz
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class SonosError(Exception):
    pass


def _hostport(h):
    h = str(h).strip()
    if not h:
        return None
    return h if ":" in h else f"{h}:1400"


def soap(host, service, action, args=None, timeout=4):
    """Einen Befehl an eine Box schicken. Gibt die Antwort als Wörterbuch (einfache Felder) zurück."""
    path, urn = service
    body = "".join(f"<{k}>{html.escape(str(v), quote=False)}</{k}>" for k, v in (args or {}).items())
    env = ('<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
           's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
           f'<u:{action} xmlns:u="{urn}">{body}</u:{action}></s:Body></s:Envelope>')
    req = urllib.request.Request(f"http://{_hostport(host)}{path}", data=env.encode("utf-8"), method="POST", headers={
        "Content-Type": 'text/xml; charset="utf-8"', "SOAPACTION": f'"{urn}#{action}"'})
    try:
        with _OPENER.open(req, timeout=timeout) as r:
            text = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        code = re.search(r"<errorCode>(\d+)</errorCode>", detail)
        raise SonosError(f"Sonos lehnt «{action}» ab (Fehler {code.group(1) if code else e.code})") from e
    except OSError as e:
        raise SonosError(f"Sonos-Box {host} antwortet nicht ({e})") from e
    out = {}
    for m in re.finditer(r"<([A-Za-z]+)>(.*?)</\1>", text, re.S):
        out[m.group(1)] = html.unescape(m.group(2))
    return out


def ssdp_hosts(timeout=2.0):
    """Sonos-Boxen per Rundruf im Heimnetz finden (IP-Adressen)."""
    msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\n"
           "ST: urn:schemas-upnp-org:device:ZonePlayer:1\r\n\r\n").encode()
    found = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        s.settimeout(0.3)
        for _ in range(2):
            s.sendto(msg, SSDP_ADDR)
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, addr = s.recvfrom(4096)
            except socket.timeout:
                continue
            if b"Sonos" in data or b"ZonePlayer" in data:
                found.add(addr[0])
        s.close()
    except OSError as e:
        log.info("Rundruf im Heimnetz nicht möglich: %s", e)
    return sorted(found)


def parse_groups(xml):
    """Räume/Gruppen aus dem ZoneGroupState einer Box."""
    groups = []
    for g in re.finditer(r"<ZoneGroup\b([^>]*)>(.*?)</ZoneGroup>", xml, re.S):
        coord = re.search(r'Coordinator="([^"]+)"', g.group(1))
        members = []
        for m in re.finditer(r"<ZoneGroupMember\b([^>]*?)/?>", g.group(2)):
            a = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
            if a.get("Invisible") == "1":          # fest verbundener Sub / Rücklautsprecher
                continue
            loc = re.search(r"//([^/]+)/", a.get("Location", ""))
            members.append({"uuid": a.get("UUID"), "name": html.unescape(a.get("ZoneName", "?")), "host": loc.group(1) if loc else None})
        if not members or not coord:
            continue
        c = next((m for m in members if m["uuid"] == coord.group(1)), None)
        if not c or not c["host"]:
            continue
        others = [m["name"] for m in members if m is not c]
        groups.append({"id": coord.group(1), "name": c["name"] + (" + " + " + ".join(others) if others else ""), "host": c["host"],
                       "rooms": [c["name"]] + others, "members": [c] + [m for m in members if m is not c]})
    groups.sort(key=lambda g: g["name"].lower())
    return groups


def _hms(sec):
    sec = max(0, int(sec))
    return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


def _sec(hms):
    try:
        h, m, s = (hms or "0:00:00").split(":")
        return int(h) * 3600 + int(m) * 60 + float(s)
    except ValueError:
        return 0.0


def didl(url, mime, title, artist="", album="", cover=""):
    x = lambda s: html.escape(str(s or ""), quote=True)
    return ('<DIDL-Lite xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/" '
            'xmlns:r="urn:schemas-rinconnetworks-com:metadata-1-0/" xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/">'
            f'<item id="myplayer" parentID="0" restricted="1"><dc:title>{x(title)}</dc:title><dc:creator>{x(artist)}</dc:creator>'
            f'<upnp:album>{x(album)}</upnp:album>' + (f'<upnp:albumArtURI>{x(cover)}</upnp:albumArtURI>' if cover else '') +
            f'<upnp:class>object.item.audioItem.musicTrack</upnp:class><res protocolInfo="http-get:*:{x(mime)}:*">{x(url)}</res></item></DIDL-Lite>')


class Sonos:
    def __init__(self, app):
        self.app = app
        self.lock = threading.RLock()
        self.sessions = {}          # Profil-ID (oder "") -> Sitzung
        self._groups = (0, [])
        threading.Thread(target=self._watch, daemon=True).start()

    # ---- Boxen finden
    def hosts(self):
        conf = [h for h in (self.app.main_store.settings.get("sonos_hosts") or []) if h]
        return conf + [h for h in ssdp_hosts() if h not in conf]

    def groups(self, fresh=False):
        with self.lock:
            if not fresh and time.time() - self._groups[0] < 30 and self._groups[1]:
                return self._groups[1]
        last_err = None
        for h in self.hosts():
            try:
                r = soap(h, ZGT, "GetZoneGroupState", timeout=3)
                gs = parse_groups(r.get("ZoneGroupState", ""))
                if gs:
                    # eingetragene Adresse mit Port (z. B. für Tests) auf die Gruppen übertragen
                    if ":" in h:
                        for g in gs:
                            if g["host"] and g["host"].split(":")[0] == h.split(":")[0]:
                                g["host"] = h
                    with self.lock:
                        self._groups = (time.time(), gs)
                    return gs
            except SonosError as e:
                last_err = e
        if last_err:
            raise last_err
        return []

    def rooms(self, fresh=False):
        """Alle Räume einzeln (für «mitspielen lassen»), mit der Gruppe, in der sie gerade sind."""
        out = []
        for g in self.groups(fresh):
            for m in g.get("members", []):
                out.append({"id": m["uuid"], "name": m["name"], "host": m["host"], "group": g["id"], "coordinator": m["uuid"] == g["id"]})
        return sorted(out, key=lambda r: r["name"].lower())

    def regroup(self, pid, room_id, join):
        """Einen Raum zur laufenden Wiedergabe dazunehmen (join) oder herausnehmen."""
        with self.lock:
            s = self.sessions.get(pid)
        if not s:
            raise SonosError("Gerade läuft nichts auf Sonos")
        r = next((x for x in self.rooms(fresh=True) if x["id"] == room_id), None)
        if not r or not r["host"]:
            raise SonosError("Diesen Raum finde ich gerade nicht")
        if room_id == s["group"]:
            raise SonosError("Hier spielt die Wiedergabe – diesen Raum kann man nicht herausnehmen (sonst: Lautsprecher wechseln)")
        if join:
            soap(r["host"], AVT, "SetAVTransportURI", {"InstanceID": 0, "CurrentURI": f"x-rincon:{s['group']}", "CurrentURIMetaData": ""})
        else:
            soap(r["host"], AVT, "BecomeCoordinatorOfStandaloneGroup", {"InstanceID": 0})
        time.sleep(0.6)                  # Sonos braucht einen Moment, bis die neue Gruppe gilt
        g = next((x for x in self.groups(fresh=True) if x["id"] == s["group"]), None)
        if g:
            s["group_name"] = g["name"]
        s.pop("volume", None)            # Gruppenlautstärke neu abfragen
        return self.state(pid)

    def server_url(self, box_host):
        """Adresse des Heimservers, wie die Box sie erreicht (eigene IP Richtung Box)."""
        ip = box_host.split(":")[0]
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((ip, 1400))
            own = s.getsockname()[0]
            s.close()
        except OSError:
            own = "127.0.0.1"
        if own.startswith("127.") and not ip.startswith("127."):
            raise SonosError("Die Adresse des Heimservers im Heimnetz ist nicht bekannt")
        return f"http://{own}:{self.app.port}"

    # ---- Sitzung
    def start(self, pid, group_id, kind, **kw):
        g = next((x for x in self.groups() if x["id"] == group_id), None) or next((x for x in self.groups(fresh=True) if x["id"] == group_id), None)
        if not g:
            raise SonosError("Dieser Sonos-Raum ist gerade nicht erreichbar")
        base = self.server_url(g["host"])
        if kind == "book":
            it = self.app.lib.get(kw.get("id"))
            if not it:
                raise SonosError("Titel nicht gefunden")
            cover = f"{base}/cover/{it['cover']}?big=1" if it.get("cover") else ""
            tracks, off = [], 0.0
            for n, t in enumerate(it["tracks"]):
                ext = {"audio/mpeg": "mp3", "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/aac": "aac", "audio/flac": "flac"}.get(t["mime"], "mp3")
                tracks.append({"url": f"{base}/media/{it['id']}/{n}.{ext}", "mime": "audio/mp4" if ext == "m4a" else t["mime"], "start": off,
                               "duration": t.get("duration") or 0, "title": it["title"], "artist": it.get("author") or it.get("show") or "",
                               "album": it["title"], "cover": cover})
                off += t.get("duration") or 0
            pos = float(kw.get("pos") or 0)
            idx = max(0, max((i for i, t in enumerate(tracks) if t["start"] <= pos + 0.01), default=0))
            s = {"kind": "book", "item": it["id"], "title": it["title"], "sub": it.get("author") or it.get("show") or "",
                 "chapters": it.get("chapters") or [], "total": off or it.get("duration") or 0, "cover_ui": f"/cover/{it['cover']}?big=1" if it.get("cover") else ""}
            rel = pos - tracks[idx]["start"]
        elif kind == "jukebox":
            # Jukebox: die Box spielt die gemeinsame Playlist; den nächsten Titel holt der Heimserver bei jedem Titelende
            jb = self.app.jukebox
            tid = jb.current() or jb.advance()
            for _ in range(100):                     # Apple-Music-Titel gehen nicht über Sonos
                if not (tid and tid.startswith("am:")):
                    break
                tid = jb.advance()
            tr = self._music_track(tid, base) if tid else None
            if not tr:
                raise SonosError("Die Jukebox-Playlist ist leer")
            tracks, idx, rel = [tr], 0, float(kw.get("t") or 0)
            s = {"kind": "music", "jukebox": True}
        else:
            tracks = [x for x in (self._music_track(tid, base) for tid in kw.get("ids") or []) if x]
            if not tracks:
                raise SonosError("Keine Titel zum Abspielen")
            idx = max(0, min(int(kw.get("idx") or 0), len(tracks) - 1))
            rel = float(kw.get("t") or 0)
            s = {"kind": "music"}
        s.update({"group": g["id"], "group_name": g["name"], "host": g["host"], "tracks": tracks, "idx": idx, "rel": rel,
                  "state": "TRANSITIONING", "pid": pid, "started": time.time(), "saved": 0, "error": None, "seek_at": 0})
        with self.lock:
            # gleiche Box schon von einer anderen Sitzung belegt? Die übernimmt jetzt diese.
            for k, o in list(self.sessions.items()):
                if o["group"] == g["id"] and k != pid:
                    self.sessions.pop(k, None)
            self.sessions[pid] = s
        self._play_index(s, idx, rel)
        return self.state(pid)

    def _music_track(self, tid, base):
        """Ein Titel aus «Meine Musik» so, wie die Box ihn braucht."""
        from .musik import AUDIO_EXT
        mu = self.app.musik
        t = mu.tracks.get(tid)
        if not t:
            return None
        a = mu.albums.get(t["album"], {})
        ext = t["path"].rsplit(".", 1)[-1].lower()
        return {"url": f"{base}/musik/datei/{tid}.{ext}", "mime": AUDIO_EXT.get("." + ext, "audio/mpeg"), "start": 0,
                "duration": t["duration"], "title": t["title"], "artist": t["artist"], "album": a.get("title", ""),
                "album_id": t["album"], "cover": f"{base}/musik/cover/{t['album']}?gross=1", "id": tid}

    def _jukebox_next(self, s):
        """Jukebox: nächsten Titel aus der gemeinsamen Playlist holen und abspielen. False = Liste leer.
        Apple-Music-Titel kann der Heimserver nicht an Sonos geben (Kopierschutz) – die werden hier übersprungen."""
        tid = self.app.jukebox.advance()
        for _ in range(100):
            if not (tid and tid.startswith("am:")):
                break
            log.info("Sonos-Jukebox: Apple-Music-Titel übersprungen (geht nur auf einem Gerät mit Apple Music)")
            tid = self.app.jukebox.advance()
        base = s["tracks"][s["idx"]]["url"].split("/musik/datei/")[0]
        tr = self._music_track(tid, base) if tid else None
        if not tr:
            return False
        s["tracks"] = s["tracks"][-20:] + [tr]          # nur die letzten paar behalten
        self._play_index(s, len(s["tracks"]) - 1, 0)
        return True

    def _play_index(self, s, idx, rel=0.0):
        t = s["tracks"][idx]
        s["idx"], s["rel"], s["state"] = idx, rel, "TRANSITIONING"
        meta = didl(t["url"], t["mime"], t["title"], t["artist"], t["album"], t["cover"])
        soap(s["host"], AVT, "SetAVTransportURI", {"InstanceID": 0, "CurrentURI": t["url"], "CurrentURIMetaData": meta})
        if rel > 1:
            for _ in range(10):        # die Box braucht einen Moment, bis sie springen kann
                try:
                    soap(s["host"], AVT, "Seek", {"InstanceID": 0, "Unit": "REL_TIME", "Target": _hms(rel)})
                    break
                except SonosError:
                    time.sleep(0.3)
        soap(s["host"], AVT, "Play", {"InstanceID": 0, "Speed": 1})
        s["seek_at"] = time.time()

    def command(self, pid, cmd, value=None):
        with self.lock:
            s = self.sessions.get(pid)
        if not s:
            raise SonosError("Gerade läuft nichts auf Sonos")
        h = s["host"]
        if cmd == "toggle":
            cmd = "pause" if s["state"] in ("PLAYING", "TRANSITIONING") else "play"
        if cmd == "play":
            soap(h, AVT, "Play", {"InstanceID": 0, "Speed": 1})
            s["state"] = "PLAYING"
        elif cmd == "pause":
            soap(h, AVT, "Pause", {"InstanceID": 0})
            s["state"] = "PAUSED_PLAYBACK"
        elif cmd in ("next", "prev"):
            if s["kind"] == "book":       # Hörbuch: Kapitel vor/zurück
                pos = self._pos(s)
                chs = [c["start"] for c in s["chapters"]] or [0]
                if cmd == "next":
                    nxt = [c for c in chs if c > pos + 1]
                    target = nxt[0] if nxt else None
                else:
                    cur = max([c for c in chs if c <= pos + 0.5] or [0])
                    target = cur if pos - cur > 3 else max([c for c in chs if c < cur - 0.5] or [0])
                if target is not None:
                    self._seek_abs(s, target)
            else:
                if cmd == "prev" and self._pos(s) > 4:
                    self._play_index(s, s["idx"], 0)
                elif s.get("jukebox"):
                    if cmd == "next":
                        self._jukebox_next(s)
                    else:
                        self._play_index(s, s["idx"], 0)     # Jukebox: zurück = Titel von vorn
                else:
                    n = s["idx"] + (1 if cmd == "next" else -1)
                    if 0 <= n < len(s["tracks"]):
                        self._play_index(s, n, 0)
        elif cmd == "skip":                   # ± Sekunden
            self._seek_abs(s, self._pos(s) + float(value or 0))
        elif cmd == "seek":                   # Hörbuch: Stelle im ganzen Buch; Musik: Stelle im Titel
            self._seek_abs(s, float(value or 0))
        elif cmd == "volume":
            soap(h, GRC, "SetGroupVolume", {"InstanceID": 0, "DesiredVolume": max(0, min(100, int(value or 0)))})
            s["volume"] = max(0, min(100, int(value or 0)))
        elif cmd == "stop":
            try:
                soap(h, AVT, "Pause", {"InstanceID": 0})
            except SonosError:
                pass
            pos = self._pos(s)
            self._save(s, force=True)
            with self.lock:
                self.sessions.pop(pid, None)
            return {"active": False, "pos": pos, "kind": s["kind"], "item": s.get("item"), "idx": s["idx"], "rel": s["rel"],
                    "ids": [t.get("id") for t in s["tracks"]], "jukebox": bool(s.get("jukebox"))}
        return self.state(pid)

    def _pos(self, s):
        """Stelle: Hörbuch = im ganzen Buch, Musik = im Titel."""
        t = s["tracks"][s["idx"]]
        return (t["start"] if s["kind"] == "book" else 0) + s["rel"]

    def _seek_abs(self, s, target):
        if s["kind"] == "book":
            target = max(0.0, min(target, s["total"] - 1))
            idx = max(i for i, t in enumerate(s["tracks"]) if t["start"] <= target + 0.01)
            rel = target - s["tracks"][idx]["start"]
            if idx != s["idx"]:
                return self._play_index(s, idx, rel)
        else:
            rel = max(0.0, float(target))
        soap(s["host"], AVT, "Seek", {"InstanceID": 0, "Unit": "REL_TIME", "Target": _hms(rel)})
        s["rel"] = rel
        s["seek_at"] = time.time()

    def state(self, pid):
        with self.lock:
            s = self.sessions.get(pid)
        if not s:
            return {"active": False}
        t = s["tracks"][s["idx"]]
        out = {"active": True, "kind": s["kind"], "group": s["group"], "group_name": s["group_name"],
               "playing": s["state"] in ("PLAYING", "TRANSITIONING"), "state": s["state"], "volume": s.get("volume"), "error": s.get("error"),
               "jukebox": bool(s.get("jukebox"))}
        if s["kind"] == "book":
            pos = self._pos(s)
            ch = max([c for c in s["chapters"] if c["start"] <= pos + 0.5] or [{"title": ""}], key=lambda c: c.get("start", 0))
            out.update(item=s["item"], title=s["title"], sub=ch.get("title") or s["sub"], cover=s["cover_ui"], pos=pos, total=s["total"])
        else:
            out.update(title=t["title"], sub=" · ".join(x for x in (t["artist"], t["album"]) if x), cover=f"/musik/cover/{t['album_id']}",
                       pos=s["rel"], total=t["duration"], idx=s["idx"], n=len(s["tracks"]), track=t.get("id"), album=t["album_id"])
        return out

    # ---- Überwachung (jede Sekunde)
    def _watch(self):
        while True:
            time.sleep(1)
            with self.lock:
                items = list(self.sessions.items())
            for pid, s in items:
                try:
                    self._tick(pid, s)
                except SonosError as e:
                    s["error"] = str(e)
                except Exception:
                    log.exception("Sonos-Überwachung")

    def _tick(self, pid, s):
        h = s["host"]
        tr = soap(h, AVT, "GetTransportInfo", {"InstanceID": 0}, timeout=3)
        pi = soap(h, AVT, "GetPositionInfo", {"InstanceID": 0}, timeout=3)
        s["error"] = None
        state = tr.get("CurrentTransportState", "")
        uri = html.unescape(pi.get("TrackURI", ""))
        cur = s["tracks"][s["idx"]]
        if uri and uri != cur["url"] and time.time() - s["seek_at"] > 5:
            log.info("Sonos %s spielt etwas anderes – Sitzung beendet", s["group_name"])
            self._save(s, force=True)
            with self.lock:
                if self.sessions.get(pid) is s:
                    self.sessions.pop(pid, None)
            return
        if time.time() - s["seek_at"] > 2:
            s["rel"] = _sec(pi.get("RelTime"))
        if "volume" not in s:
            try:
                s["volume"] = int(soap(h, GRC, "GetGroupVolume", {"InstanceID": 0}, timeout=3).get("CurrentVolume", 0))
            except (SonosError, ValueError):
                s["volume"] = None
        prev = s["state"]
        s["state"] = state or prev
        # Titel zu Ende → nächster (Box meldet STOPPED, wir waren am Spielen)
        if state == "STOPPED" and prev in ("PLAYING", "TRANSITIONING") and time.time() - s["seek_at"] > 3:
            if s.get("jukebox"):
                if not self._jukebox_next(s):
                    s["rel"] = cur["duration"]
                    s["state"] = "STOPPED"
                    s["jb_waiting"] = True     # Playlist leer: sobald jemand etwas antippt, geht es weiter
            elif s["idx"] + 1 < len(s["tracks"]):
                self._play_index(s, s["idx"] + 1, 0)
            else:
                s["rel"] = cur["duration"]
                s["state"] = "STOPPED"
                self._save(s, force=True)
        elif s.get("jb_waiting") and state == "STOPPED" and self.app.jukebox.state()["next"]:
            s["jb_waiting"] = False
            self._jukebox_next(s)
        self._save(s)

    def _save(self, s, force=False):
        """Hörbuch: Hörstand ins Profil schreiben (alle 5 s und beim Ende)."""
        if s["kind"] != "book" or (not force and time.time() - s["saved"] < 5):
            return
        s["saved"] = time.time()
        st = self.app.profiles.get(s["pid"]) if self.app.server_mode and s["pid"] else self.app.main_store
        if not st:
            return
        pos = self._pos(s)
        kw = {"pos": round(pos, 2), "updated": time.time(), "changed_ms": int(time.time() * 1000)}
        if s["total"] and pos >= s["total"] - 20:
            kw["finished"] = True
        st.update_item(s["item"], **kw)
        st.settings["last_item"] = s["item"]
