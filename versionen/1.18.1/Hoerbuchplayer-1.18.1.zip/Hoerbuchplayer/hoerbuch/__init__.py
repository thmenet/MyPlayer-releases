VERSION = "1.18.1"
APP_NAME = "MyPlayer"
