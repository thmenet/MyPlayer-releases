VERSION = "1.18.13"
APP_NAME = "MyPlayer"
