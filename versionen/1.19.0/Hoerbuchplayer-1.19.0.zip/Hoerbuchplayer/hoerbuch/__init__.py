VERSION = "1.19.0"
APP_NAME = "MyPlayer"
