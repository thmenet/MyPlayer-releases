VERSION = "1.18.2"
APP_NAME = "MyPlayer"
