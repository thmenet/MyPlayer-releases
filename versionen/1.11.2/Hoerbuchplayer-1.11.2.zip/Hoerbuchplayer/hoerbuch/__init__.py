VERSION = "1.11.2"
APP_NAME = "MyPlayer"
