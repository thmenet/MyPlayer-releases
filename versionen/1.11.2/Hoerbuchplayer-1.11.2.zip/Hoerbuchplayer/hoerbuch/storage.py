"""Speichern und Laden der Daten (Einstellungen, Fortschritt, Cache) als JSON."""
import json
import os
import re
import secrets
import threading
import time

def data_dir():
    base = os.environ.get("HOERBUCH_DATA") or os.environ.get("APPDATA") or os.path.expanduser("~/.config")
    d = os.path.join(base, "Hoerbuchplayer")
    os.makedirs(d, exist_ok=True)
    os.makedirs(os.path.join(d, "covers"), exist_ok=True)
    return d


def _load(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception:
        # beschädigte Datei: Sicherungskopie behalten, mit Standard weitermachen
        try:
            os.replace(path, path + ".kaputt-" + time.strftime("%Y%m%d-%H%M%S"))
        except OSError:
            pass
        bak = path + ".bak"
        if os.path.exists(bak):
            try:
                with open(bak, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return default


def _save(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    if os.path.exists(path):
        try:
            os.replace(path, path + ".bak")
        except OSError:
            pass
    os.replace(tmp, path)


DEFAULT_SETTINGS = {
    "folders": [],            # Bibliotheksordner
    "recursive": True,        # Unterordner einbeziehen
    "podcast_folders": [],    # Ordner, die als Podcast gelten
    "music_folders": [],      # «Meine Musik» (z. B. /mnt/musik auf dem Heimserver)
    "theme": "dark",          # dark | light
    "speed": 1.0,
    "volume": 1.0,
    "view": "grid",           # grid | list
    "sort": "recent",
    "skip_back": 30,
    "skip_fwd": 30,
    "last_item": None,
}


# Heimserver: diese Einstellungen gelten für alle (Bibliothek), alle übrigen je Profil (Person)
SHARED_KEYS = ("folders", "recursive", "podcast_folders", "music_folders", "sonos_hosts", "update_checked")


class Store:
    """Hält settings.json und state.json im Speicher und schreibt sie sicher auf die Platte.
    Ohne Ordner-Angabe = Hauptspeicher (PC-Player); mit Ordner = Speicher eines Profils (Heimserver)."""

    def __init__(self, directory=None):
        self.dir = directory or data_dir()
        os.makedirs(self.dir, exist_ok=True)
        self.lock = threading.RLock()
        self.settings_path = os.path.join(self.dir, "settings.json")
        self.state_path = os.path.join(self.dir, "state.json")
        s = _load(self.settings_path, {})
        self.settings = dict(DEFAULT_SETTINGS)
        self.settings.update(s if isinstance(s, dict) else {})
        st = _load(self.state_path, {})
        self.state = st if isinstance(st, dict) else {}
        self.state.setdefault("items", {})
        self._dirty = False

    # ---- Einstellungen
    def save_settings(self):
        with self.lock:
            _save(self.settings_path, self.settings)

    # ---- Zustand pro Titel
    def item(self, item_id, create=False):
        with self.lock:
            it = self.state["items"].get(item_id)
            if it is None and create:
                it = {}
                self.state["items"][item_id] = it
            return it

    def update_item(self, item_id, **kw):
        with self.lock:
            it = self.item(item_id, create=True)
            for k, v in kw.items():
                if v is None:
                    it.pop(k, None)
                else:
                    it[k] = v
            self._dirty = True
            return it

    def mark_dirty(self):
        self._dirty = True

    def flush(self, force=False):
        with self.lock:
            if self._dirty or force:
                _save(self.state_path, self.state)
                self._dirty = False


PROFILE_COLORS = ["#f4a640", "#5aa9e6", "#7bc67e", "#e6739f", "#b48ae6", "#e6c35a", "#5ac8c8", "#e68a5a"]


class Profiles:
    """Personen auf dem Heimserver («Wer hört?»). Jede hat einen eigenen Ordner profile/<id>/
    mit settings.json (Tempo, Lautstärke, Konto bei player.menet.ch …) und state.json (Hörstand, Lesezeichen)."""

    def __init__(self, main):
        self.main = main
        self.path = os.path.join(main.dir, "profile.json")
        self.lock = threading.RLock()
        data = _load(self.path, [])
        self.list = [p for p in data if isinstance(p, dict) and p.get("id")] if isinstance(data, list) else []
        self.stores = {}

    def save(self):
        with self.lock:
            _save(self.path, self.list)

    def find(self, pid):
        return next((p for p in self.list if p["id"] == pid), None) if pid else None

    def get(self, pid):
        """Speicher des Profils (oder None, wenn es das Profil nicht gibt)."""
        with self.lock:
            if not self.find(pid):
                return None
            st = self.stores.get(pid)
            if st is None:
                st = self.stores[pid] = Store(os.path.join(self.main.dir, "profile", pid))
            return st

    def add(self, name):
        name = " ".join(str(name or "").split())[:40]
        if not name:
            raise ValueError("Bitte einen Namen eingeben.")
        with self.lock:
            if any(p["name"].lower() == name.lower() for p in self.list):
                raise ValueError(f"Das Profil «{name}» gibt es schon.")
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower().translate(str.maketrans("äöüéèà", "aoueea"))).strip("-")[:20] or "profil"
            pid = f"{slug}-{secrets.token_hex(2)}"
            p = {"id": pid, "name": name, "color": PROFILE_COLORS[len(self.list) % len(PROFILE_COLORS)]}
            self.list.append(p)
            self.save()
            return p

    def rename(self, pid, name):
        name = " ".join(str(name or "").split())[:40]
        with self.lock:
            p = self.find(pid)
            if not p or not name:
                raise ValueError("Profil oder Name fehlt.")
            if any(x["name"].lower() == name.lower() and x["id"] != pid for x in self.list):
                raise ValueError(f"Das Profil «{name}» gibt es schon.")
            p["name"] = name
            self.save()
            return p

    def remove(self, pid):
        """Profil entfernen – der Ordner bleibt als Sicherung (profile/_geloescht-…)."""
        with self.lock:
            p = self.find(pid)
            if not p:
                return False
            st = self.stores.pop(pid, None)
            if st:
                st.flush(force=True)
            self.list = [x for x in self.list if x["id"] != pid]
            self.save()
            src = os.path.join(self.main.dir, "profile", pid)
            if os.path.isdir(src):
                try:
                    os.replace(src, os.path.join(self.main.dir, "profile", f"_geloescht-{pid}-{time.strftime('%Y%m%d-%H%M%S')}"))
                except OSError:
                    pass
            return True

    def flush_all(self, force=False):
        with self.lock:
            for st in self.stores.values():
                st.flush(force)
                if force:
                    st.save_settings()


def load_json(path, default):
    return _load(path, default)


def save_json(path, data):
    _save(path, data)
