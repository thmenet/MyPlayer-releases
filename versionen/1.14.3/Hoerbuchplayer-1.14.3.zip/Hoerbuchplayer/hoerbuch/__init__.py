VERSION = "1.14.3"
APP_NAME = "MyPlayer"
