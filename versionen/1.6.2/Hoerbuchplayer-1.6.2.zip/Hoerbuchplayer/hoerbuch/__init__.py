VERSION = "1.6.2"
APP_NAME = "MyPlayer"
