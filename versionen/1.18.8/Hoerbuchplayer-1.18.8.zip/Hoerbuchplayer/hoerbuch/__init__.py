VERSION = "1.18.8"
APP_NAME = "MyPlayer"
