VERSION = "1.12.0"
APP_NAME = "MyPlayer"
