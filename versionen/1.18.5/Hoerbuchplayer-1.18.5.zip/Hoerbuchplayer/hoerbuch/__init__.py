VERSION = "1.18.5"
APP_NAME = "MyPlayer"
