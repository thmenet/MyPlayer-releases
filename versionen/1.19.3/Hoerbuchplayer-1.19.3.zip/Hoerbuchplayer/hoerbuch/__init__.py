VERSION = "1.19.3"
APP_NAME = "MyPlayer"
