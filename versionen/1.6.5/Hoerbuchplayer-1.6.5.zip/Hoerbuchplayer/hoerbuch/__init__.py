VERSION = "1.6.5"
APP_NAME = "MyPlayer"
