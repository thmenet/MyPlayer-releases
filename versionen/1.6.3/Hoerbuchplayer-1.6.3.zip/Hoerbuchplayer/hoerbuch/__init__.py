VERSION = "1.6.3"
APP_NAME = "MyPlayer"
