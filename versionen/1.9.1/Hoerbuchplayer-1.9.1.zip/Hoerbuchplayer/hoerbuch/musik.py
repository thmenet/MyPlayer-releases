"""«Meine Musik»: eigene Musiksammlung (FLAC, MP3, M4A …) aus den Musik-Ordnern, z. B. vom NAS.

- Einlesen schnell und sparsam: bei FLAC wird nur der kleine Kopf gelesen (Länge + Tags), eingebettete Bilder werden übersprungen –
  bei zehntausenden Dateien über das Netz macht das Minuten statt Stunden. Andere Formate über mutagen.
- Zwischenspeicher musik-cache.json (je Datei Grösse + Änderungszeit): beim nächsten Mal werden nur neue/geänderte Dateien gelesen.
- Alben = gleicher Album-Titel im gleichen Ordner (Unterordner «CD1», «Disc 2» … gehören zum Album darüber).
- Cover: Bild im Album-Ordner (cover/folder/front …), sonst das in der ersten Datei eingebettete; verkleinert zwischengespeichert.
"""
import hashlib
import logging
import os
import re
import struct
import threading
import time
import unicodedata

from .storage import load_json, save_json

log = logging.getLogger("musik")

AUDIO_EXT = {".flac": "audio/flac", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac",
             ".ogg": "audio/ogg", ".oga": "audio/ogg", ".opus": "audio/ogg", ".wav": "audio/wav"}
COVER_NAMES = ("cover", "folder", "front", "albumart", "album", "albumartsmall")
DISC_DIR = re.compile(r"^(cd|disc|disk|teil|part)[\s._-]*\d+", re.I)
DISC_IN_TITLE = re.compile(r"[\s,:;\-–(\[]*\b(?:disc|disk|cd)\s*(\d+)\s*[)\]]?\s*$", re.I)   # «Live, Disc 2», «Best of (CD 1)»
SKIP_DIR = re.compile(r"^[#@.]|^\$recycle", re.I)     # Synology-Papierkorb (#recycle), @eaDir, versteckte Ordner
VARIOUS = "Verschiedene Interpreten"
RESCAN_EVERY = 6 * 3600
_COVER_SLOTS = threading.BoundedSemaphore(3)   # höchstens 3 Cover gleichzeitig verkleinern (kleiner Container)


def _id(s, n=16):
    return hashlib.sha1(s.encode("utf-8", "surrogateescape")).hexdigest()[:n]


def _sortkey(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower().strip()
    return re.sub(r"^(the|die|der|das)\s+", "", s)


def _num(v):
    m = re.match(r"\s*(\d+)", str(v or ""))
    return int(m.group(1)) if m else 0


# --------------------------------------------------------------------------- Tags lesen
def read_flac(path):
    """Nur Kopf einer FLAC-Datei: Länge (STREAMINFO) und Tags (VORBIS_COMMENT). Bilder werden übersprungen."""
    tags = {}
    duration = 0.0
    with open(path, "rb") as f:
        if f.read(4) != b"fLaC":
            raise ValueError("keine FLAC-Datei")
        last = False
        while not last:
            hdr = f.read(4)
            if len(hdr) < 4:
                break
            last = bool(hdr[0] & 0x80)
            btype = hdr[0] & 0x7F
            size = int.from_bytes(hdr[1:4], "big")
            if btype == 0:          # STREAMINFO
                d = f.read(size)
                if len(d) >= 18:
                    x = int.from_bytes(d[10:18], "big")
                    rate = x >> 44
                    total = x & ((1 << 36) - 1)
                    duration = total / rate if rate else 0.0
            elif btype == 4:        # VORBIS_COMMENT (Little Endian)
                d = f.read(size)
                try:
                    vl = struct.unpack_from("<I", d, 0)[0]
                    pos = 4 + vl
                    n = struct.unpack_from("<I", d, pos)[0]
                    pos += 4
                    for _ in range(n):
                        ln = struct.unpack_from("<I", d, pos)[0]
                        pos += 4
                        kv = d[pos:pos + ln].decode("utf-8", "replace")
                        pos += ln
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            k = k.lower()
                            if k not in tags:
                                tags[k] = v
                except struct.error:
                    pass
            else:                   # PICTURE, PADDING … überspringen
                f.seek(size, 1)
    return tags, duration


def flac_picture(path):
    """Eingebettetes Bild einer FLAC-Datei (für das Cover), oder None."""
    try:
        with open(path, "rb") as f:
            if f.read(4) != b"fLaC":
                return None
            last = False
            while not last:
                hdr = f.read(4)
                if len(hdr) < 4:
                    return None
                last = bool(hdr[0] & 0x80)
                btype, size = hdr[0] & 0x7F, int.from_bytes(hdr[1:4], "big")
                if btype != 6:
                    f.seek(size, 1)
                    continue
                d = f.read(size)
                pos = 4
                ml = int.from_bytes(d[pos:pos + 4], "big"); pos += 4 + ml
                dl = int.from_bytes(d[pos:pos + 4], "big"); pos += 4 + dl + 16
                n = int.from_bytes(d[pos:pos + 4], "big"); pos += 4
                return d[pos:pos + n]
    except OSError:
        return None
    return None


def read_other(path):
    """MP3, M4A, OGG … über mutagen (bei den wenigen Nicht-FLAC-Dateien ist das schnell genug)."""
    import mutagen
    tags, duration = {}, 0.0
    f = mutagen.File(path, easy=True)
    if f is not None:
        duration = float(getattr(f.info, "length", 0) or 0)
        for k in ("title", "artist", "albumartist", "album", "tracknumber", "discnumber", "date", "genre"):
            try:
                v = f.get(k)
            except Exception:
                v = None
            if v:
                tags[k] = str(v[0])
    return tags, duration


def read_track(path):
    ext = os.path.splitext(path)[1].lower()
    tags, duration = read_flac(path) if ext == ".flac" else read_other(path)
    return {
        "title": tags.get("title") or os.path.splitext(os.path.basename(path))[0],
        "artist": tags.get("artist") or "", "albumartist": tags.get("albumartist") or tags.get("album artist") or "",
        "album": tags.get("album") or "", "no": _num(tags.get("tracknumber")), "disc": _num(tags.get("discnumber")) or 1,
        "year": (re.search(r"\d{4}", tags.get("date") or tags.get("year") or "") or [None])[0] or "",
        "genre": tags.get("genre") or "", "duration": round(duration, 2),
    }


# --------------------------------------------------------------------------- Bibliothek
class Musik:
    def __init__(self, store):
        self.store = store          # Hauptspeicher (Einstellung music_folders gilt für alle)
        self.cache_path = os.path.join(store.dir, "musik-cache.json")
        self.cover_dir = os.path.join(store.dir, "musik-cover")
        os.makedirs(self.cover_dir, exist_ok=True)
        self.lock = threading.RLock()
        self.status = {"running": False, "done": 0, "total": 0, "message": "", "tracks": 0, "albums": 0, "artists": 0, "scanned_at": 0}
        self.tracks = {}            # id -> Titel
        self.albums = {}            # id -> Album (mit Liste der Titel-IDs)
        self.artists = {}           # id -> Interpret
        self._again = False
        c = load_json(self.cache_path, {})
        self._cache = c.get("files", {}) if isinstance(c, dict) else {}
        self._build(list(self._cache.items()))   # sofort mit dem letzten Stand starten
        self._timer = None

    def folders(self):
        return [f for f in (self.store.settings.get("music_folders") or []) if f]

    # ---- Einlesen
    def start_scan(self):
        with self.lock:
            if self.status["running"]:
                self._again = True
                return
            if not self.folders():
                self._build([])
                return
            self.status.update(running=True, done=0, total=0, message="Suche Musik …")
        threading.Thread(target=self._scan_safe, daemon=True).start()

    def schedule(self):
        """Alle paar Stunden neu einlesen (neue Alben auf dem NAS erscheinen von selbst)."""
        def loop():
            while True:
                time.sleep(RESCAN_EVERY)
                self.start_scan()
        threading.Thread(target=loop, daemon=True).start()

    def _scan_safe(self):
        while True:
            try:
                self._scan()
            except Exception:
                log.exception("Fehler beim Einlesen der Musik")
                self.status["message"] = "Fehler beim Einlesen – siehe Protokoll"
            with self.lock:
                if self._again:
                    self._again = False
                    continue
                self.status["running"] = False
                return

    def _scan(self):
        t0 = time.time()
        files = []
        for root in self.folders():
            if not os.path.isdir(root):
                log.warning("Musik-Ordner nicht gefunden: %s", root)
                continue
            for d, dirs, names in os.walk(root):
                dirs[:] = sorted(x for x in dirs if not SKIP_DIR.match(x))
                for n in names:
                    if n.startswith(".") or os.path.splitext(n)[1].lower() not in AUDIO_EXT:
                        continue
                    files.append(os.path.join(d, n))
            self.status["message"] = f"{len(files)} Musikdateien gefunden …"
        self.status.update(total=len(files), done=0, message="Lese Titel …")
        new_cache, changed = {}, 0
        for i, p in enumerate(files):
            try:
                st = os.stat(p)
            except OSError:
                continue
            sig = [st.st_size, int(st.st_mtime)]
            c = self._cache.get(p)
            if c and c.get("sig") == sig:
                new_cache[p] = c
            else:
                try:
                    meta = read_track(p)
                except Exception as e:
                    log.info("Nicht lesbar: %s (%s)", p, e)
                    continue
                meta["sig"] = sig
                new_cache[p] = meta
                changed += 1
            if i % 200 == 0:
                self.status["done"] = i
                if changed and changed % 2000 == 0:     # Zwischenstand sichern (langes erstes Einlesen)
                    save_json(self.cache_path, {"files": {**self._cache, **new_cache}})
        self.status["done"] = len(files)
        self._cache = new_cache
        save_json(self.cache_path, {"files": new_cache})
        self._build(list(new_cache.items()))
        self.status["scanned_at"] = int(time.time())
        self.status["message"] = f"{self.status['tracks']} Titel, {self.status['albums']} Alben"
        log.info("Musik eingelesen: %s Titel (%s neu gelesen) in %.0f s", len(new_cache), changed, time.time() - t0)

    # ---- Alben und Interpreten zusammenstellen
    def _build(self, items):
        tracks, albums = {}, {}
        roots = self.folders()
        for path, m in items:
            if roots and not any(path.startswith(r) for r in roots):
                continue
            d = os.path.dirname(path)
            base = os.path.dirname(d) if DISC_DIR.match(os.path.basename(d)) else d      # CD1/CD2 gehören zusammen
            album = m.get("album") or os.path.basename(base)
            # CD-Nummer im Albumtitel («AC/DC Live, Disc 2»): als eine CD des gleichen Albums behandeln – auch wenn die CDs in
            # eigenen Ordnern nebeneinander liegen und die Schreibweise leicht abweicht («AC-DC Live»)
            dm = DISC_IN_TITLE.search(album)
            disc_t = int(dm.group(1)) if dm else 0
            if dm and dm.start() > 0:
                album = album[:dm.start()].strip(" ,-–:")
            norm = re.sub(r"[^a-z0-9]+", "", _sortkey(album)) or album.lower()
            aid = _id((os.path.dirname(base) if dm else base) + "\0" + norm, 12)
            tid = _id(path)
            t = {"id": tid, "path": path, "album": aid, "title": m["title"], "artist": m.get("artist") or "",
                 "no": m.get("no", 0), "disc": (m.get("disc") or 1) if (m.get("disc") or 1) > 1 or not disc_t else disc_t,
                 "duration": m.get("duration", 0)}
            tracks[tid] = t
            a = albums.get(aid)
            if a is None:
                a = albums[aid] = {"id": aid, "title": album, "dir": base, "year": m.get("year") or "", "genre": m.get("genre") or "",
                                   "albumartists": set(), "artists": {}, "tracks": [], "added": 0}
            if m.get("albumartist"):
                a["albumartists"].add(m["albumartist"])
            if t["artist"]:
                a["artists"][t["artist"]] = a["artists"].get(t["artist"], 0) + 1
            a["tracks"].append(tid)
            a["added"] = max(a["added"], (m.get("sig") or [0, 0])[1])
            if not a["year"] and m.get("year"):
                a["year"] = m["year"]
        artists = {}
        for a in albums.values():
            if len(a["albumartists"]) == 1:
                name = next(iter(a["albumartists"]))
            elif len(a["artists"]) == 1:
                name = next(iter(a["artists"]))
            elif a["artists"]:
                top, n = max(a["artists"].items(), key=lambda kv: kv[1])
                name = top if n >= 0.8 * len(a["tracks"]) else VARIOUS
            else:
                name = os.path.basename(os.path.dirname(a["dir"])) or "Unbekannt"
            a["artist"] = name
            a["artist_id"] = _id(name.lower(), 12)
            a["tracks"].sort(key=lambda i: (tracks[i]["disc"], tracks[i]["no"], tracks[i]["title"].lower()))
            a["duration"] = round(sum(tracks[i]["duration"] for i in a["tracks"]))
            del a["albumartists"], a["artists"]
            ar = artists.setdefault(a["artist_id"], {"id": a["artist_id"], "name": name, "albums": []})
            ar["albums"].append(a["id"])
        for ar in artists.values():
            ar["albums"].sort(key=lambda i: (albums[i]["year"] or "9999", _sortkey(albums[i]["title"])))
        with self.lock:
            self.tracks, self.albums, self.artists = tracks, albums, artists
            self.status.update(tracks=len(tracks), albums=len(albums), artists=len(artists))

    # ---- für die Oberfläche
    def overview(self):
        with self.lock:
            al = sorted(self.albums.values(), key=lambda a: (_sortkey(a["artist"]), a["year"] or "9999", _sortkey(a["title"])))
            ar = sorted(self.artists.values(), key=lambda a: _sortkey(a["name"]))
            return {
                "status": self.public_status(),
                "albums": [{"id": a["id"], "title": a["title"], "artist": a["artist"], "artist_id": a["artist_id"], "year": a["year"],
                            "n": len(a["tracks"]), "added": a["added"]} for a in al],
                "artists": [{"id": a["id"], "name": a["name"], "n": len(a["albums"]), "cover": a["albums"][-1] if a["albums"] else None}
                            for a in ar if a["name"] != VARIOUS] + [{"id": a["id"], "name": a["name"], "n": len(a["albums"]),
                                                                       "cover": a["albums"][-1]} for a in ar if a["name"] == VARIOUS],
            }

    def public_status(self):
        return {k: self.status[k] for k in ("running", "done", "total", "message", "tracks", "albums", "artists", "scanned_at")} | {"folders": self.folders()}

    def _track_out(self, t):
        return {"id": t["id"], "title": t["title"], "artist": t["artist"], "no": t["no"], "disc": t["disc"],
                "duration": t["duration"], "album": t["album"], "ext": os.path.splitext(t["path"])[1].lower().lstrip(".")}

    def album(self, aid):
        with self.lock:
            a = self.albums.get(aid)
            if not a:
                return None
            return {"id": a["id"], "title": a["title"], "artist": a["artist"], "artist_id": a["artist_id"], "year": a["year"],
                    "genre": a["genre"], "duration": a["duration"], "tracks": [self._track_out(self.tracks[i]) for i in a["tracks"]],
                    "album_title": a["title"]}

    def artist(self, rid):
        with self.lock:
            r = self.artists.get(rid)
            if not r:
                return None
            return {"id": r["id"], "name": r["name"], "albums": [{"id": i, "title": self.albums[i]["title"], "year": self.albums[i]["year"],
                                                                  "n": len(self.albums[i]["tracks"])} for i in r["albums"]]}

    def search(self, q, limit=100):
        q = (q or "").lower().strip()
        if len(q) < 2:
            return []
        out = []
        with self.lock:
            for t in self.tracks.values():
                a = self.albums.get(t["album"]) or {}
                if q in t["title"].lower() or q in t["artist"].lower():
                    out.append(self._track_out(t) | {"album_title": a.get("title", "")})
                    if len(out) >= limit:
                        break
        return out

    def random(self, n=100):
        import random
        with self.lock:
            ids = random.sample(list(self.tracks), min(n, len(self.tracks)))
            return [self._track_out(self.tracks[i]) | {"album_title": self.albums[self.tracks[i]["album"]]["title"],
                                                       "album_artist": self.albums[self.tracks[i]["album"]]["artist"]} for i in ids]

    def track_file(self, tid):
        with self.lock:
            t = self.tracks.get(tid)
        if not t:
            return None, None
        return t["path"], AUDIO_EXT.get(os.path.splitext(t["path"])[1].lower(), "application/octet-stream")

    # ---- Cover
    def cover(self, aid, big=False):
        """Pfad zu einem (verkleinerten) Cover des Albums, oder None."""
        with self.lock:
            a = self.albums.get(aid)
        if not a:
            return None
        out = os.path.join(self.cover_dir, f"{aid}{'-gross' if big else ''}.jpg")
        none = os.path.join(self.cover_dir, f"{aid}.kein")
        if os.path.exists(out):
            return out
        if os.path.exists(none):
            return None
        src = self._cover_source(a)
        if not src:
            open(none, "w").close()
            return None
        from .library import _run_ffmpeg
        tmp = None
        if isinstance(src, bytes):
            tmp = os.path.join(self.cover_dir, f"{aid}.roh")
            with open(tmp, "wb") as f:
                f.write(src)
            src = tmp
        size = 900 if big else 360
        with _COVER_SLOTS:
            if os.path.exists(out):          # inzwischen von einer anderen Anfrage erstellt
                return out
            r = _run_ffmpeg(["-y", "-i", src, "-vf", f"scale='min({size},iw)':-2", "-frames:v", "1", "-q:v", "4", out], timeout=30)
        if tmp:
            try:
                os.remove(tmp)
            except OSError:
                pass
        if r is None or r.returncode != 0 or not os.path.exists(out):
            return src if not tmp and os.path.exists(src) else None      # ohne ffmpeg: Originalbild
        return out

    def _cover_source(self, a):
        try:
            names = os.listdir(a["dir"])
        except OSError:
            names = []
        imgs = [n for n in names if os.path.splitext(n)[1].lower() in (".jpg", ".jpeg", ".png") and not n.startswith(".")]
        for want in COVER_NAMES:
            for n in imgs:
                if os.path.splitext(n)[0].lower() == want:
                    return os.path.join(a["dir"], n)
        if imgs:
            return os.path.join(a["dir"], sorted(imgs)[0])
        with self.lock:
            first = self.tracks.get(a["tracks"][0]) if a["tracks"] else None
        if first and first["path"].lower().endswith(".flac"):
            return flac_picture(first["path"])
        if first:
            try:
                import mutagen
                f = mutagen.File(first["path"])
                for k in (f.tags or {}).keys() if f is not None else []:
                    if str(k).startswith("APIC"):
                        return f.tags[k].data
                if f is not None and "covr" in (f.tags or {}):
                    return bytes(f.tags["covr"][0])
            except Exception:
                return None
        return None
