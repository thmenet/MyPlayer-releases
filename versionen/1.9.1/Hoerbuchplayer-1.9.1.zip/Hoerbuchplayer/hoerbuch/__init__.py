VERSION = "1.9.1"
APP_NAME = "MyPlayer"
