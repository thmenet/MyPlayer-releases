VERSION = "1.18.4"
APP_NAME = "MyPlayer"
