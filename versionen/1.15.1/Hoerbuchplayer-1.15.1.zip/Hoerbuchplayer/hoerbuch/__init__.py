VERSION = "1.15.1"
APP_NAME = "MyPlayer"
