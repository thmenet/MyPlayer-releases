VERSION = "1.17.0"
APP_NAME = "MyPlayer"
