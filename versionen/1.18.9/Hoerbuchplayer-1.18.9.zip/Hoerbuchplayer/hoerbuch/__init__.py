VERSION = "1.18.9"
APP_NAME = "MyPlayer"
