VERSION = "1.15.2"
APP_NAME = "MyPlayer"
