VERSION = "1.4.0"
APP_NAME = "Hörbuch-Player"
