"""Jukebox: eine gemeinsame Playlist für das ganze Haus (alle Profile, auch «Gast»).

Wer am Handy einen Titel antippt, hängt ihn hinten an; nochmals tippen nimmt ihn wieder heraus.
«Zufall» füllt die Liste selbst nach – angetippte Titel kommen immer vor den Zufallstiteln dran.
Abgespielt wird entweder auf dem Gerät, das «Abspielen» drückt, oder auf Sonos (der Heimserver holt dann
bei jedem Titelende selbst den nächsten). Gespeichert in jukebox.json im Datenordner.
"""
import json
import os
import random
import threading

MAX_LEN = 300        # mehr Titel braucht kein Fest
MIX_MIN = 5          # weniger kommende Titel → Zufall füllt nach
MIX_ADD = 20


class Jukebox:
    def __init__(self, musik, data_dir):
        self.musik = musik
        self.path = os.path.join(data_dir, "jukebox.json")
        self.lock = threading.RLock()
        d = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            pass
        self.cur = d.get("cur") if isinstance(d.get("cur"), dict) else None
        self.next = [e for e in d.get("next") or [] if isinstance(e, dict) and e.get("id")]
        self.mix = bool(d.get("mix"))
        self.rev = int(d.get("rev") or 0)

    # ---- intern
    def _save(self):
        self.rev += 1
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"cur": self.cur, "next": self.next, "mix": self.mix, "rev": self.rev}, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def _known(self, tid):
        return tid in self.musik.tracks

    def _refill(self):
        if not self.mix or len(self.next) >= MIX_MIN:
            return
        have = {e["id"] for e in self.next} | ({self.cur["id"]} if self.cur else set())
        pool = [t for t in self.musik.tracks if t not in have]
        for tid in random.sample(pool, min(MIX_ADD, len(pool))):
            self.next.append({"id": tid, "auto": True})

    def _out(self, e):
        mu = self.musik
        t = mu.tracks.get(e["id"])
        if not t:
            return None
        a = mu.albums.get(t["album"], {})
        return mu._track_out(t) | {"album_title": a.get("title", ""), "album_artist": a.get("artist", ""),
                                   "auto": bool(e.get("auto")), "by": e.get("by") or ""}

    # ---- nach aussen
    def state(self):
        with self.lock, self.musik.lock:
            nxt = [x for x in (self._out(e) for e in self.next) if x]
            return {"rev": self.rev, "mix": self.mix, "cur": self._out(self.cur) if self.cur else None, "next": nxt}

    def toggle(self, tid, by=""):
        """Antippen: hinten anhängen (vor die Zufallstitel) oder – wenn schon drin – wieder herausnehmen."""
        with self.lock:
            if not self._known(tid):
                raise ValueError("Diesen Titel gibt es nicht (mehr).")
            i = next((n for n, e in enumerate(self.next) if e["id"] == tid), -1)
            if i >= 0 and not self.next[i].get("auto"):
                self.next.pop(i)
                added = False
            else:
                if i >= 0:                       # von «Zufall» eingeplant → jetzt gewünscht: nach vorne zu den Wünschen
                    self.next.pop(i)
                if len(self.next) >= MAX_LEN:
                    raise ValueError("Die Playlist ist voll.")
                pos = next((n for n, e in enumerate(self.next) if e.get("auto")), len(self.next))
                self.next.insert(pos, {"id": tid, "by": str(by or "")[:40]})
                added = True
            self._save()
        return added

    def add_many(self, ids, by=""):
        """Ganzes Album anhängen (Titel, die schon drin sind, bleiben, wo sie sind)."""
        with self.lock:
            have = {e["id"] for e in self.next}
            pos = next((n for n, e in enumerate(self.next) if e.get("auto")), len(self.next))
            new = [{"id": t, "by": str(by or "")[:40]} for t in ids if self._known(t) and t not in have][:MAX_LEN - len(self.next)]
            self.next[pos:pos] = new
            self._save()
            return len(new)

    def advance(self):
        """Nächster Titel: der erste der Liste wird zum laufenden. Gibt den Titel (oder None) zurück."""
        with self.lock:
            self._refill()
            self.cur = self.next.pop(0) if self.next else None
            self._refill()
            self._save()
            return self.cur["id"] if self.cur else None

    def current(self):
        with self.lock:
            return self.cur["id"] if self.cur else None

    def set_mix(self, on):
        with self.lock:
            self.mix = bool(on)
            if not self.mix:          # Zufall aus: die Zufallstitel verschwinden, angetippte bleiben
                self.next = [e for e in self.next if not e.get("auto")]
            self._refill()
            self._save()

    def clear(self):
        with self.lock:
            self.next = []
            self.cur = None
            self.mix = False
            self._save()
