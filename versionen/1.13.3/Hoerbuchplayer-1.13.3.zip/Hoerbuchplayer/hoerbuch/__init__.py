VERSION = "1.13.3"
APP_NAME = "MyPlayer"
