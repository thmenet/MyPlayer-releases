VERSION = "1.14.2"
APP_NAME = "MyPlayer"
