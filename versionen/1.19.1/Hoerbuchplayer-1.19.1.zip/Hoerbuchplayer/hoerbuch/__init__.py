VERSION = "1.19.1"
APP_NAME = "MyPlayer"
