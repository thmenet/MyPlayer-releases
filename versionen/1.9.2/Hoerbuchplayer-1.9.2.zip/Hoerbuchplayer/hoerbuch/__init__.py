VERSION = "1.9.2"
APP_NAME = "MyPlayer"
