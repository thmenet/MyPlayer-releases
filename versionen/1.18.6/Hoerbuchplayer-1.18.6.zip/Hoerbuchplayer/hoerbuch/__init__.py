VERSION = "1.18.6"
APP_NAME = "MyPlayer"
