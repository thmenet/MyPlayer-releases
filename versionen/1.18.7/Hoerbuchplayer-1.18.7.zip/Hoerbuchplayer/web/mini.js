/* Mini-Fenster des PC-Players («MyPlayer (mini)»).
   Abgespielt wird weiter im grossen Fenster; dieses kleine Fenster zeigt nur an und schickt die Tasten hinüber
   (BroadcastChannel – funktioniert zwischen Fenstern derselben Adresse). */
const ch = new BroadcastChannel("myplayer-mini");
const $ = id => document.getElementById(id);
const icon = n => `<svg><use href="#i-${n}"/></svg>`;
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}
let st = null, mode = "", cover = null, lastMsg = 0;
const send = (cmd, extra = {}) => ch.postMessage({ cmd, ...extra });

ch.onmessage = e => {
  const m = e.data || {};
  if (m.typ === "zu") { window.close(); return; }          // grosses Fenster wurde geschlossen
  if (m.typ === "stand") { st = m; lastMsg = Date.now(); render(); }
};

function render() {
  if (!st) return;
  document.documentElement.dataset.theme = st.theme || "dark";
  if (st.mode !== mode) {
    mode = st.mode;
    $("pipBack").innerHTML = icon(mode === "music" ? "prev" : "back");
    $("pipFwd").innerHTML = icon(mode === "music" ? "next" : "fwd");
    $("pipBack").title = mode === "music" ? "Voriger Titel" : "30 s zurück";
    $("pipFwd").title = mode === "music" ? "Nächster Titel" : "30 s vor";
  }
  if (st.cover !== cover) {
    cover = st.cover;
    $("pipCover").innerHTML = cover ? `<img src="${esc(cover)}" alt="">` : `<span class="ph">${icon(mode === "music" ? "music" : "headphones")}</span>`;
  }
  $("pipTitle").textContent = st.title || "";
  $("pipSub").textContent = st.sub || "";
  const pl = st.playing ? "pause" : "play";
  if ($("pipPlay").dataset.st !== pl) { $("pipPlay").dataset.st = pl; $("pipPlay").innerHTML = icon(pl); }
  $("pipTime").textContent = st.dur ? `${fmtClock(st.t)} / ${fmtClock(st.dur)}` : "";
  if (!$("pipBar").dataset.drag) $("pipProg").style.width = st.dur ? (st.t / st.dur * 100) + "%" : "0";
}

document.addEventListener("click", e => {
  const b = e.target.closest("[data-pip]");
  if (!b) return;
  if (b.dataset.pip === "gross") { send("gross"); window.close(); return; }
  send(b.dataset.pip);
});
document.addEventListener("keydown", e => {
  if (e.code === "Space") { e.preventDefault(); send("toggle"); }
  if (e.key === "ArrowLeft") send("back");
  if (e.key === "ArrowRight") send("fwd");
});

// Fortschritt ziehen
{
  const el = $("pipBar"), fill = $("pipProg");
  const frac = e => { const r = el.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); };
  el.addEventListener("pointerdown", e => {
    if (!st || !st.dur) return;
    e.preventDefault(); el.setPointerCapture(e.pointerId); el.dataset.drag = "1";
    fill.style.width = frac(e) * 100 + "%";
  });
  el.addEventListener("pointermove", e => {
    if (!el.dataset.drag) return;
    const f = frac(e); fill.style.width = f * 100 + "%";
    $("pipTime").textContent = `${fmtClock(f * st.dur)} / ${fmtClock(st.dur)}`;
  });
  el.addEventListener("pointerup", e => { if (!el.dataset.drag) return; delete el.dataset.drag; send("seek", { t: frac(e) * st.dur }); });
  el.addEventListener("pointercancel", () => { delete el.dataset.drag; });
}

// «Bin da» – das grosse Fenster schickt darauf den Stand (und dann laufend)
send("hallo");
setInterval(() => {
  send("hallo");
  if (Date.now() - lastMsg > 5000) { $("pipSub").textContent = "Keine Verbindung zum grossen Fenster"; }
}, 1000);
window.addEventListener("pagehide", () => send("tschuess"));
