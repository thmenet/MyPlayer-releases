"""Updates: schaut auf GitHub nach einer neuen Version, lädt sie herunter und spielt sie ein."""
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile

from . import VERSION

log = logging.getLogger("update")

RELEASES_REPO = "thmenet/MyPlayer-releases"
API_URL = os.environ.get("HOERBUCH_UPDATE_URL") or f"https://api.github.com/repos/{RELEASES_REPO}/releases/latest"
CHECK_EVERY = 20 * 3600          # automatisch höchstens etwa einmal pro Tag
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
PROGRAM_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def parse_version(v):
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(n) for n in nums[:3]) + (0,) * (3 - len(nums[:3]))


def _get(url, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": f"Hoerbuchplayer/{VERSION}",
                                               "Accept": "application/vnd.github+json"})
    from .cloud import SSL_CONTEXT   # Windows-Speicher + certifi (siehe cloud.py)
    with urllib.request.urlopen(req, timeout=timeout, context=SSL_CONTEXT) as r:
        return r.read()


class Updater:
    def __init__(self, store):
        self.store = store
        self.lock = threading.Lock()
        self.state = {"current": VERSION, "latest": None, "available": False, "notes": "",
                      "url": None, "checked": 0, "error": None, "busy": False, "phase": ""}

    def public(self):
        return dict(self.state)

    # ---- Nachsehen
    def check(self, force=False):
        last = self.store.settings.get("update_checked", 0) or 0
        if not force and time.time() - last < CHECK_EVERY and self.state["checked"]:
            return self.public()
        try:
            data = json.loads(_get(API_URL).decode("utf-8"))
            tag = data.get("tag_name") or data.get("name") or ""
            asset = next((a for a in data.get("assets") or [] if a.get("name", "").lower().endswith(".zip")), None)
            latest = ".".join(str(x) for x in parse_version(tag))
            self.state.update(latest=latest, notes=data.get("body") or "", error=None,
                              url=asset.get("browser_download_url") if asset else None,
                              available=bool(asset) and parse_version(tag) > parse_version(VERSION))
            log.info("Update-Prüfung: installiert %s, verfügbar %s", VERSION, latest)
        except Exception as e:
            msg = str(e)
            if "404" in msg:
                msg = "Noch keine Version veröffentlicht."
            elif "urlopen error" in msg or "timed out" in msg:
                msg = "Keine Verbindung zum Internet."
            self.state.update(error=msg)
            log.warning("Update-Prüfung fehlgeschlagen: %s", e)
        self.state["checked"] = time.time()
        self.store.settings["update_checked"] = self.state["checked"]
        return self.public()

    def check_async(self):
        threading.Thread(target=self.check, daemon=True).start()

    # ---- Einspielen
    def apply(self, on_ready_to_quit):
        """Lädt die neue Version, startet den Helfer und beendet danach das Programm."""
        if not self.state.get("available") or not self.state.get("url"):
            return False, "Keine neue Version verfügbar."
        with self.lock:
            if self.state["busy"]:
                return False, "Update läuft bereits."
            self.state.update(busy=True, phase="Lade herunter …", error=None)
        try:
            tmp = tempfile.mkdtemp(prefix="hoerbuch-update-")
            zpath = os.path.join(tmp, "update.zip")
            with open(zpath, "wb") as f:
                f.write(_get(self.state["url"], timeout=120))
            self.state["phase"] = "Entpacke …"
            src = os.path.join(tmp, "neu")
            with zipfile.ZipFile(zpath) as z:
                z.extractall(src)
            root = find_program_root(src)
            if not root:
                raise RuntimeError("Das Update-Paket ist unvollständig.")
            self.state["phase"] = "Starte neu …"
            from .modus import SERVER
            if SERVER:
                # Heimserver (Linux): Dateien gleich hier ersetzen (laufende Dateien darf man dort überschreiben),
                # dann beenden – der Systemdienst (systemd) startet die neue Version von selbst.
                helper = os.path.join(root, "hoerbuch", "update_helper.py")
                r = subprocess.run([sys.executable, "-I", helper, "--quelle", root, "--ziel", PROGRAM_DIR, "--kein-neustart"],
                                   capture_output=True, timeout=900)
                if r.returncode != 0:
                    raise RuntimeError("Dateien konnten nicht ersetzt werden: " + r.stderr.decode("utf-8", "replace")[-300:])
                on_ready_to_quit()
                return True, ""
            start_helper(root, PROGRAM_DIR, os.getpid())
            on_ready_to_quit()
            return True, ""
        except Exception as e:
            log.exception("Update fehlgeschlagen")
            self.state.update(busy=False, phase="", error=f"Update fehlgeschlagen: {e}")
            return False, self.state["error"]


def find_program_root(folder):
    for d, _dirs, files in os.walk(folder):
        if "app.py" in files and os.path.isdir(os.path.join(d, "hoerbuch")):
            return d
    return None


def venv_python(gui=True):
    """Python der Programmumgebung (.venv) – bleibt beim Update unverändert."""
    exe = sys.executable
    if sys.platform == "win32":
        base = os.path.dirname(exe)
        cand = os.path.join(base, "pythonw.exe" if gui else "python.exe")
        if os.path.exists(cand):
            return cand
    return exe


def start_helper(new_root, target, pid):
    helper = os.path.join(new_root, "hoerbuch", "update_helper.py")
    args = [venv_python(gui=True), "-I", helper, "--quelle", new_root, "--ziel", target, "--pid", str(pid)]
    log.info("Starte Update-Helfer: %s", args)
    kw = {}
    if sys.platform == "win32":
        kw["creationflags"] = NO_WINDOW | 0x00000008 | 0x00000200  # DETACHED_PROCESS | NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    subprocess.Popen(args, close_fds=True, cwd=new_root, **kw)
