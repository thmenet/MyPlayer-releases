"""Genres für «Meine Musik»: die Genre-Angaben der Dateien zu wenigen, verständlichen Gruppen zusammenfassen.

In Musiksammlungen steht oft «Rock», «Classic Rock», «Rock/Pop», «(17)» (alte MP3-Nummer) usw. durcheinander.
Hier wird daraus z. B. «Rock» und «Pop». «Weihnachten» ist meist kein Genre – darum zählen auch Wörter im
Titel oder Albumnamen (Christmas, Weihnacht, Jingle Bells …).
"""
import re

XMAS = "Weihnachten"

# Reihenfolge zählt: der erste Treffer gewinnt (z. B. «Rhythm and Blues» → Soul & R&B, nicht Blues)
FAMILIES = [
    (XMAS, r"christmas|xmas|x-mas|weihnacht|noël|navidad|natale|holiday|advent"),
    ("Klassik", r"classical|klassik|klassisch|\boper\b|opera|symphon|sinfon|baroque|barock|kammermusik|chamber"),
    ("Jazz", r"jazz|swing|bebop|big ?band"),
    ("Soul & R&B", r"soul|r ?& ?b|\brnb\b|rhythm|funk|motown"),
    ("Blues", r"blues"),
    ("Metal", r"metal"),
    ("Punk", r"punk"),
    ("Hip-Hop", r"hip ?-?hop|\brap\b"),
    ("Reggae", r"reggae|\bska\b|dancehall"),
    ("Dance & Elektro", r"electro|electronic|\bdance\b|house|techno|trance|\bedm\b|disco"),
    ("Country", r"country"),
    ("Schlager", r"schlager"),
    ("Volksmusik", r"volksmusik|volkstüml|ländler|jodel"),
    ("Folk", r"folk|singer ?[/-]? ?songwriter|acoustic|liedermacher"),
    ("Soundtrack", r"soundtrack|\bscore\b|filmmusik|musical|\bost\b"),
    ("Kinder", r"kinder|children|\bkids\b"),
    ("Hörspiel", r"hörspiel|audiobook|hörbuch|spoken"),
    ("Latin", r"latin|salsa|bossa|samba|tango"),
    ("Chanson", r"chanson"),
    ("Gospel", r"gospel"),
    ("Rock", r"rock|grunge|alternative|\bindie\b"),
    ("Pop", r"\bpop\b|pop$|^pop"),
]
_FAM = [(n, re.compile(p, re.I)) for n, p in FAMILIES]

# Alte MP3-Genrenummern (ID3v1), nur die häufigen
ID3 = {0: "Blues", 1: "Rock", 2: "Country", 3: "Dance", 4: "Disco", 5: "Funk", 6: "Grunge", 7: "Hip-Hop", 8: "Jazz", 9: "Metal",
       13: "Pop", 14: "R&B", 15: "Rap", 16: "Reggae", 17: "Rock", 18: "Techno", 20: "Alternative", 24: "Soundtrack", 26: "Ambient",
       32: "Classical", 35: "House", 52: "Electronic", 79: "Hard Rock", 80: "Folk", 98: "Easy Listening", 131: "Indie"}

JUNK = {"", "other", "others", "unknown", "<unknown>", "misc", "miscellaneous", "genre", "none", "andere", "sonstige", "sonstiges",
        "general", "unclassifiable", "various", "n/a", "-"}

# Weihnachtslieder erkennt man auch am Titel / Album
XMAS_WORDS = re.compile(r"christmas|xmas|x-mas|weihnacht|noël|navidad|jingle bell|santa claus|stille nacht|tannenbaum|let it snow|"
                        r"rudolph the red|o du fröhliche|leise rieselt|feliz navidad|winter wonderland|kling,? glöckchen", re.I)


def keys(genre, title="", album=""):
    """Gruppen eines Titels (Liste, meist 0–2 Einträge)."""
    out = []
    g = re.sub(r"singer\s*/\s*songwriter", "Singer-Songwriter", genre or "", flags=re.I)
    for part in re.split(r"[;/,|\x00]+", g):
        p = part.strip()
        m = re.fullmatch(r"\(?(\d{1,3})\)?", p)
        if m:
            p = ID3.get(int(m.group(1)), "")
        if p.lower() in JUNK:
            continue
        name = next((n for n, rx in _FAM if rx.search(p)), None)
        if not name:
            name = " ".join(w[:1].upper() + w[1:] for w in p.split())[:30]
        if name and name not in out:
            out.append(name)
    if XMAS not in out and (XMAS_WORDS.search(title or "") or XMAS_WORDS.search(album or "")):
        out.append(XMAS)
    return out


def build(tracks, albums):
    """Gruppen für alle Titel und Alben ausrechnen. Ein Album gehört zu einer Gruppe, wenn mind. die Hälfte seiner Titel dazugehört."""
    index = {}
    for a in albums.values():
        count = {}
        for tid in a["tracks"]:
            t = tracks[tid]
            t["g"] = keys(t.get("genre", ""), t["title"], a["title"])
            for k in t["g"]:
                count[k] = count.get(k, 0) + 1
                index.setdefault(k, {"name": k, "albums": [], "tracks": set()})["tracks"].add(tid)
        a["g"] = [k for k, n in sorted(count.items(), key=lambda kv: -kv[1]) if n * 2 >= len(a["tracks"])]
        for k in a["g"]:
            index[k]["albums"].append(a["id"])
    return index
