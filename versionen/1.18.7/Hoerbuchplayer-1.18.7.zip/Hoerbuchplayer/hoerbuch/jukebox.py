"""Jukebox: eine gemeinsame Playlist für das ganze Haus (alle Profile, auch «Gast»).

Wer am Handy einen Titel antippt, hängt ihn hinten an; nochmals tippen nimmt ihn wieder heraus.
«Zufall» füllt die Liste selbst nach – angetippte Titel kommen immer vor den Zufallstiteln dran.
Abgespielt wird entweder auf dem Gerät, das «Abspielen» drückt, oder auf Sonos (der Heimserver holt dann
bei jedem Titelende selbst den nächsten). Gespeichert in jukebox.json im Datenordner.
"""
import json
import os
import random
import threading

MAX_LEN = 300        # mehr Titel braucht kein Fest
MIX_MIN = 5          # weniger kommende Titel → Zufall füllt nach
MIX_ADD = 20


class Jukebox:
    def __init__(self, musik, data_dir):
        self.musik = musik
        self.path = os.path.join(data_dir, "jukebox.json")
        self.lock = threading.RLock()
        d = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            pass
        self.cur = d.get("cur") if isinstance(d.get("cur"), dict) else None
        self.next = [e for e in d.get("next") or [] if isinstance(e, dict) and e.get("id")]
        self.mix = bool(d.get("mix"))
        self.hist = [e for e in d.get("hist") or [] if isinstance(e, dict) and e.get("id")][-30:]   # zuletzt gespielt (für «Zurück»)
        self.mix_genre = str(d.get("mix_genre") or "")       # Zufall nur aus einem Genre (leer = alles)
        self.rev = int(d.get("rev") or 0)

    # ---- intern
    def _save(self):
        self.rev += 1
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"cur": self.cur, "next": self.next, "mix": self.mix, "mix_genre": self.mix_genre, "hist": self.hist[-30:], "rev": self.rev}, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def _known(self, tid):
        return tid in self.musik.tracks or tid.startswith("am:")

    @staticmethod
    def _meta(meta):
        """Angaben zu einem Apple-Music-Titel (kommen vom Gerät, das ihn wünscht – der Heimserver kennt Apple Music nicht)."""
        m = meta if isinstance(meta, dict) else {}
        art = str(m.get("art") or "")
        return {"t": str(m.get("t") or "?")[:200], "a": str(m.get("a") or "")[:200], "al": str(m.get("al") or "")[:200],
                "art": art[:500] if art.startswith("https://") else "", "d": float(m.get("d") or 0) if str(m.get("d") or "0").replace(".", "", 1).isdigit() else 0}

    def _refill(self):
        if not self.mix or len(self.next) >= MIX_MIN:
            return
        have = {e["id"] for e in self.next} | ({self.cur["id"]} if self.cur else set())
        src = self.musik.genre_track_ids(self.mix_genre) if self.mix_genre else self.musik.tracks
        pool = [t for t in src if t not in have and t in self.musik.tracks]
        for tid in random.sample(pool, min(MIX_ADD, len(pool))):
            self.next.append({"id": tid, "auto": True})

    def _out(self, e):
        if e["id"].startswith("am:"):          # Apple-Music-Titel
            m = e.get("m") or {}
            return {"id": e["id"], "am": e["id"][3:], "apple": True, "title": m.get("t", "?"), "artist": m.get("a", ""),
                    "album_title": m.get("al", ""), "album": "", "art": m.get("art", ""), "duration": m.get("d", 0),
                    "auto": False, "by": e.get("by") or ""}
        mu = self.musik
        t = mu.tracks.get(e["id"])
        if not t:
            return None
        a = mu.albums.get(t["album"], {})
        return mu._track_out(t) | {"album_title": a.get("title", ""), "album_artist": a.get("artist", ""),
                                   "auto": bool(e.get("auto")), "by": e.get("by") or ""}

    # ---- nach aussen
    def state(self):
        with self.lock, self.musik.lock:
            nxt = [x for x in (self._out(e) for e in self.next) if x]
            return {"rev": self.rev, "mix": self.mix, "mix_genre": self.mix_genre, "cur": self._out(self.cur) if self.cur else None, "next": nxt}

    def toggle(self, tid, by="", meta=None):
        """Antippen: hinten anhängen (vor die Zufallstitel) oder – wenn schon drin – wieder herausnehmen."""
        with self.lock:
            if not self._known(tid):
                raise ValueError("Diesen Titel gibt es nicht (mehr).")
            i = next((n for n, e in enumerate(self.next) if e["id"] == tid), -1)
            if i >= 0 and not self.next[i].get("auto"):
                self.next.pop(i)
                added = False
            else:
                if i >= 0:                       # von «Zufall» eingeplant → jetzt gewünscht: nach vorne zu den Wünschen
                    self.next.pop(i)
                if len(self.next) >= MAX_LEN:
                    raise ValueError("Die Playlist ist voll.")
                pos = next((n for n, e in enumerate(self.next) if e.get("auto")), len(self.next))
                e = {"id": tid, "by": str(by or "")[:40]}
                if tid.startswith("am:"):
                    if len(tid) > 80:
                        raise ValueError("Ungültiger Apple-Music-Titel.")
                    e["m"] = self._meta(meta)
                self.next.insert(pos, e)
                added = True
            self._save()
        return added

    def add_many(self, ids, by="", metas=None):
        """Ganzes Album anhängen (Titel, die schon drin sind, bleiben, wo sie sind). metas: Angaben zu Apple-Music-Titeln je ID."""
        metas = metas if isinstance(metas, dict) else {}
        with self.lock:
            have = {e["id"] for e in self.next}
            pos = next((n for n, e in enumerate(self.next) if e.get("auto")), len(self.next))
            new = [{"id": t, "by": str(by or "")[:40]} | ({"m": self._meta(metas.get(t))} if t.startswith("am:") else {})
                   for t in ids if self._known(t) and t not in have and len(t) <= 80][:MAX_LEN - len(self.next)]
            self.next[pos:pos] = new
            self._save()
            return len(new)

    def advance(self):
        """Nächster Titel: der erste der Liste wird zum laufenden. Gibt den Titel (oder None) zurück."""
        with self.lock:
            self._refill()
            if self.cur:
                self.hist = (self.hist + [self.cur])[-30:]
            self.cur = self.next.pop(0) if self.next else None
            self._refill()
            self._save()
            return self.cur["id"] if self.cur else None

    def back(self):
        """Zurück zum vorher gespielten Titel; der laufende kommt wieder vorne in die Liste. Gibt den Titel (oder None) zurück."""
        with self.lock:
            if not self.hist:
                return self.cur["id"] if self.cur else None
            if self.cur:
                self.next.insert(0, self.cur)
            self.cur = self.hist.pop()
            self._save()
            return self.cur["id"]

    def current(self):
        with self.lock:
            return self.cur["id"] if self.cur else None

    def set_mix(self, on, genre=""):
        with self.lock:
            changed = (genre or "") != self.mix_genre
            self.mix, self.mix_genre = bool(on), genre or ""
            if not self.mix or changed:   # Zufall aus (oder anderes Genre): die Zufallstitel verschwinden, angetippte bleiben
                self.next = [e for e in self.next if not e.get("auto")]
            self._refill()
            self._save()

    def clear(self):
        with self.lock:
            self.next = []
            self.cur = None
            self.mix = False
            self._save()
