VERSION = "1.18.7"
APP_NAME = "MyPlayer"
