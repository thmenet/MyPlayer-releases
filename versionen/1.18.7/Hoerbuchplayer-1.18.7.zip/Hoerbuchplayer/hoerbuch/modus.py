"""Betriebsart: PC-Player (Fenster, nur dieser Computer) oder Heimserver (ohne Fenster, im Heimnetz, mit Profilen).

Heimserver = Start mit `--server` (setzt MYPLAYER_SERVER=1). Weitere Angaben über Umgebungsvariablen:
  MYPLAYER_PORT   (Standard 48219)
  MYPLAYER_HOSTS  zusätzliche Namen, unter denen der Server aufgerufen werden darf (Komma-getrennt), z. B. «myplayer.fritz.box»
"""
import os
import sys

if "--server" in sys.argv:
    os.environ["MYPLAYER_SERVER"] = "1"

SERVER = os.environ.get("MYPLAYER_SERVER") == "1"
