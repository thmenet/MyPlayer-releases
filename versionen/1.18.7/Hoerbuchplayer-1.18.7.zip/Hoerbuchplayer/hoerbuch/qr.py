"""Kleiner QR-Code-Erzeuger (ohne zusätzliche Pakete) für den Gäste-Link auf der TV-Ansicht.

Nur das Nötigste: Byte-Modus, Fehlerkorrektur «M», Versionen 1–9 (bis ca. 180 Zeichen), Ausgabe als SVG.
Aufbau nach der QR-Norm (ISO/IEC 18004), Vorgehen wie in der bekannten Referenz von Project Nayuki.
"""

# Version → (Fehlerkorrektur-Bytes je Block, [(Anzahl Blöcke, Datenbytes je Block), …]) für Stufe M
_BLOCKS = {
    1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]), 5: (24, [(2, 43)]),
    6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]),
}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46]}


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    res = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            res[j] = _gf_mul(res[j], root)
            if j + 1 < degree:
                res[j] ^= res[j + 1]
        root = _gf_mul(root, 2)
    return res


def _rs_remainder(data, div):
    res = [0] * len(div)
    for b in data:
        f = b ^ res.pop(0)
        res.append(0)
        for i, c in enumerate(div):
            res[i] ^= _gf_mul(c, f)
    return res


def _codewords(text):
    data = text.encode("utf-8")
    for ver in range(1, 10):
        ec, groups = _BLOCKS[ver]
        cap = sum(n * k for n, k in groups)
        if 4 + 8 + len(data) * 8 <= cap * 8:
            break
    else:
        raise ValueError("Text zu lang für den QR-Code")
    bits = [0, 1, 0, 0] + [(len(data) >> i) & 1 for i in range(7, -1, -1)]
    for b in data:
        bits += [(b >> i) & 1 for i in range(7, -1, -1)]
    bits += [0] * min(4, cap * 8 - len(bits))
    bits += [0] * (-len(bits) % 8)
    by = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    while len(by) < cap:
        by.append(pad[(len(by) - len(bits) // 8) % 2])
    # in Blöcke teilen, Fehlerkorrektur rechnen, verschränken
    blocks, pos, div = [], 0, _rs_divisor(ec)
    for n, k in groups:
        for _ in range(n):
            d = by[pos:pos + k]
            pos += k
            blocks.append((d, _rs_remainder(d, div)))
    out = []
    for i in range(max(len(d) for d, _ in blocks)):
        out += [d[i] for d, _ in blocks if i < len(d)]
    for i in range(ec):
        out += [e[i] for _, e in blocks]
    return ver, out


_MASKS = [
    lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0, lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0, lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0, lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
]


def _penalty(m):
    n, p = len(m), 0
    lines = [row for row in m] + [[m[y][x] for y in range(n)] for x in range(n)]
    for line in lines:
        run, prev = 0, None
        for v in line:
            if v == prev:
                run += 1
            else:
                if run >= 5:
                    p += run - 2
                run, prev = 1, v
        if run >= 5:
            p += run - 2
        s = "".join("1" if v else "0" for v in line)
        p += 40 * (s.count("10111010000") + s.count("00001011101"))
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                p += 3
    dark = sum(sum(r) for r in m)
    p += 10 * (abs(dark * 20 - n * n * 10) // (n * n))
    return p


def matrix(text):
    """QR-Code als Liste von Zeilen mit True (dunkel) / False (hell)."""
    ver, data = _codewords(text)
    size = ver * 4 + 17
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        mod[y][x] = dark
        fn[y][x] = True

    for i in range(size):                         # Taktlinien
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):    # Suchmuster in drei Ecken
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    setf(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    al = _ALIGN[ver]
    for i, ay in enumerate(al):                   # Ausrichtungsmuster
        for j, ax in enumerate(al):
            if (i == 0 and j == 0) or (i == 0 and j == len(al) - 1) or (i == len(al) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)

    def format_bits(mask):
        d = (0 << 3) | mask                       # Stufe M = 00
        r = d
        for _ in range(10):
            r = (r << 1) ^ ((r >> 9) * 0x537)
        bits = ((d << 10) | r) ^ 0x5412
        b = lambda i: (bits >> i) & 1 == 1
        for i in range(6):
            setf(8, i, b(i))
        setf(8, 7, b(6))
        setf(8, 8, b(7))
        setf(7, 8, b(8))
        for i in range(9, 15):
            setf(14 - i, 8, b(i))
        for i in range(8):
            setf(size - 1 - i, 8, b(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, b(i))
        setf(8, size - 8, True)                   # immer dunkles Modul

    format_bits(0)
    if ver >= 7:
        r = ver
        for _ in range(12):
            r = (r << 1) ^ ((r >> 11) * 0x1F25)
        bits = (ver << 12) | r
        for i in range(18):
            bit = (bits >> i) & 1 == 1
            a, b2 = size - 11 + i % 3, i // 3
            setf(a, b2, bit)
            setf(b2, a, bit)
    # Daten im Zickzack von unten rechts
    i, right = 0, size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                y = size - 1 - vert if ((right + 1) & 2) == 0 else vert
                if not fn[y][x] and i < len(data) * 8:
                    mod[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1
        right -= 2
    # beste Maske wählen
    best = None
    for mk in range(8):
        m = [[mod[y][x] ^ (not fn[y][x] and _MASKS[mk](x, y)) for x in range(size)] for y in range(size)]
        saved = (mod, fn)
        mod = m
        format_bits(mk)
        pen = _penalty(mod)
        if best is None or pen < best[0]:
            best = (pen, [r[:] for r in mod])
        mod = saved[0]
    return best[1]


def svg(text, dark="#000", light="#fff"):
    m = matrix(text)
    n, q = len(m), 4                              # 4 Module Rand ringsum
    path = "".join(f"M{x + q},{y + q}h1v1h-1z" for y, row in enumerate(m) for x, v in enumerate(row) if v)
    s = n + 2 * q
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {s} {s}" shape-rendering="crispEdges">'
            f'<rect width="{s}" height="{s}" fill="{light}"/><path d="{path}" fill="{dark}"/></svg>')
