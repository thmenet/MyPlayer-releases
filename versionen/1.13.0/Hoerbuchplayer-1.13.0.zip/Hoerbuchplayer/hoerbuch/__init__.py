VERSION = "1.13.0"
APP_NAME = "MyPlayer"
