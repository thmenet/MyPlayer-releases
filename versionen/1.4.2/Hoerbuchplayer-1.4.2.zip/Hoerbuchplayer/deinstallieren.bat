@echo off
setlocal
title Hoerbuch-Player entfernen
set "ZIEL=%LOCALAPPDATA%\Programs\Hoerbuchplayer"
echo Das entfernt den Hoerbuch-Player aus
echo   %ZIEL%
echo sowie die Verknuepfungen im Startmenue und auf dem Desktop.
echo Deine Daten (Fortschritt, Lesezeichen) in %APPDATA%\Hoerbuchplayer bleiben erhalten.
echo Bitte den Player vorher schliessen.
echo.
choice /c JN /n /m "Wirklich entfernen? [J/N] "
if errorlevel 2 exit /b 0
powershell -NoProfile -ExecutionPolicy Bypass -File "%ZIEL%\tools\verknuepfungen.ps1" -Ziel "%ZIEL%" -Entfernen 1
cd /d "%TEMP%"
echo Entferne Programmordner ...
start "" /min cmd /c "timeout /t 2 /nobreak >nul & rmdir /s /q "%ZIEL%""
exit /b 0
