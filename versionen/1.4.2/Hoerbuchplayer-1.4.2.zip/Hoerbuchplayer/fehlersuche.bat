@echo off
setlocal
cd /d "%~dp0"
title Hoerbuch-Player - Fehlersuche
echo ============================================================
echo  Hoerbuch-Player - Fehlersuche
echo  Dieses Fenster zeigt alle Meldungen. Bei Problemen bitte
echo  einen Screenshot davon schicken.
echo ============================================================
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo FEHLER: Python wurde nicht gefunden.
  pause
  exit /b 1
)
echo Gefundenes Python:
%PY% --version
echo.

if not exist ".venv\Scripts\python.exe" (
  echo Programmumgebung wird angelegt ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo FEHLER: venv konnte nicht angelegt werden.
    pause
    exit /b 1
  )
)

fc /b requirements.txt ".venv\requirements.installed" >nul 2>nul
if errorlevel 1 (
  echo Pakete werden installiert ...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo.
    echo FEHLER bei der Installation der Pakete (siehe oben^).
    pause
    exit /b 1
  )
  copy /y requirements.txt ".venv\requirements.installed" >nul
)

echo.
echo Installierte Pakete:
".venv\Scripts\python.exe" -m pip list --disable-pip-version-check 2>nul | findstr /i "mutagen imageio"
echo.
".venv\Scripts\python.exe" -c "import tkinter; print('Ordner-Dialog (tkinter): vorhanden')" 2>nul || echo Ordner-Dialog (tkinter^): FEHLT - Ordnerpfade bitte von Hand einfuegen
".venv\Scripts\python.exe" -c "import imageio_ffmpeg; print('ffmpeg:', imageio_ffmpeg.get_ffmpeg_exe())"
echo.
echo Programm startet ...
echo.
".venv\Scripts\python.exe" app.py --debug
echo.
echo Programm beendet. Protokoll: %APPDATA%\Hoerbuchplayer\protokoll.txt
pause
