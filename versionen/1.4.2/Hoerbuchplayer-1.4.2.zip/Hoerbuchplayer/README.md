# Hörbuch-Player

Ein Player für Hörbücher (M4B aus Libation, MP3-Ordner …) und Podcasts – mit Bibliothek,
Kapiteln, Lesezeichen, Favoriten, Archiv und automatischem Weiterhören.

## Installieren (empfohlen)
- **`installieren.bat`** doppelklicken. Der Player wird nach
  `%LOCALAPPDATA%\Programs\Hoerbuchplayer` kopiert (das ist der persönliche
  «Programme»-Ordner, keine Admin-Rechte nötig). Er bekommt einen Eintrag im **Startmenü**
  (auf Wunsch auch auf dem Desktop) und wird bei Windows als Player für **.m4b** angemeldet.
- **Updates:** Der Player meldet neue Versionen selbst («Neue Version verfügbar» → «Jetzt
  aktualisieren»). Von Hand: neueste ZIP von
  https://github.com/thmenet/MyPlayer-releases/releases/latest laden, entpacken und
  wieder `installieren.bat` starten.
- **Entfernen:** `deinstallieren.bat` im Programmordner.
- **Standard-Player für .m4b:** Rechtsklick auf eine .m4b-Datei → «Öffnen mit» →
  «Andere App auswählen» → «Hörbuch-Player» → «Immer».
  (Windows erlaubt Programmen nicht, sich selbst als Standard festzulegen.)

## Ohne Installation starten
- **`start.bat`** doppelklicken (läuft direkt aus dem entpackten Ordner).
- Bei Problemen: **`fehlersuche.bat`** starten – dort stehen alle Meldungen.

## Erste Schritte
1. Beim ersten Start auf **«Ordner wählen»** klicken und den Ordner mit den Hörbüchern wählen
   (z. B. den Libation-Ordner «Books»).
2. Weitere Ordner und **Podcast-Ordner** über das Zahnrad (Einstellungen) hinzufügen.

## Hörbuch oder Podcast?
1. Liegt die Datei in einem **Podcast-Ordner** (Einstellungen) → Podcast.
2. Genre-Tag enthält «Podcast» → Podcast.
3. **M4B-Datei**, Datei mit **Kapitelmarken**, Ordner mit **mehreren Dateien eines Buchs**
   (z. B. «01 - Kapitel 1.mp3», «02 - …») oder länger als 2 Stunden → Hörbuch.
4. Sonst (einzelne kurze Datei ohne Kapitel) → Podcast.
5. Pro Titel änderbar: Rechtsklick (oder ⋯) → «Art des Titels». Wird gemerkt.

## Mehrere Titel auf einmal
Auf das Kreis-Symbol einer Kachel klicken (oder **Strg + Klick**). Danach wählt jeder
Klick weitere Titel aus. **Umschalt + Klick** wählt alles dazwischen, **Strg + A** alles.
Unten erscheint eine Leiste: «Als Podcast», «Als Hörbuch», «Mehr» (Favoriten, Archiv, gehört).
Rechtsklick geht auch. **Esc** hebt die Auswahl auf.

## Tastenkürzel
Leertaste = Play/Pause · ← / → = 30 s zurück/vor · Bild↑ / Bild↓ = Kapitel zurück/vor ·
↑ / ↓ = Lautstärke · + / − = Tempo · B = Lesezeichen · F = Favorit · Esc = Bibliothek.
Die Medientasten der Tastatur funktionieren auch.

## Wo sind meine Daten?
`%APPDATA%\Hoerbuchplayer` – Fortschritt, Lesezeichen, Favoriten, Einstellungen (JSON),
Cover-Bilder und das Protokoll `protokoll.txt`. Die Hörbuch-Dateien selbst werden nie verändert.

## Technik (kurz)
Python (nur 127.0.0.1, also nur auf diesem Computer erreichbar) + Oberfläche im
Edge-App-Fenster. Pakete: `mutagen` (Tags, Kapitel, Cover), `imageio-ffmpeg` (Kapitel aus
M4B-Dateien, Cover verkleinern).
