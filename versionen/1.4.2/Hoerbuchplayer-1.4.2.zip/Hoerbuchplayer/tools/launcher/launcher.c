/* Hoerbuchplayer.exe – startet den Player (pythonw app.py) und reicht eine Datei weiter. */
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <wchar.h>

static const wchar_t *skip_arg0(const wchar_t *c) {
    if (*c == L'"') { c++; while (*c && *c != L'"') c++; if (*c) c++; }
    else { while (*c && *c != L' ' && *c != L'\t') c++; }
    while (*c == L' ' || *c == L'\t') c++;
    return c;
}

int WINAPI wWinMain(HINSTANCE h, HINSTANCE p, LPWSTR cmd, int show) {
    wchar_t dir[MAX_PATH], py[MAX_PATH], app[MAX_PATH];
    GetModuleFileNameW(NULL, dir, MAX_PATH);
    wchar_t *slash = wcsrchr(dir, L'\\');
    if (slash) *slash = 0;
    swprintf(py, MAX_PATH, L"%ls\\.venv\\Scripts\\pythonw.exe", dir);
    swprintf(app, MAX_PATH, L"%ls\\app.py", dir);
    if (GetFileAttributesW(py) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL, L"Der Hörbuch-Player ist noch nicht fertig eingerichtet.\n\n"
                          L"Bitte zuerst «installieren.bat» (oder «start.bat») ausführen.",
                    L"Hörbuch-Player", MB_ICONINFORMATION);
        return 1;
    }
    const wchar_t *args = skip_arg0(GetCommandLineW());
    size_t n = wcslen(py) + wcslen(app) + wcslen(args) + 16;
    wchar_t *line = (wchar_t *)HeapAlloc(GetProcessHeap(), 0, n * sizeof(wchar_t));
    swprintf(line, n, L"\"%ls\" \"%ls\" %ls", py, app, args);
    AllowSetForegroundWindow(ASFW_ANY);  /* Player darf sein Fenster nach vorne holen */
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si); si.cb = sizeof si;
    ZeroMemory(&pi, sizeof pi);
    if (!CreateProcessW(py, line, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi)) {
        MessageBoxW(NULL, L"Der Hörbuch-Player konnte nicht gestartet werden.\nBitte «fehlersuche.bat» ausführen.",
                    L"Hörbuch-Player", MB_ICONERROR);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
