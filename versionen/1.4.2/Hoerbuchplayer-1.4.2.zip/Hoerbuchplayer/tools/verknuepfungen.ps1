﻿# Legt Verknüpfungen an und meldet den Hörbuch-Player bei Windows als Player für .m4b an
# (oder entfernt alles wieder). Alles nur für den aktuellen Benutzer, ohne Admin-Rechte.
param(
  [Parameter(Mandatory = $true)][string]$Ziel,
  [int]$Desktop = 0,
  [int]$Entfernen = 0
)
$ErrorActionPreference = 'Stop'
$name = 'Hörbuch-Player'
$exe = Join-Path $Ziel 'Hoerbuchplayer.exe'
$ico = Join-Path $Ziel 'web\icon.ico'
$startmenu = Join-Path ([Environment]::GetFolderPath('Programs')) "$name.lnk"
$desk = Join-Path ([Environment]::GetFolderPath('Desktop')) "$name.lnk"
$progId = 'Hoerbuchplayer.Hoerbuch'
$exts = @('.m4b')
$cls = 'HKCU:\Software\Classes'

function Set-Key([string]$path, [string]$valueName, [string]$value) {
  if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
  if ($valueName -eq '') { Set-Item -LiteralPath $path -Value $value }
  else { New-ItemProperty -LiteralPath $path -Name $valueName -Value $value -PropertyType String -Force | Out-Null }
}
function Refresh-Shell {
  try {
    Add-Type -Namespace Hb -Name Shell -MemberDefinition '[DllImport("shell32.dll")] public static extern void SHChangeNotify(int e, int f, System.IntPtr a, System.IntPtr b);'
    [Hb.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
  } catch { }
}

if ($Entfernen -eq 1) {
  foreach ($p in @($startmenu, $desk)) { if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force } }
  foreach ($k in @("$cls\$progId", "$cls\Applications\Hoerbuchplayer.exe", 'HKCU:\Software\Hoerbuchplayer')) {
    if (Test-Path -LiteralPath $k) { Remove-Item -LiteralPath $k -Recurse -Force }
  }
  foreach ($e in $exts) {
    $k = "$cls\$e\OpenWithProgids"
    if (Test-Path -LiteralPath $k) { Remove-ItemProperty -LiteralPath $k -Name $progId -ErrorAction SilentlyContinue }
  }
  Remove-ItemProperty -LiteralPath 'HKCU:\Software\RegisteredApplications' -Name $name -ErrorAction SilentlyContinue
  Refresh-Shell
  Write-Host 'Verknüpfungen und Dateizuordnung entfernt.'
  exit 0
}

# --- Mit Unblock-File die Download-Markierung entfernen (sonst warnt Windows beim Start der .exe)
Get-ChildItem -LiteralPath $Ziel -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notlike '*\.venv\*' } | Unblock-File -ErrorAction SilentlyContinue

# --- Verknüpfungen
$links = @($startmenu)
if ($Desktop -eq 1) { $links += $desk }
$ws = New-Object -ComObject WScript.Shell
foreach ($p in $links) {
  $s = $ws.CreateShortcut($p)
  $s.TargetPath = $exe
  $s.WorkingDirectory = $Ziel
  $s.IconLocation = "$ico,0"
  $s.Description = 'Hörbuch- und Podcast-Player'
  $s.Save()
  Write-Host "Verknüpfung angelegt: $p"
}

# --- Dateityp anmelden (erscheint unter "Öffnen mit" und in "Standard-Apps")
$cmd = '"' + $exe + '" "%1"'
Set-Key "$cls\$progId" '' 'Hörbuch'
Set-Key "$cls\$progId" 'FriendlyTypeName' 'Hörbuch'
Set-Key "$cls\$progId\DefaultIcon" '' "$ico,0"
Set-Key "$cls\$progId\Application" 'ApplicationName' $name
Set-Key "$cls\$progId\Application" 'ApplicationIcon' "$ico,0"
Set-Key "$cls\$progId\shell\open" 'FriendlyAppName' $name
Set-Key "$cls\$progId\shell\open\command" '' $cmd
Set-Key "$cls\Applications\Hoerbuchplayer.exe" 'FriendlyAppName' $name
Set-Key "$cls\Applications\Hoerbuchplayer.exe\DefaultIcon" '' "$ico,0"
Set-Key "$cls\Applications\Hoerbuchplayer.exe\shell\open\command" '' $cmd
foreach ($e in $exts) {
  Set-Key "$cls\$e\OpenWithProgids" $progId ''
  Set-Key "$cls\Applications\Hoerbuchplayer.exe\SupportedTypes" $e ''
  Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities\FileAssociations' $e $progId
}
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationName' $name
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationDescription' 'Hörbuch- und Podcast-Player'
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationIcon' "$ico,0"
Set-Key 'HKCU:\Software\RegisteredApplications' $name 'Software\Hoerbuchplayer\Capabilities'
Refresh-Shell
Write-Host 'Dateityp .m4b angemeldet.'
