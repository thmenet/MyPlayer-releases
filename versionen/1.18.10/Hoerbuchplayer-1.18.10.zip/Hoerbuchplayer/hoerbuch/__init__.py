VERSION = "1.18.10"
APP_NAME = "MyPlayer"
