VERSION = "1.6.8"
APP_NAME = "MyPlayer"
