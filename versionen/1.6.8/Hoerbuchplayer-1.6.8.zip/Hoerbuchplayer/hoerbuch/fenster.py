"""Das grosse Player-Fenster (Edge-App-Fenster mit Titel «MyPlayer …») finden, nach vorne holen oder verkleinern.

Der Mini-Player ist ein eigenes kleines Fenster, das immer im Vordergrund bleibt (gleicher Titel) –
es wird hier übersprungen, damit immer das grosse Fenster gemeint ist.
"""
import logging
import sys

from . import APP_NAME

log = logging.getLogger(__name__)

GWL_EXSTYLE = -20
WS_EX_TOPMOST = 0x0008
SW_MINIMIZE = 6
SW_RESTORE = 9


def _main_window():
    if sys.platform != "win32":
        return None, None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []
    proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.startswith(APP_NAME) and not (user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST):
                    found.append(hwnd)
                    return False
        return True
    user32.EnumWindows(proto(cb), 0)
    return user32, (found[0] if found else None)


def nach_vorne():
    """Grosses Fenster wiederherstellen und nach vorne holen."""
    try:
        user32, h = _main_window()
        if not h:
            return False
        if user32.IsIconic(h):
            user32.ShowWindow(h, SW_RESTORE)
        user32.SetForegroundWindow(h)
        return True
    except Exception as e:
        log.warning("Fenster nach vorne holen fehlgeschlagen: %s", e)
        return False


def minimieren():
    """Grosses Fenster in die Taskleiste (der Mini-Player bleibt sichtbar)."""
    try:
        user32, h = _main_window()
        if not h:
            return False
        user32.ShowWindow(h, SW_MINIMIZE)
        return True
    except Exception as e:
        log.warning("Fenster verkleinern fehlgeschlagen: %s", e)
        return False
