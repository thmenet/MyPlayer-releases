"""Kleiner lokaler Webserver (nur 127.0.0.1): liefert Oberfläche, Audio (mit Spulen) und die Daten."""
import json
import logging
import mimetypes
import os
import re
import secrets
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import VERSION, APP_NAME

log = logging.getLogger("server")
WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
CHUNK = 256 * 1024
# feste Dateitypen (die Windows-Registry liefert manchmal falsche Werte)
STATIC_TYPES = {".html": "text/html", ".css": "text/css", ".js": "application/javascript",
                ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon"}
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

PICK_SCRIPT = r"""
import sys, tkinter
from tkinter import filedialog
r = tkinter.Tk(); r.withdraw(); r.attributes('-topmost', True)
p = filedialog.askdirectory(parent=r, title=sys.argv[2], initialdir=sys.argv[3] or None, mustexist=True)
r.destroy()
open(sys.argv[1], 'w', encoding='utf-8').write(p or '')
"""


def visible_bookmarks(st):
    return [x for x in (st.get("bookmarks") or []) if not x.get("deleted")]


class App:
    """Verbindet Server, Bibliothek und Speicher."""

    def __init__(self, store, library):
        self.store = store
        self.lib = library
        self.token = secrets.token_urlsafe(18)
        self.last_beat = time.time()
        self.had_beat = False
        self.bye_at = None
        self.quit_event = threading.Event()
        self.pending_open = None   # Datei, die die Oberfläche öffnen soll
        from .updater import Updater
        from .cloud import Cloud
        self.updater = Updater(store)
        self.cloud = Cloud(store, library)

    # ---- Darstellung eines Titels
    def light(self, it):
        st = self.store.item(it["id"]) or {}
        kind = st.get("kind") or it["auto_kind"]
        return {
            "id": it["id"], "title": it["title"], "author": it["author"], "narrator": it.get("narrator", ""),
            "show": it["show"], "kind": kind, "auto_kind": it["auto_kind"], "kind_reason": it["kind_reason"],
            "kind_manual": bool(st.get("kind")), "duration": it["duration"], "cover": it["cover"],
            "pos": st.get("pos", 0), "finished": bool(st.get("finished")), "fav": bool(st.get("fav")),
            "archived": bool(st.get("archived")), "updated": st.get("updated", 0), "added": it["added"],
            "date": it.get("date", ""), "folder": it["folder"], "nchapters": len(it["chapters"]),
            "nbookmarks": len(visible_bookmarks(st)), "on_server": self.cloud.is_on_server(it["id"]), "path": it["path"], "genre": it.get("genre", ""),
        }

    def full(self, it):
        d = self.light(it)
        st = self.store.item(it["id"]) or {}
        d.update({
            "description": it.get("description", ""), "album": it.get("album", ""),
            "chapters": it["chapters"],
            "tracks": [{"duration": t["duration"], "mime": t["mime"], "name": os.path.basename(t["path"])} for t in it["tracks"]],
            "bookmarks": visible_bookmarks(st),
        })
        return d


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "Hoerbuchplayer"

        def log_message(self, fmt, *args):  # keine Konsolen-Ausgabe (pythonw!)
            pass

        # ---- Hilfen
        def _host_ok(self):
            host = (self.headers.get("Host") or "").split(":")[0]
            return host in ("127.0.0.1", "localhost")

        def send_json(self, obj, status=200):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def send_bytes(self, data, ctype, status=200, cache=None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", cache or "no-cache")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        def not_found(self):
            self.send_bytes(b"Nicht gefunden", "text/plain; charset=utf-8", 404)

        def read_body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return {}
            raw = self.rfile.read(min(n, 2_000_000))
            try:
                return json.loads(raw.decode("utf-8"))
            except Exception:
                return {}

        # ---- GET
        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            if not self._host_ok():
                return self.send_bytes(b"", "text/plain", 403)
            try:
                self._get()
            except (ConnectionError, BrokenPipeError, TimeoutError):
                pass
            except Exception:
                log.exception("Fehler bei GET %s", self.path)
                try:
                    self.send_json({"error": "Interner Fehler"}, 500)
                except Exception:
                    pass

        def _get(self):
            u = urlparse(self.path)
            path = u.path
            q = parse_qs(u.query)
            if path == "/" or path == "/index.html":
                return self.static("index.html")
            if path.startswith("/static/"):
                return self.static(path[len("/static/"):])
            if path.startswith("/media/"):
                m = re.match(r"^/media/([0-9a-f]+)/(\d+)", path)
                it = app.lib.get(m.group(1)) if m else None
                if not it:
                    return self.not_found()
                n = int(m.group(2))
                if n >= len(it["tracks"]):
                    return self.not_found()
                t = it["tracks"][n]
                return self.send_file(t["path"], t["mime"])
            if path.startswith("/cover/"):
                cid = path[len("/cover/"):]
                if not re.fullmatch(r"[0-9a-f]{16}", cid):
                    return self.not_found()
                base = os.path.join(app.lib.covers_dir, cid)
                p = base + ".jpg"
                if q.get("big"):
                    for ext in (".jpg", ".png", ".jpeg", ".webp"):
                        if os.path.exists(base + ".orig" + ext):
                            p = base + ".orig" + ext
                            break
                if not os.path.exists(p):
                    return self.not_found()
                with open(p, "rb") as f:
                    data = f.read()
                ctype = STATIC_TYPES.get(os.path.splitext(p)[1].lower()) or mimetypes.guess_type(p)[0] or "image/jpeg"
                return self.send_bytes(data, ctype, cache="max-age=86400")
            if path == "/api/init":
                rp = app.store.settings.pop("resume_play", None)
                resume = bool(rp) and rp != VERSION   # nur nach erfolgreichem Update weiterspielen
                return self.send_json({"version": VERSION, "name": APP_NAME, "settings": app.store.settings,
                                       "status": app.lib.status, "data_dir": app.store.dir,
                                       "resume_play": resume, "update": app.updater.public()})
            if path == "/api/update":
                return self.send_json(app.updater.public())
            if path == "/api/library":
                items = [app.light(i) for i in app.lib.all()]
                return self.send_json({"items": items, "status": app.lib.status})
            if path == "/api/status":
                return self.send_json(app.lib.status)
            if path == "/api/item":
                it = app.lib.get((q.get("id") or [""])[0])
                if not it:
                    return self.send_json({"error": "Titel nicht gefunden"}, 404)
                # Vor dem Abspielen den neuesten Stand von player.menet.ch holen (z. B. im Auto weitergehört)
                if app.cloud.token and app.cloud.is_on_server(it["id"]) and time.time() - app.cloud.status["last_sync"] > 20:
                    app.cloud.sync()
                return self.send_json(app.full(it))
            return self.not_found()

        def static(self, rel):
            rel = rel.split("?")[0]
            p = os.path.normpath(os.path.join(WEB_DIR, rel))
            if not p.startswith(os.path.normpath(WEB_DIR)) or not os.path.isfile(p):
                return self.not_found()
            with open(p, "rb") as f:
                data = f.read()
            if rel == "index.html":
                data = data.replace(b"__TOKEN__", app.token.encode()).replace(b"__VERSION__", VERSION.encode())
            ctype = STATIC_TYPES.get(os.path.splitext(p)[1].lower()) or mimetypes.guess_type(p)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
                ctype += "; charset=utf-8"
            self.send_bytes(data, ctype)

        def send_file(self, path, ctype):
            """Datei mit HTTP-Range-Unterstützung senden (nötig zum Spulen)."""
            try:
                size = os.path.getsize(path)
                f = open(path, "rb")
            except OSError:
                return self.not_found()
            with f:
                start, end = 0, size - 1
                status = 200
                rng = self.headers.get("Range")
                if rng:
                    m = re.match(r"bytes=(\d*)-(\d*)", rng.strip())
                    if m:
                        a, b = m.groups()
                        if a == "" and b != "":
                            start = max(0, size - int(b))
                        else:
                            start = int(a or 0)
                            if b:
                                end = min(int(b), size - 1)
                        if start >= size or start > end:
                            self.send_response(416)
                            self.send_header("Content-Range", f"bytes */{size}")
                            self.send_header("Content-Length", "0")
                            self.end_headers()
                            return
                        status = 206
                length = end - start + 1
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(length))
                self.send_header("Cache-Control", "no-cache")
                if status == 206:
                    self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
                self.end_headers()
                if self.command == "HEAD":
                    return
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)

        # ---- POST
        def do_POST(self):
            if not self._host_ok() or self.headers.get("X-Token") != app.token:
                return self.send_json({"error": "verboten"}, 403)
            try:
                body = self.read_body()
                self._post(urlparse(self.path).path, body)
            except (ConnectionError, BrokenPipeError):
                pass
            except Exception:
                log.exception("Fehler bei POST %s", self.path)
                try:
                    self.send_json({"error": "Interner Fehler"}, 500)
                except Exception:
                    pass

        def _post(self, path, b):
            store, lib = app.store, app.lib
            if path == "/api/heartbeat":
                app.last_beat = time.time()
                app.had_beat = True
                app.bye_at = None
                return self.send_json({"ok": True, "status": lib.status, "cloud": app.cloud.public()})
            if path == "/api/bye":
                app.bye_at = time.time()
                store.flush()
                return self.send_json({"ok": True})
            if path == "/api/progress":
                iid = b.get("id")
                if not lib.get(iid):
                    return self.send_json({"error": "unbekannt"}, 404)
                pos = float(b.get("pos") or 0)
                dur = float(b.get("duration") or 0) or lib.get(iid)["duration"]
                kw = {"pos": round(pos, 2), "updated": time.time(), "changed_ms": int(time.time() * 1000)}
                if dur and pos >= dur - 20:
                    kw["finished"] = True
                store.update_item(iid, **kw)
                store.settings["last_item"] = iid
                if b.get("flush"):
                    store.flush()
                    store.save_settings()
                return self.send_json({"ok": True})
            if path == "/api/flags":
                ids = b.get("ids") if isinstance(b.get("ids"), list) else [b.get("id")]
                done = []
                for iid in ids:
                    it = lib.get(iid)
                    if not it:
                        continue
                    kw = {}
                    if "fav" in b:
                        kw["fav"] = True if b["fav"] else None
                    if "archived" in b:
                        kw["archived"] = True if b["archived"] else None
                        if b["archived"]:
                            kw["fav"] = None
                    if "kind" in b:
                        kw["kind"] = b["kind"] if b["kind"] in ("book", "podcast") else None
                    if "finished" in b:
                        if b["finished"]:
                            kw["finished"] = True
                            kw["pos"] = it["duration"]
                        else:
                            kw["finished"] = None
                            kw["pos"] = 0
                        kw["updated"] = time.time()
                    kw["changed_ms"] = int(time.time() * 1000)
                    store.update_item(iid, **kw)
                    done.append(app.light(it))
                store.flush()
                if "ids" in b:
                    return self.send_json({"items": done})
                if not done:
                    return self.send_json({"error": "unbekannt"}, 404)
                return self.send_json(done[0])
            if path == "/api/bookmark":
                iid = b.get("id")
                if not lib.get(iid):
                    return self.send_json({"error": "unbekannt"}, 404)
                st = store.item(iid, create=True)
                bms = st.setdefault("bookmarks", [])
                act = b.get("action")
                now = int(time.time() * 1000)
                if act == "add":
                    bms.append({"id": uuid.uuid4().hex[:10], "pos": round(float(b.get("pos") or 0), 2),
                                "note": str(b.get("note") or "")[:500], "created": time.time(), "changed_ms": now})
                    bms.sort(key=lambda x: x["pos"])
                elif act == "delete":
                    for x in bms:
                        if x["id"] == b.get("bid"):
                            x.update(deleted=True, changed_ms=now)
                elif act == "edit":
                    for x in bms:
                        if x["id"] == b.get("bid"):
                            x.update(note=str(b.get("note") or "")[:500], changed_ms=now)
                store.mark_dirty()
                store.flush()
                return self.send_json({"bookmarks": visible_bookmarks(st)})
            if path == "/api/settings":
                s = store.settings
                rescan = False
                for k in ("folders", "podcast_folders"):
                    if k in b and isinstance(b[k], list):
                        new = [str(x).strip() for x in b[k] if str(x).strip()]
                        if new != s.get(k):
                            s[k] = new
                            rescan = True
                if "recursive" in b and bool(b["recursive"]) != s.get("recursive"):
                    s["recursive"] = bool(b["recursive"])
                    rescan = True
                for k in ("theme", "view", "sort"):
                    if k in b and isinstance(b[k], str):
                        s[k] = b[k]
                if "music" in b:
                    s["music"] = bool(b["music"])
                for k in ("speed", "volume"):
                    if k in b:
                        try:
                            s[k] = float(b[k])
                        except (TypeError, ValueError):
                            pass
                for k in ("skip_back", "skip_fwd"):
                    if k in b:
                        try:
                            s[k] = max(5, min(300, int(b[k])))
                        except (TypeError, ValueError):
                            pass
                store.save_settings()
                if rescan:
                    lib.start_scan()
                return self.send_json({"settings": s, "rescan": rescan})
            if path == "/api/open":
                p = str(b.get("path") or "")
                if p and os.path.isfile(p):
                    app.pending_open = p
                    return self.send_json({"ok": True})
                return self.send_json({"ok": False}, 404)
            if path == "/api/pending":
                p = app.pending_open
                if not p:
                    return self.send_json({})
                iid = lib.find_or_add_file(p)
                if iid is None:
                    return self.send_json({"wait": True})
                app.pending_open = None
                if not iid:
                    return self.send_json({"error": f"Datei konnte nicht gelesen werden: {os.path.basename(p)}"})
                return self.send_json({"id": iid})
            if path == "/api/cloud":
                return self.send_json(app.cloud.public())
            if path == "/api/musik/token":
                # Apple-Music-Zugang: das Token stellt player.menet.ch aus (der Schlüssel bleibt dort)
                if not app.cloud.token:
                    return self.send_json({"error": "Für Apple Music zuerst in den Einstellungen mit player.menet.ch verbinden."})
                try:
                    return self.send_json(app.cloud.music_token())
                except Exception as e:
                    return self.send_json({"error": str(e)})
            if path == "/api/cloud/pair":
                try:
                    return self.send_json(app.cloud.pair(str(b.get("code") or "")))
                except Exception as e:
                    return self.send_json({"error": str(e)}, 400)
            if path == "/api/cloud/unpair":
                return self.send_json(app.cloud.unpair())
            if path == "/api/cloud/sync":
                return self.send_json(app.cloud.sync())
            if path == "/api/cloud/upload":
                ids = [i for i in (b.get("ids") or []) if lib.get(i)]
                n = app.cloud.enqueue(ids)
                return self.send_json({"added": n} | app.cloud.public())
            if path == "/api/cloud/cancel":
                app.cloud.cancel_uploads()
                return self.send_json(app.cloud.public())
            if path == "/api/cloud/delete":
                try:
                    ok = app.cloud.delete_remote(b.get("id"))
                    return self.send_json({"ok": ok} | app.cloud.public())
                except Exception as e:
                    return self.send_json({"error": str(e)}, 400)
            if path == "/api/update/check":
                return self.send_json(app.updater.check(force=bool(b.get("force"))))
            if path == "/api/update/apply":
                store.settings["resume_play"] = VERSION if b.get("playing") else None
                store.flush(force=True)
                store.save_settings()
                ok, msg = app.updater.apply(lambda: app.quit_event.set())
                if not ok:
                    store.settings.pop("resume_play", None)
                return self.send_json({"ok": ok, "error": msg, "update": app.updater.public()})
            if path == "/api/rescan":
                lib.start_scan()
                return self.send_json({"ok": True})
            if path == "/api/pickfolder":
                return self.send_json({"path": pick_folder(b.get("title") or "Ordner wählen", b.get("start") or "")})
            if path == "/api/reveal":
                it = lib.get(b.get("id"))
                if it and sys.platform == "win32":
                    target = it["tracks"][0]["path"] if not it["folder"] else it["path"]
                    subprocess.Popen(["explorer", "/select,", os.path.normpath(target)])
                return self.send_json({"ok": bool(it)})
            if path == "/api/fenster":
                # Mini-Player: grosses Fenster verkleinern bzw. wieder nach vorne holen
                from . import fenster
                a = str(b.get("aktion") or "")
                ok = fenster.minimieren() if a == "minimieren" else fenster.nach_vorne() if a == "vorne" else False
                return self.send_json({"ok": ok})
            if path == "/api/opendata":
                if sys.platform == "win32":
                    os.startfile(store.dir)
                return self.send_json({"ok": True})
            return self.not_found()

    return Handler


def pick_folder(title, start):
    """Öffnet den Windows-Ordnerdialog (über tkinter in eigenem Prozess)."""
    fd, out = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    try:
        exe = sys.executable
        if exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
            exe = exe[:-10] + "pythonw.exe"
        r = subprocess.run([exe, "-c", PICK_SCRIPT, out, title, start if os.path.isdir(start or "") else ""],
                           timeout=600, creationflags=NO_WINDOW, capture_output=True)
        if r.returncode != 0:
            log.warning("Ordnerdialog: %s", r.stderr.decode("utf-8", "replace")[-500:])
            return None
        with open(out, "r", encoding="utf-8") as f:
            p = f.read().strip()
        return os.path.normpath(p) if p else ""
    except Exception as e:
        log.warning("Ordnerdialog fehlgeschlagen: %s", e)
        return None
    finally:
        try:
            os.remove(out)
        except OSError:
            pass


def start_server(app, port):
    handler = make_handler(app)
    for p in [port] + [0]:
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", p), handler)
            break
        except OSError:
            continue
    httpd.daemon_threads = True
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, httpd.server_address[1]
