"""Das grosse Player-Fenster (Edge-App-Fenster mit Titel «MyPlayer …») finden, nach vorne holen oder verkleinern.

Der Mini-Player ist ein eigenes kleines Fenster, das immer im Vordergrund bleibt (gleicher Titel) –
es wird hier übersprungen, damit immer das grosse Fenster gemeint ist.
"""
import logging
import sys

from . import APP_NAME

log = logging.getLogger(__name__)

GWL_EXSTYLE = -20
WS_EX_TOPMOST = 0x0008
SW_MINIMIZE = 6
SW_RESTORE = 9


def _main_window():
    if sys.platform != "win32":
        return None, None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []
    proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.startswith(APP_NAME) and not (user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST):
                    found.append(hwnd)
                    return False
        return True
    user32.EnumWindows(proto(cb), 0)
    return user32, (found[0] if found else None)


def _mini_window(user32):
    """Das Mini-Player-Fenster: von Edge, «immer zuoberst», Titel MyPlayer oder Adresse des Players."""
    import ctypes
    from ctypes import wintypes
    found = []
    proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd) and (user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST):
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            cls = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, cls, 64)
            t = buf.value
            if cls.value.startswith("Chrome_WidgetWin") and (t.startswith(APP_NAME) or "127.0.0.1" in t):
                found.append(hwnd)
                return False
        return True
    user32.EnumWindows(proto(cb), 0)
    return found[0] if found else None


def mini_platzieren(breite=440, hoehe=200, rand=16):
    """Mini-Player auf seine Grösse bringen und unten rechts über die Taskleiste setzen.
    (Edge übernimmt sonst die Grösse des grossen Fensters.) Masse in «normalen» Pixeln, werden mit der Bildschirm-Skalierung umgerechnet."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        import time
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        try:
            user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))   # echte Bildschirm-Pixel
        except Exception:
            pass
        h = None
        for _ in range(20):                    # das Fenster erscheint erst nach einem Moment
            h = _mini_window(user32)
            if h:
                break
            time.sleep(0.1)
        if not h:
            return False
        try:
            f = user32.GetDpiForWindow(h) / 96.0 or 1.0
        except Exception:
            f = 1.0
        area = wintypes.RECT()
        user32.SystemParametersInfoW(0x30, 0, ctypes.byref(area), 0)   # SPI_GETWORKAREA: Bildschirm ohne Taskleiste
        w, hh, m = int(breite * f), int(hoehe * f), int(rand * f)
        x, y = area.right - w - m, area.bottom - hh - m
        user32.SetWindowPos(h, wintypes.HWND(-1), x, y, w, hh, 0x0010 | 0x0040)   # zuoberst, nicht aktivieren, zeigen
        return True
    except Exception as e:
        log.warning("Mini-Player platzieren fehlgeschlagen: %s", e)
        return False


def nach_vorne():
    """Grosses Fenster wiederherstellen und nach vorne holen."""
    try:
        user32, h = _main_window()
        if not h:
            return False
        if user32.IsIconic(h):
            user32.ShowWindow(h, SW_RESTORE)
        user32.SetForegroundWindow(h)
        return True
    except Exception as e:
        log.warning("Fenster nach vorne holen fehlgeschlagen: %s", e)
        return False


def minimieren():
    """Grosses Fenster in die Taskleiste (der Mini-Player bleibt sichtbar)."""
    try:
        user32, h = _main_window()
        if not h:
            return False
        user32.ShowWindow(h, SW_MINIMIZE)
        return True
    except Exception as e:
        log.warning("Fenster verkleinern fehlgeschlagen: %s", e)
        return False
