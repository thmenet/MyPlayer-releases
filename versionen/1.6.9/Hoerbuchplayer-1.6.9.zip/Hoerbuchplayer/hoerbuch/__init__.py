VERSION = "1.6.9"
APP_NAME = "MyPlayer"
