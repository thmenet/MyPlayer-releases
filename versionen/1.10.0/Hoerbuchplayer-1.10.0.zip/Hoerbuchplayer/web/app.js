/* MyPlayer – Oberfläche */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const SPEEDS = [0.7, 1.0, 1.2, 1.5, 1.7, 2.0];
const SKIP = 30;

const S = {
  settings: {}, items: [], byId: {},
  kind: "book", fav: false, arch: false, q: "", view: "library",
  scanning: false, dataDir: "", openShows: new Set(), showPick: {}, sel: new Set(), selAnchor: null,
};

/* ---------------- Hilfsfunktionen ---------------- */
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function icon(id, cls = "") { return `<svg class="${cls}"><use href="#i-${id}"/></svg>`; }
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.round(sec % 3600 / 60);
  if (h && m === 60) return `${h + 1} h`;
  if (h) return m ? `${h} h ${m} min` : `${h} h`;
  if (sec < 60) return `${sec} s`;
  return `${Math.max(1, m)} min`;
}
function fmtSpeed(v) { return (Math.round(v * 10) / 10).toFixed(1).replace(/\.0$/, ".0") + "×"; }
function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }
function pct(it) { if (it.finished) return 100; return it.duration ? Math.min(100, it.pos / it.duration * 100) : 0; }
function coverHTML(it, big = false, phIcon = null) {
  const ic = phIcon || (it && it.kind === "podcast" ? "mic" : "book");
  if (it && it.cover) return `<img loading="lazy" src="/cover/${it.cover}${big ? "?big=1" : ""}" alt="" onerror="this.remove()"><div class="ph" style="z-index:-1">${icon(ic)}</div>`;
  return `<div class="ph">${icon(ic)}</div>`;
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  if (!r.ok) {   // Meldung des Programms zeigen statt nur der Nummer
    let msg = `${path}: ${r.status}`;
    try { const j = await r.json(); if (j && j.error) msg = j.error; } catch (e) { }
    throw new Error(msg);
  }
  return r.json();
}
function toast(msg, action, fn, ms = 4200) {
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `<span>${esc(msg)}</span>${action ? `<button>${esc(action)}</button>` : ""}`;
  if (action) el.querySelector("button").onclick = () => { fn(); el.remove(); };
  $("#toasts").append(el);
  setTimeout(() => el.remove(), ms);
}

/* ---------------- Bibliothek ---------------- */
async function loadLibrary() {
  const d = await api("/api/library");
  S.items = d.items;
  S.byId = Object.fromEntries(d.items.map(i => [i.id, i]));
  if (P.item && S.byId[P.item.id]) {
    const li = S.byId[P.item.id];
    if (P.playing || P.wantPlay) li.pos = P.pos();          // laufender Titel: Position kommt vom Player
    else if (Math.abs(li.pos - P.pos()) > 5) P.seek(li.pos, false);   // anderswo weitergehört (player.menet.ch)
  }
  setScan(d.status);
  renderLibrary();
}

function setScan(st) {
  const was = S.scanning;
  S.scanning = !!st.running;
  $("#scanInfo").hidden = !S.scanning;
  if (S.scanning) $("#scanText").textContent = st.total ? `Lese Bibliothek … ${st.done} / ${st.total}` : "Suche Dateien …";
  if (was && !S.scanning) loadLibrary();
}

function visibleItems() {
  const q = norm(S.q).trim();
  let list = S.items.filter(i => {
    if (S.arch ? !i.archived : i.archived) return false;
    if (S.fav && !i.fav) return false;
    if (S.kind !== "all" && i.kind !== S.kind) return false;
    if (q) {
      const hay = norm([i.title, i.author, i.narrator, i.show, i.genre].join(" "));
      if (!q.split(/\s+/).every(w => hay.includes(w))) return false;
    }
    return true;
  });
  const sort = S.settings.sort || "recent";
  const byTitle = (a, b) => a.title.localeCompare(b.title, "de", { numeric: true, sensitivity: "base" });
  const cmp = {
    recent: (a, b) => (b.updated || 0) - (a.updated || 0) || byTitle(a, b),
    title: byTitle,
    author: (a, b) => (a.author || "~").localeCompare(b.author || "~", "de", { sensitivity: "base" }) || byTitle(a, b),
    added: (a, b) => (b.added || 0) - (a.added || 0),
    duration: (a, b) => (b.duration || 0) - (a.duration || 0),
    progress: (a, b) => pct(b) - pct(a) || byTitle(a, b),
  }[sort] || byTitle;
  return list.sort(cmp);
}

function metaLine(it) {
  if (it.finished) return `<span class="okc">Gehört</span><span>·</span><span>${fmtDur(it.duration)}</span>`;
  if (it.pos > 5) return `<span class="acc">${Math.floor(pct(it))} %</span><span>·</span><span>noch ${fmtDur(it.duration - it.pos)}</span>`;
  return `<span>${fmtDur(it.duration)}</span>`;
}

function cardHTML(it) {
  const p = pct(it);
  const playing = P.item && P.item.id === it.id;
  return `<div class="card${playing ? " playing" : ""}${S.sel.has(it.id) ? " selected" : ""}" tabindex="0" data-id="${it.id}">
    <div class="cv">${coverHTML(it)}${it.cover ? "" : `<div class="ph-t">${esc(it.title)}</div>`}
      <div class="hover"></div>
      <button class="sel-o" data-act="select" title="Auswählen (oder Strg + Klick)">${icon("check")}</button>
      <div class="badges">${playing ? `<span class="bdg now">${P.playing ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("pause")}</span>` : ""}${it.fav ? `<span class="bdg fav">${icon("heart-f")}</span>` : ""}${it.finished ? `<span class="bdg done">${icon("check")}</span>` : ""}${it.on_server ? `<span class="bdg cloud" title="Auf player.menet.ch">${icon("cloud")}</span>` : ""}</div>
      <button class="play-o" data-act="play" title="Abspielen">${icon("play")}</button>
      <button class="more-o" data-act="menu" title="Mehr">${icon("more")}</button>
      ${p > 0 && !it.finished ? `<div class="bar"><i style="width:${p}%"></i></div>` : ""}
    </div>
    <div class="t" title="${esc(it.title)}">${esc(it.title)}</div>
    <div class="a">${esc(it.author || it.show || "")}</div>
    <div class="m">${metaLine(it)}</div>
  </div>`;
}

function rowHTML(it, inShow = false) {
  const p = pct(it);
  const playing = P.item && P.item.id === it.id;
  const sub = inShow ? (it.date ? esc(String(it.date).slice(0, 10)) : "") : esc(it.author || it.show || "");
  const fresh = inShow && !it.finished && it.pos < 5;
  return `<div class="row${playing ? " playing" : ""}${S.sel.has(it.id) ? " selected" : ""}" data-id="${it.id}">
    <div class="rc">${coverHTML(it)}<button class="sel-o" data-act="select" title="Auswählen (oder Strg + Klick)">${icon("check")}</button></div>
    <div class="rt"><b title="${esc(it.title)}">${fresh ? '<i class="ep-new" title="Noch nicht gehört"></i>' : ""}${esc(it.title)}</b><span>${sub}</span></div>
    ${inShow ? "" : `<div class="ra">${esc(it.narrator ? "Gelesen von " + it.narrator : it.kind === "podcast" ? "Podcast" : (it.nchapters > 1 ? it.nchapters + " Kapitel" : ""))}</div>`}
    <div class="rp">${it.finished ? `<span class="okc" style="color:var(--ok);font-weight:600">${icon("check")}</span><span>Gehört</span>` : `<div class="pb"><i style="width:${p}%"></i></div><span>${Math.floor(p)} %</span>`}</div>
    <div class="rd">${fmtDur(it.duration)}</div>
    <div class="rb"><button class="icon-btn${it.fav ? " fav-on" : ""}" data-act="fav" title="Favorit">${icon(it.fav ? "heart-f" : "heart")}</button><button class="icon-btn" data-act="menu" title="Mehr">${icon("more")}</button></div>
  </div>`;
}

function renderLibrary() {
  _renderLibrary();
  if (S.sel.size) { const vis = new Set(domIds()); for (const id of [...S.sel]) if (!vis.has(id)) S.sel.delete(id); }
  refreshSel();
}
function _renderLibrary() {
  const body = $("#libBody"), head = $("#libHead");
  if (S.kind === "music") { renderMusicArea(body, head); return; }
  const noFolders = !(S.settings.folders || []).length;
  if (noFolders) {
    head.innerHTML = "";
    body.innerHTML = `<div class="empty"><div class="big">${icon("headphones")}</div><h2>Willkommen!</h2>
      <p>Wähle den Ordner, in dem deine Hörbücher liegen (z.&nbsp;B. den Libation-Ordner). Du kannst später weitere Ordner und Podcast-Ordner hinzufügen.</p>
      <button class="btn primary" id="firstFolder">${icon("folder")}Ordner wählen</button></div>`;
    $("#firstFolder").onclick = async () => {
      const p = await pickFolder("Hörbuch-Ordner wählen");
      if (p) { await saveSettings({ folders: [p] }); toast("Bibliothek wird eingelesen …"); }
    };
    return;
  }
  const items = visibleItems();
  const names = { book: "Hörbücher", podcast: "Podcasts", all: "Alle Titel" };
  let title = S.arch ? "Archiv" : S.fav ? "Favoriten" : names[S.kind];
  if (S.arch && S.kind !== "all") title += ` · ${names[S.kind]}`;
  if (S.fav && !S.arch && S.kind !== "all") title += ` · ${names[S.kind]}`;
  const total = items.reduce((a, i) => a + (i.duration || 0), 0);
  head.innerHTML = `<h2>${esc(title)}</h2><span class="sub">${items.length} ${items.length === 1 ? "Titel" : "Titel"}${items.length ? " · " + fmtDur(total) : ""}</span>`;

  if (!items.length) {
    let msg = S.scanning ? "Die Bibliothek wird gerade eingelesen …" : "Hier ist (noch) nichts.";
    if (S.q) msg = `Nichts gefunden für «${esc(S.q)}».`;
    else if (S.arch) msg = "Im Archiv liegt noch nichts. Fertig gehörte Titel kannst du über das Menü (⋯) archivieren.";
    else if (S.fav) msg = "Noch keine Favoriten. Markiere Titel mit dem Herz, um sie dir für später zu merken.";
    else if (S.kind === "podcast") msg = "Keine Podcasts gefunden. In den Einstellungen kannst du Ordner als Podcast-Ordner markieren.";
    body.innerHTML = `<div class="empty"><div class="big">${icon(S.arch ? "archive" : S.fav ? "heart" : "search")}</div><p>${msg}</p></div>`;
    return;
  }

  if (S.kind === "podcast" && !S.q) {
    // nach Sendung gruppieren
    const groups = new Map();
    for (const it of items) {
      const k = it.show || "Ohne Sendung";
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(it);
    }
    // Älteste zuerst (Folge 1 oben): Datum, dann Titel mit Zahlen in richtiger Reihenfolge (#2 vor #10), dann Dateidatum
    const epSort = (a, b) => String(a.date || "").localeCompare(String(b.date || "")) ||
      a.title.localeCompare(b.title, "de", { numeric: true, sensitivity: "base" }) || (a.added - b.added);
    let html = "";
    const keys = [...groups.keys()].sort((a, b) => {
      const ra = Math.max(...groups.get(a).map(i => i.updated || 0)), rb = Math.max(...groups.get(b).map(i => i.updated || 0));
      return rb - ra || a.localeCompare(b, "de");
    });
    S.showPick = {};
    for (const k of keys) {
      const eps = groups.get(k).sort(epSort);
      const coverIt = eps.find(e => e.cover) || eps[0];
      const started = eps.filter(e => !e.finished && e.pos > 5);
      const fresh = eps.filter(e => !e.finished && e.pos <= 5).length;
      const last = [...eps].filter(e => e.updated).sort((a, b) => b.updated - a.updated)[0];
      // "Weiterhören": zuletzt angefangene Folge, sonst neueste ungehörte
      const pick = started.sort((a, b) => (b.updated || 0) - (a.updated || 0))[0] || eps.find(e => !e.finished) || eps[0];
      S.showPick[k] = pick.id;
      const isOpen = S.openShows.has(k);
      const playingHere = P.item && eps.some(e => e.id === P.item.id);
      const parts = [`${eps.length} ${eps.length === 1 ? "Folge" : "Folgen"}`];
      if (fresh) parts.push(`${fresh} ungehört`);
      if (started.length) parts.push(`${started.length} angefangen`);
      if (!fresh && !started.length) parts.push("alle gehört");
      const kk = esc(k);
      html += `<section class="show${isOpen ? " open" : ""}${playingHere ? " playing" : ""}">
        <div class="show-h" data-show="${kk}" title="${isOpen ? "Zuklappen" : "Aufklappen"}">
          <div class="sc">${coverHTML(coverIt, false, "mic")}</div>
          <div class="show-t"><h3>${kk}</h3><div class="sub">${parts.join(" · ")}</div>
            ${last ? `<div class="last">Zuletzt: ${esc(last.title)}</div>` : ""}</div>
          <button class="pill show-play" data-showplay="${kk}" title="${esc(pick.title)}">${icon("play")}${started.length ? "Weiterhören" : "Neueste Folge"}</button>
          <span class="chev">${icon("chev-up")}</span>
        </div>
        ${isOpen ? `<div class="list">${eps.map(e => rowHTML(e, true)).join("")}</div>` : ""}</section>`;
    }
    body.innerHTML = html;
  } else if ((S.settings.view || "grid") === "list") {
    body.innerHTML = `<div class="list-head"><span></span><span>Titel</span><span class="ra">Info</span><span>Fortschritt</span><span class="r rd">Dauer</span><span></span></div>
      <div class="list">${items.map(i => rowHTML(i)).join("")}</div>`;
  } else {
    body.innerHTML = `<div class="grid">${items.map(cardHTML).join("")}</div>`;
  }
}

function libClick(e) {
  const sp = e.target.closest("[data-showplay]");
  if (sp) { e.stopPropagation(); const id = S.showPick[sp.dataset.showplay]; if (id) openItem(id, true); return; }
  const sh = e.target.closest("[data-show]");
  if (sh) {
    const k = sh.dataset.show;
    if (S.openShows.has(k)) S.openShows.delete(k); else S.openShows.add(k);
    renderLibrary(); return;
  }
  const el = e.target.closest("[data-id]");
  if (!el) return;
  const id = el.dataset.id;
  const act = e.target.closest("[data-act]")?.dataset.act;
  if (act === "menu") { e.stopPropagation(); return itemMenu(id, e.target.closest("[data-act]")); }
  if (act === "fav") { e.stopPropagation(); return setFlags(id, { fav: !S.byId[id].fav }); }
  // Auswahl: Häkchen, Strg+Klick, Umschalt+Klick – oder normaler Klick, sobald schon etwas ausgewählt ist
  if (e.shiftKey && S.selAnchor) { e.preventDefault(); return selectRange(id); }
  if (act === "select" || e.ctrlKey || e.metaKey || (S.sel.size && act !== "play")) return toggleSel(id);
  openItem(id, true);
}

/* ---------------- Mehrfachauswahl ---------------- */
function domIds() { return $$("#libBody [data-id]").map(el => el.dataset.id); }
function toggleSel(id) {
  if (S.sel.has(id)) S.sel.delete(id); else S.sel.add(id);
  S.selAnchor = id;
  refreshSel();
}
function selectRange(id) {
  const ids = domIds(), a = ids.indexOf(S.selAnchor), b = ids.indexOf(id);
  if (a < 0 || b < 0) return toggleSel(id);
  for (const x of ids.slice(Math.min(a, b), Math.max(a, b) + 1)) S.sel.add(x);
  refreshSel();
}
function clearSel() { S.sel.clear(); S.selAnchor = null; refreshSel(); }
function refreshSel() {
  $$("#libBody [data-id]").forEach(el => el.classList.toggle("selected", S.sel.has(el.dataset.id)));
  const n = S.sel.size, bar = $("#selBar");
  document.body.classList.toggle("has-sel", n > 0);
  $("#libBody").classList.toggle("selecting", n > 0);
  if (!n) { bar.hidden = true; return; }
  bar.hidden = false;
  $("#selCount").textContent = `${n} ausgewählt`;
}
function selMenuEntries() {
  const ids = [...S.sel];
  const allFav = ids.every(i => S.byId[i]?.fav), allArch = ids.every(i => S.byId[i]?.archived);
  return [
    { label: `${ids.length} Titel ausgewählt` },
    { icon: "mic", text: "Als Podcast markieren", fn: () => bulk({ kind: "podcast" }) },
    { icon: "book", text: "Als Hörbuch markieren", fn: () => bulk({ kind: "book" }) },
    { icon: "refresh", text: "Art automatisch bestimmen", fn: () => bulk({ kind: "auto" }) },
    "-",
    { icon: allFav ? "heart-f" : "heart", text: allFav ? "Aus Favoriten entfernen" : "Zu Favoriten", fn: () => bulk({ fav: !allFav }) },
    { icon: "archive", text: allArch ? "Aus dem Archiv holen" : "Ins Archiv verschieben", fn: () => bulk({ archived: !allArch }) },
    { icon: "check", text: "Als gehört markieren", fn: () => bulk({ finished: true }) },
    ...(S.cloud && S.cloud.connected && S.cloud.admin ? [{ icon: "cloud-up", text: "Auf player.menet.ch hochladen", fn: () => { const ids = [...S.sel]; clearSel(); cloudUpload(ids); } }] : []),
    "-",
    { icon: "x", text: "Auswahl aufheben", fn: clearSel },
  ];
}
async function bulk(flags) {
  const ids = [...S.sel];
  if (!ids.length) return;
  const prev = ids.map(i => ({ id: i, kind: S.byId[i]?.kind, manual: S.byId[i]?.kind_manual }));
  const d = await api("/api/flags", { ids, ...flags });
  for (const u of d.items) { if (S.byId[u.id]) Object.assign(S.byId[u.id], u); if (P.item && P.item.id === u.id) { Object.assign(P.item, u); renderPlayerMeta(); } }
  const n = d.items.length;
  const what = "kind" in flags ? (flags.kind === "podcast" ? "gelten jetzt als Podcast" : flags.kind === "book" ? "gelten jetzt als Hörbuch" : "werden wieder automatisch eingeordnet")
    : "fav" in flags ? (flags.fav ? "sind jetzt Favoriten" : "sind keine Favoriten mehr")
    : "archived" in flags ? (flags.archived ? "sind jetzt im Archiv" : "sind wieder in der Bibliothek")
    : "sind als gehört markiert";
  clearSel();
  renderLibrary();
  if ("archived" in flags || "kind" in flags) toast(`${n} Titel ${what}.`, "Rückgängig", async () => {
    const back = "archived" in flags ? { archived: !flags.archived } : null;
    if (back) { await api("/api/flags", { ids, ...back }); }
    else { // Art einzeln zurücksetzen auf vorherigen Zustand
      for (const it of prev) await api("/api/flags", { id: it.id, kind: it.manual ? it.kind : "auto" });
    }
    await loadLibrary();
  }, 7000);
  else toast(`${n} Titel ${what}.`);
}

/* ---------------- Touch: lange drücken = auswählen ---------------- */
// Auf dem Handy öffnet ein Antippen das Buch; ca. eine halbe Sekunde gedrückt halten startet die Auswahl (wie beim iPhone üblich).
const LONGPRESS_MS = 550;
let lp = null, lpFired = false;
function bindLongPress() {
  const body = $("#libBody");
  body.addEventListener("pointerdown", e => {
    if (e.pointerType === "mouse") return;
    const el = e.target.closest("[data-id]");
    if (!el || e.target.closest("[data-act=menu],[data-act=fav],[data-showplay]")) return;
    lpFired = false;
    lp = { x: e.clientX, y: e.clientY, t: setTimeout(() => {
      lpFired = true; lp = null;
      if (!S.sel.has(el.dataset.id)) toggleSel(el.dataset.id);
      try { navigator.vibrate && navigator.vibrate(15); } catch (err) { }
      if (S.sel.size === 1) toast("Auswahl: weitere Titel antippen. Fertig mit ✕ unten.", null, null, 3500);
    }, LONGPRESS_MS) };
  });
  const cancel = () => { if (lp) { clearTimeout(lp.t); lp = null; } };
  body.addEventListener("pointermove", e => { if (lp && Math.hypot(e.clientX - lp.x, e.clientY - lp.y) > 10) cancel(); });
  body.addEventListener("pointerup", cancel);
  body.addEventListener("pointercancel", cancel);
  // der Klick nach dem langen Drücken soll nicht gleich wieder abwählen oder das Buch öffnen
  body.addEventListener("click", e => { if (lpFired) { lpFired = false; e.stopPropagation(); e.preventDefault(); } }, true);
}

/* ---------------- Kontextmenü ---------------- */
function showMenu(entries, x, y) {
  const m = $("#menu");
  m.innerHTML = entries.map((en, i) => en === "-" ? "<hr>" : en.label && !en.fn ? `<div class="lbl">${esc(en.label)}</div>` :
    `<button data-i="${i}">${en.icon ? icon(en.icon) : '<svg></svg>'}<span>${esc(en.text)}</span>${en.checked ? icon("check", "chk") : ""}</button>`).join("");
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + "px";
  m.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
  m.onclick = ev => { const b = ev.target.closest("button"); if (!b) return; hideMenu(); entries[+b.dataset.i].fn(); };
}
function hideMenu() { $("#menu").hidden = true; }

function itemMenu(id, anchor, at) {
  const it = S.byId[id];
  if (!it) return;
  let x, y;
  if (at) { x = at.x; y = at.y; } else { const r = anchor.getBoundingClientRect(); x = r.left; y = r.bottom + 4; }
  const kindName = it.auto_kind === "book" ? "Hörbuch" : "Podcast";
  showMenu([
    { icon: "play", text: P.item && P.item.id === id ? (P.playing ? "Pause" : "Weiterhören") : (it.pos > 5 && !it.finished ? "Weiterhören" : "Abspielen"), fn: () => P.item && P.item.id === id ? togglePlay() : openItem(id, true) },
    { icon: "chapters", text: "Kapitel anzeigen", fn: () => openItem(id, false) },
    "-",
    { icon: it.fav ? "heart-f" : "heart", text: it.fav ? "Aus Favoriten entfernen" : "Zu Favoriten", fn: () => setFlags(id, { fav: !it.fav }) },
    { icon: "archive", text: it.archived ? "Aus dem Archiv holen" : "Ins Archiv verschieben", fn: () => setFlags(id, { archived: !it.archived }) },
    { icon: "check", text: it.finished ? "Als ungehört markieren (von vorne)" : "Als gehört markieren", fn: () => setFlags(id, { finished: !it.finished }) },
    "-",
    { label: "Art des Titels" },
    { icon: "book", text: "Hörbuch", checked: it.kind === "book" && it.kind_manual, fn: () => setFlags(id, { kind: "book" }) },
    { icon: "mic", text: "Podcast", checked: it.kind === "podcast" && it.kind_manual, fn: () => setFlags(id, { kind: "podcast" }) },
    { icon: "refresh", text: `Automatisch (${kindName}: ${it.kind_reason})`, checked: !it.kind_manual, fn: () => setFlags(id, { kind: "auto" }) },
    "-",
    { icon: "explorer", text: "Im Explorer zeigen", fn: () => api("/api/reveal", { id }) },
    ...(S.cloud && S.cloud.connected && S.cloud.admin ? ["-", it.on_server
      ? { icon: "cloud", text: "Vom Server entfernen …", fn: () => cloudDelete(id) }
      : { icon: "cloud-up", text: "Auf player.menet.ch hochladen", fn: () => cloudUpload([id]) }] : []),
  ], x, y);
}

async function setFlags(id, flags) {
  const it = S.byId[id];
  const upd = await api("/api/flags", { id, ...flags });
  Object.assign(it, upd);
  if (P.item && P.item.id === id) {
    Object.assign(P.item, upd);
    if ("finished" in flags) { P.seek(flags.finished ? P.total : 0, false); }
    renderPlayerMeta();
  }
  if ("archived" in flags) toast(flags.archived ? `«${it.title}» ist jetzt im Archiv.` : `«${it.title}» ist wieder in der Bibliothek.`, "Rückgängig", () => setFlags(id, { archived: !flags.archived }));
  if ("kind" in flags) toast(`«${it.title}» gilt jetzt als ${upd.kind === "book" ? "Hörbuch" : "Podcast"}.`);
  renderLibrary();
}

/* ---------------- Player-Kern ---------------- */
const audio = new Audio();
audio.preload = "auto";

const P = {
  item: null, tracks: [], chapters: [], total: 0, trackIdx: 0, pendingSeek: null,
  playing: false, wantPlay: false, lastSave: 0, loadingId: null,
  pos() {
    if (!this.item) return 0;
    const t = this.tracks[this.trackIdx];
    const local = this.pendingSeek != null ? this.pendingSeek : audio.currentTime || 0;
    return (t ? t.offset : 0) + local;
  },
  layout() { // Versätze der Dateien neu berechnen
    let off = 0;
    for (const t of this.tracks) { t.offset = off; off += t.duration; }
    this.total = off || this.item.duration;
    if (this.item.folder) this.chapters.forEach((c, i) => { c.start = this.tracks[i] ? this.tracks[i].offset : c.start; });
    this.chapters.forEach((c, i) => { c.end = i + 1 < this.chapters.length ? this.chapters[i + 1].start : this.total; });
  },
  chapterIdx(t = this.pos()) {
    let i = 0;
    for (let k = 0; k < this.chapters.length; k++) if (this.chapters[k].start <= t + 0.25) i = k;
    return i;
  },
  loadTrack(i, at, play) {
    this.trackIdx = i;
    this.pendingSeek = at;
    this.wantPlay = play;
    audio.src = `/media/${this.item.id}/${i}`;
    audio.load();
  },
  seek(t, play = this.playing || this.wantPlay) {
    if (!this.item) return;
    t = Math.max(0, Math.min(t, this.total - 0.5));
    let i = this.tracks.length - 1;
    for (let k = 0; k < this.tracks.length; k++) if (t < this.tracks[k].offset + this.tracks[k].duration) { i = k; break; }
    const local = t - this.tracks[i].offset;
    if (i !== this.trackIdx || !audio.src) this.loadTrack(i, local, play);
    else if (this.pendingSeek != null) this.pendingSeek = local;
    else audio.currentTime = local;
    updateUI(true);
    saveSoon();
  },
};

audio.addEventListener("loadedmetadata", () => {
  const t = P.tracks[P.trackIdx];
  if (t && isFinite(audio.duration) && audio.duration > 0 && Math.abs(audio.duration - t.duration) > 1) {
    t.duration = audio.duration; P.layout(); renderChapters(); renderTicks();
  }
  if (P.pendingSeek != null) { try { audio.currentTime = P.pendingSeek; } catch (e) { } }
  P.pendingSeek = null;
  applySpeed();
  if (P.wantPlay) audio.play().catch(err => { console.warn(err); P.wantPlay = false; updatePlayState(); });
});
audio.addEventListener("play", () => { P.playing = true; P.wantPlay = true; updatePlayState(); });
audio.addEventListener("pause", () => { P.playing = false; if (!audio.ended) P.wantPlay = false; updatePlayState(); saveProgress(); });
audio.addEventListener("timeupdate", () => { updateUI(); checkSleep(); if (P.playing && Date.now() - P.lastSave > 5000) saveProgress(); });
audio.addEventListener("ended", () => {
  if (P.trackIdx + 1 < P.tracks.length) { P.loadTrack(P.trackIdx + 1, 0, true); return; }
  P.playing = false; P.wantPlay = false;
  saveProgress(true, P.total);
  updatePlayState();
  const it = S.byId[P.item.id];
  if (it) { it.finished = true; it.pos = it.duration; renderLibrary(); }
  if (S.sleep && S.sleep.mode === "chapter") clearSleep();
  toast(`«${P.item.title}» fertig gehört.`, "Ins Archiv", () => setFlags(P.item.id, { archived: true }), 9000);
});
audio.addEventListener("error", () => {
  if (!audio.src || !P.item) return;
  const code = audio.error ? audio.error.code : 0;
  const why = code === 4 ? "Dieses Format kann nicht abgespielt werden." : "Die Datei konnte nicht geladen werden.";
  toast(`Fehler: ${why}`, null, null, 7000);
  P.playing = false; P.wantPlay = false; updatePlayState();
});

function applySpeed() { const s = S.settings.speed || 1; audio.defaultPlaybackRate = s; audio.playbackRate = s; }

async function saveProgress(flush = false, posOverride) {
  if (!P.item) return;
  if (sonosBook(P.item.id)) return;   // läuft auf Sonos: der Heimserver speichert den Stand
  P.lastSave = Date.now();
  const pos = posOverride ?? P.pos();
  const li = S.byId[P.item.id];
  if (li) { li.pos = pos; li.updated = Date.now() / 1000; if (pos < li.duration - 20 && li.finished && P.playing) li.finished = false; }
  try { await api("/api/progress", { id: P.item.id, pos, duration: P.total, flush }); } catch (e) { console.warn(e); }
}
const saveSoon = debounce(() => saveProgress(), 900);

async function openItem(id, play) {
  if (P.item && P.item.id === id) {
    if (play && !P.playing) togglePlay();
    showView("player");
    return;
  }
  if (P.item) { audio.pause(); await saveProgress(true); }
  P.loadingId = id;
  const it = await api("/api/item?id=" + encodeURIComponent(id));
  if (P.loadingId !== id) return;
  P.item = it;
  P.tracks = it.tracks.map(t => ({ duration: t.duration, offset: 0 }));
  P.chapters = it.chapters.map(c => ({ title: c.title, start: c.start }));
  P.layout();
  P.trackIdx = -1;
  let start = it.finished ? 0 : (it.pos || 0);
  if (start >= P.total - 3) start = 0;
  if (it.finished && play) { // neu anfangen
    setFlags(id, { finished: false }).catch(() => { });
  }
  renderPlayer();
  P.seek(start, play);
  showView(play || S.view === "player" ? "player" : "player");
  S.settings.last_item = id;
  renderLibrary();
}

function togglePlay() {
  if (!P.item) return;
  if (audio.paused) {
    if (P.trackIdx < 0 || !audio.src) { P.seek(P.pos(), true); return; }
    if (P.pos() >= P.total - 1) P.seek(0, true);
    P.wantPlay = true;
    audio.play().catch(e => console.warn(e));
  } else audio.pause();
}
function skip(d) { if (P.item) P.seek(P.pos() + d); }
function prevChapter() {
  if (!P.item) return;
  const t = P.pos(), i = P.chapterIdx(t);
  const ch = P.chapters[i];
  if (t - ch.start > 3 * (S.settings.speed || 1) || i === 0) P.seek(ch.start);
  else P.seek(P.chapters[i - 1].start);
}
function nextChapter() {
  if (!P.item) return;
  const i = P.chapterIdx();
  if (i + 1 < P.chapters.length) P.seek(P.chapters[i + 1].start);
}

/* ---------------- Player-Ansicht ---------------- */
function showView(v) {
  S.view = v;
  document.body.classList.toggle("view-player", v === "player");
  $("#libView").hidden = v !== "library";
  $("#playerView").hidden = v !== "player";
  $("#mini").hidden = !(v === "library" && P.item);
  musicBar();
  if (v === "player") scrollToCurrentChapter(true);
}

function renderPlayer() {
  const it = P.item;
  $("#plCover").innerHTML = coverHTML(it, true);
  $("#plBg").style.backgroundImage = it.cover ? `url(/cover/${it.cover})` : "none";
  $("#miniCover").innerHTML = coverHTML(it);
  $("#miniTitle").textContent = it.title;
  renderPlayerMeta();
  renderChapters();
  renderBookmarks();
  renderTicks();
  updateMediaSession();
  updateUI(true);
}
function renderPlayerMeta() {
  const it = P.item;
  $("#plKind").textContent = it.kind === "podcast" ? (it.show ? "Podcast · " + it.show : "Podcast") : "Hörbuch";
  $("#plTitle").textContent = it.title;
  const by = [it.author, it.narrator ? "gelesen von " + it.narrator : ""].filter(Boolean).join(" · ");
  $("#plAuthor").textContent = by;
  $("#plFav").classList.toggle("on", !!it.fav);
  $("#plFav").innerHTML = icon(it.fav ? "heart-f" : "heart");
}
function renderChapters() {
  const ol = $("#chapterList");
  $("#chCount").textContent = P.chapters.length;
  ol.innerHTML = P.chapters.map((c, i) => `<li data-i="${i}"><span class="n">${i + 1}</span><span class="ct" title="${esc(c.title)}">${esc(c.title)}</span><span class="cd">${fmtClock(c.end - c.start)}</span><span class="cp" style="width:0"></span></li>`).join("");
  P._lastCh = -1;
}
function renderTicks() {
  const el = $("#ticks");
  if (!P.item || P.chapters.length < 2 || P.chapters.length > 150) { el.innerHTML = ""; return; }
  el.innerHTML = P.chapters.slice(1).map(c => `<i style="left:calc(7px + (100% - 14px) * ${c.start / P.total})"></i>`).join("");
}
function renderBookmarks() {
  const bms = P.item.bookmarks || [];
  $("#bmCount").textContent = bms.length || "";
  const ul = $("#bookmarkList");
  if (!bms.length) { ul.innerHTML = `<li class="side-empty" style="display:block;cursor:default">Noch keine Lesezeichen.<br>Mit <kbd>B</kbd> oder dem Knopf oben setzt du eins an der aktuellen Stelle.</li>`; return; }
  ul.innerHTML = bms.map(b => {
    const ch = P.chapters[P.chapterIdx(b.pos)];
    return `<li data-bid="${b.id}" data-pos="${b.pos}"><span class="bt">${fmtClock(b.pos)}</span><span class="bx"><button class="icon-btn sm" data-bact="edit" title="Notiz bearbeiten">${icon("edit")}</button><button class="icon-btn sm" data-bact="del" title="Löschen">${icon("trash")}</button></span>
      <span class="bc">${esc(ch ? ch.title : "")}</span>${b.note ? `<span class="bn">${esc(b.note)}</span>` : ""}</li>`;
  }).join("");
}
function scrollToCurrentChapter(center) {
  const li = $(`#chapterList li[data-i="${P.chapterIdx()}"]`);
  if (li) li.scrollIntoView({ block: center ? "center" : "nearest" });
}

let dragging = null;
function setSlider(el, frac) { el.value = Math.round(frac * 1000); el.style.setProperty("--p", (frac * 100).toFixed(2) + "%"); }

function updateUI(force) {
  if (!P.item) return;
  const t = P.pos(), sp = S.settings.speed || 1;
  const ci = P.chapterIdx(t), ch = P.chapters[ci] || { start: 0, end: P.total, title: "" };
  const cl = Math.max(0.001, ch.end - ch.start), ce = Math.max(0, t - ch.start);
  if (dragging !== "ch") setSlider($("#chSlider"), ce / cl);
  if (dragging !== "tot") setSlider($("#totSlider"), t / P.total);
  $("#chElapsed").textContent = fmtClock(ce);
  $("#chRemain").textContent = "-" + fmtClock((cl - ce) / sp);
  $("#chInfo").textContent = P.chapters.length > 1 ? `Kapitel ${ci + 1} von ${P.chapters.length}` : "";
  $("#totElapsed").textContent = fmtClock(t);
  $("#totRemain").textContent = fmtClock(P.total);
  const left = (P.total - t) / sp;
  $("#totInfo").textContent = `${Math.floor(t / P.total * 100)} % · noch ${fmtDur(left)}${sp !== 1 ? ` bei ${fmtSpeed(sp)}` : ""}`;
  $("#plChapter").innerHTML = P.chapters.length > 1 || ch.title !== P.item.title ? `<span class="eq${P.playing ? "" : " paused"}"><i></i><i></i><i></i></span><span>${esc(ch.title)}</span>` : "";
  // Mini-Player
  $("#miniSub").textContent = (P.chapters.length > 1 ? ch.title + " · " : "") + (P.item.author || P.item.show || "");
  if (!$("#mini .mini-prog").dataset.drag) $("#miniProg").style.width = (t / P.total * 100) + "%";
  $("#miniTime").textContent = `${fmtClock(t)} / ${fmtClock(P.total)}`;
  $("#miniSpeed").textContent = fmtSpeed(sp);
  // Kapitelliste
  if (ci !== P._lastCh || force) {
    $$("#chapterList li").forEach((li, i) => { li.classList.toggle("cur", i === ci); li.classList.toggle("done", i < ci); if (i !== ci) li.querySelector(".cp").style.width = "0"; });
    if (P._lastCh !== -1 && ci !== P._lastCh && S.view === "player") scrollToCurrentChapter(false);
    P._lastCh = ci;
    updateMediaSession();
  }
  const cur = $(`#chapterList li[data-i="${ci}"] .cp`);
  if (cur) cur.style.width = (ce / cl * 100) + "%";
  if ("mediaSession" in navigator && navigator.mediaSession.setPositionState && P.total > 0) {
    try { navigator.mediaSession.setPositionState({ duration: P.total, position: Math.min(t, P.total), playbackRate: sp }); } catch (e) { }
  }
}

function updatePlayState() {
  const playing = P.playing || (P.wantPlay && audio.paused && P.pendingSeek != null);
  for (const b of [$("#playBtn"), $("#mPlay")]) b.innerHTML = icon(playing ? "pause" : "play");
  $$(".pl-chapter .eq").forEach(e => e.classList.toggle("paused", !P.playing));
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = P.playing ? "playing" : "paused";
  // Kachel mit Wiedergabe-Symbol aktualisieren
  if (S.view === "library") updateCardBadge();
}
function updateCardBadge() { // nur das Symbol der laufenden Kachel erneuern (kein Flackern)
  if (!P.item) return;
  const card = $(`.card[data-id="${P.item.id}"]`);
  if (!card) return;
  const it = S.byId[P.item.id] || P.item;
  card.querySelector(".badges").innerHTML = `<span class="bdg now">${P.playing ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("pause")}</span>${it.fav ? `<span class="bdg fav">${icon("heart-f")}</span>` : ""}${it.on_server ? `<span class="bdg cloud" title="Auf player.menet.ch">${icon("cloud")}</span>` : ""}`;
}

function renderSpeed() {
  const cur = S.settings.speed || 1;
  $("#speedSeg").innerHTML = SPEEDS.map(s => `<button data-s="${s}" class="${Math.abs(s - cur) < 0.01 ? "on" : ""}">${s.toFixed(1)}</button>`).join("");
}
function setSpeed(s) {
  S.settings.speed = s; applySpeed(); renderSpeed(); updateUI(true);
  saveSettingsSoon({ speed: s });
}
function setVolume(v) {
  v = Math.max(0, Math.min(1, v));
  S.settings.volume = v; audio.volume = v; audio.muted = false;
  $("#volSlider").value = Math.round(v * 100);
  $("#volSlider").style.setProperty("--p", v * 100 + "%");
  $("#muteBtn").innerHTML = icon(v === 0 ? "mute" : "vol");
  saveSettingsSoon({ volume: v });
}

/* ---------------- Lesezeichen ---------------- */
async function addBookmark() {
  if (!P.item) return;
  const pos = P.pos();
  const note = await askText("Lesezeichen setzen", `Bei ${fmtClock(pos)} – ${P.chapters[P.chapterIdx(pos)]?.title || ""}`, "Notiz (optional)", "");
  if (note === null) return;
  const d = await api("/api/bookmark", { id: P.item.id, action: "add", pos, note });
  P.item.bookmarks = d.bookmarks; renderBookmarks();
  const li = S.byId[P.item.id]; if (li) li.nbookmarks = d.bookmarks.length;
  toast("Lesezeichen gesetzt.", "Anzeigen", () => sideTab("bookmarks"));
}
async function bookmarkAction(e) {
  const li = e.target.closest("li[data-bid]");
  if (!li) return;
  const bid = li.dataset.bid, act = e.target.closest("[data-bact]")?.dataset.bact;
  if (act === "del") {
    const d = await api("/api/bookmark", { id: P.item.id, action: "delete", bid });
    P.item.bookmarks = d.bookmarks; renderBookmarks(); return;
  }
  if (act === "edit") {
    const b = P.item.bookmarks.find(x => x.id === bid);
    const note = await askText("Notiz bearbeiten", fmtClock(b.pos), "Notiz", b.note || "");
    if (note === null) return;
    const d = await api("/api/bookmark", { id: P.item.id, action: "edit", bid, note });
    P.item.bookmarks = d.bookmarks; renderBookmarks(); return;
  }
  P.seek(+li.dataset.pos, true);
  if (!P.playing) togglePlay();
}
function sideTab(t) {
  $$(".side-tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  $("#chapterList").hidden = t !== "chapters";
  $("#bookmarkPane").hidden = t !== "bookmarks";
}

/* ---------------- Schlaf-Timer ---------------- */
S.sleep = null;
function sleepDialog() {
  const opts = [5, 10, 15, 20, 30, 45, 60, 90];
  openModal(`<h2>Schlaf-Timer</h2><p class="hint">Die Wiedergabe wird nach der gewählten Zeit sanft leiser und hält dann an.</p>
    <div class="sleep-opts">${opts.map(m => `<button class="btn" data-m="${m}">${m} min</button>`).join("")}</div>
    <div class="sleep-opts" style="grid-template-columns:1fr 1fr"><button class="btn" data-m="chapter">Am Ende des Kapitels</button><button class="btn" data-m="off" ${S.sleep ? "" : "disabled"}>Timer aus</button></div>
    <div class="foot"><button class="btn" data-close>Schliessen</button></div>`);
  $("#modal").onclick = e => {
    const b = e.target.closest("[data-m]");
    if (b) {
      const m = b.dataset.m;
      if (m === "off") clearSleep();
      else if (m === "chapter") S.sleep = { mode: "chapter", ch: P.chapterIdx() };
      else S.sleep = { mode: "time", end: Date.now() + m * 60000 };
      if (m !== "off") toast(m === "chapter" ? "Schlaf-Timer: hält am Ende des Kapitels an." : `Schlaf-Timer: ${m} Minuten.`);
      closeModal(); updateSleepText();
    }
    if (e.target.closest("[data-close]")) closeModal();
  };
}
function clearSleep() { S.sleep = null; audio.volume = S.settings.volume ?? 1; updateSleepText(); }
function updateSleepText() {
  const b = $("#sleepBtn");
  b.classList.toggle("on", !!S.sleep);
  if (!S.sleep) $("#sleepText").textContent = "Schlaf-Timer";
  else if (S.sleep.mode === "chapter") $("#sleepText").textContent = "Kapitelende";
  else $("#sleepText").textContent = fmtClock(Math.max(0, (S.sleep.end - Date.now()) / 1000));
}
function checkSleep() {
  if (!S.sleep || !P.playing) return;
  if (S.sleep.mode === "chapter") {
    const ci = P.chapterIdx();
    if (ci !== S.sleep.ch) {
      audio.pause(); P.seek(P.chapters[ci].start, false); clearSleep(); toast("Schlaf-Timer: angehalten. Gute Nacht!");
    }
    return;
  }
  const left = (S.sleep.end - Date.now()) / 1000;
  const vol = S.settings.volume ?? 1;
  if (left <= 0) { audio.pause(); clearSleep(); P.seek(P.pos() - 10, false); toast("Schlaf-Timer: angehalten. Gute Nacht!"); }
  else if (left < 15) audio.volume = vol * (left / 15);
}
setInterval(() => { if (S.sleep && S.sleep.mode === "time") { updateSleepText(); if (!P.playing && S.sleep.end < Date.now()) clearSleep(); } }, 1000);

/* ---------------- Dialoge ---------------- */
let modalResolve = null;
function openModal(html) { $("#modal").innerHTML = html; $("#modalWrap").hidden = false; }
function closeModal(val = null) { $("#modalWrap").hidden = true; $("#modal").onclick = null; if (modalResolve) { const r = modalResolve; modalResolve = null; r(val); } }
function askText(title, hint, label, val) {
  return new Promise(res => {
    openModal(`<h2>${esc(title)}</h2><p class="hint">${esc(hint)}</p><textarea id="askIn" placeholder="${esc(label)}">${esc(val)}</textarea>
      <div class="foot"><button class="btn" data-x>Abbrechen</button><button class="btn primary" data-ok>Speichern</button></div>`);
    modalResolve = res;
    const ta = $("#askIn"); ta.focus(); ta.select();
    ta.onkeydown = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); closeModal(ta.value.trim()); } };
    $("#modal").onclick = e => { if (e.target.closest("[data-ok]")) closeModal(ta.value.trim()); if (e.target.closest("[data-x]")) closeModal(null); };
  });
}

async function pickFolder(title, start = "") {
  toast("Ordner-Auswahl wird geöffnet … (ggf. hinter diesem Fenster)", null, null, 3000);
  try {
    const d = await api("/api/pickfolder", { title, start });
    if (d.path === null) { toast("Der Ordner-Dialog liess sich nicht öffnen – bitte Pfad von Hand einfügen."); return ""; }
    return d.path || "";
  } catch (e) { return ""; }
}

async function saveSettings(patch) {
  const d = await api("/api/settings", patch);
  S.settings = d.settings;
  renderLibrary();
  return d;
}
const _pendingSettings = {};
const _flushSettings = debounce(() => { const p = { ...(_pendingSettings) }; for (const k in _pendingSettings) delete _pendingSettings[k]; api("/api/settings", p).catch(() => { }); }, 700);
function saveSettingsSoon(patch) { Object.assign(_pendingSettings, patch); _flushSettings(); }

function settingsDialog() {
  const st = { folders: [...(S.settings.folders || [])], podcast_folders: [...(S.settings.podcast_folders || [])], music_folders: [...(S.settings.music_folders || [])], recursive: S.settings.recursive !== false };
  const list = key => st[key].length ? st[key].map((f, i) => `<li>${icon("folder")}<span title="${esc(f)}">${esc(f)}</span><button class="icon-btn sm" data-del="${key}:${i}" title="Entfernen">${icon("x")}</button></li>`).join("") : `<li class="none">Noch kein Ordner</li>`;
  const draw = () => {
    openModal(`<h2>Einstellungen</h2>
      <h3>Bibliotheksordner</h3><p class="hint">Hier sucht das Programm nach Hörbüchern und Podcasts (M4B, MP3, M4A …).</p>
      <ul class="folders">${list("folders")}</ul>
      <div class="add-row"><input id="pathIn" type="text" placeholder="${S.server ? "Pfad auf dem Heimserver, z. B. /mnt/hoerbuecher" : "Pfad einfügen, z. B. D:\\Hörbücher"}"><button class="btn" data-add="folders">${icon("plus")}Hinzufügen</button><button class="btn" data-pick="folders">${icon("folder")}Durchsuchen …</button></div>
      <label class="switch"><input type="checkbox" id="recIn" ${st.recursive ? "checked" : ""}><span class="tr"></span><span>Unterordner einbeziehen</span></label>
      <h3>Podcast-Ordner</h3><p class="hint">Alles in diesen Ordnern gilt als Podcast – jede Datei ist eine Folge, Unterordner sind Sendungen. (Sonst entscheidet das Programm selbst: Genre «Podcast» → Podcast; M4B, Kapitelmarken oder Ordner mit mehreren Dateien eines Buchs → Hörbuch. Pro Titel kannst du es über ⋯ ändern.)</p>
      <ul class="folders">${list("podcast_folders")}</ul>
      <div class="add-row"><input id="pathIn2" type="text" placeholder="Pfad einfügen"><button class="btn" data-add="podcast_folders">${icon("plus")}Hinzufügen</button><button class="btn" data-pick="podcast_folders">${icon("folder")}Durchsuchen …</button></div>
      <h3>Musik-Ordner</h3><p class="hint">Für «Meine Musik» (unter Musik): Ordner mit deiner Musiksammlung (FLAC, MP3 …), sortiert nach Interpret und Album.</p>
      <ul class="folders">${list("music_folders")}</ul>
      <div class="add-row"><input id="pathIn3" type="text" placeholder="${S.server ? "z. B. /mnt/musik" : "Pfad einfügen, z. B. \\\\NAS\\music"}"><button class="btn" data-add="music_folders">${icon("plus")}Hinzufügen</button><button class="btn" data-pick="music_folders">${icon("folder")}Durchsuchen …</button></div>
      <div id="pfSec">${profilesSettingsHTML()}</div>
      ${S.server ? `<h3>Sonos</h3><p class="hint">Die Boxen werden im Heimnetz von selbst gefunden. Nur falls nicht: hier die Adresse einer Box eintragen (z. B. 192.168.1.40), mehrere mit Komma.</p>
        <div class="add-row"><input id="sonosHosts" type="text" placeholder="IP-Adresse einer Sonos-Box (freiwillig)" value="${esc((S.settings.sonos_hosts || []).join(", "))}"></div>` : ""}
      <div id="cloudSec">${cloudSection()}</div>
      <div id="musicSec">${musicSettingsHTML()}</div>
      <h3>Tastenkürzel</h3>
      <div class="keys">
      <span><kbd>Leertaste</kbd></span><span>Abspielen / Pause</span>
      <span><kbd>←</kbd><kbd>→</kbd></span><span>30 Sekunden zurück / vor</span>
      <span><kbd>Bild ↑</kbd><kbd>Bild ↓</kbd></span><span>Kapitelanfang bzw. voriges / nächstes Kapitel (auch Umschalt + ← / →)</span>
      <span><kbd>↑</kbd><kbd>↓</kbd></span><span>Lauter / leiser</span>
      <span><kbd>+</kbd><kbd>−</kbd></span><span>Schneller / langsamer</span>
      <span><kbd>B</kbd></span><span>Lesezeichen setzen</span>
      <span><kbd>F</kbd></span><span>Favorit an/aus</span>
      <span><kbd>M</kbd></span><span>Ton aus / an</span>
      <span><kbd>Strg</kbd>+<kbd>F</kbd></span><span>Suchen</span>
      <span><kbd>Esc</kbd></span><span>Zurück zur Bibliothek</span></div>
      <p class="hint" style="margin-top:8px">Die Medientasten der Tastatur (Play/Pause, Weiter, Zurück) funktionieren ebenfalls.</p>
      <h3>Updates</h3>
      <div class="add-row" style="align-items:center"><span class="hint" id="updStatus" style="flex:1;margin:0">${S.update && S.update.available ? `Version ${esc(S.update.latest)} ist verfügbar.` : `Du hast Version ${esc(window.VERSION)}.`}</span>
        <button class="btn" data-updcheck>${icon("refresh")}Nach Updates suchen</button></div>
      <div class="about">MyPlayer ${esc(window.VERSION)} · Deine Daten (Fortschritt, Lesezeichen …) liegen in <a id="openData">${esc(S.dataDir)}</a></div>
      <div class="foot"><button class="btn" data-rescan>${icon("refresh")}Neu einlesen</button><span style="flex:1"></span><button class="btn" data-x>Abbrechen</button><button class="btn primary" data-save>Speichern</button></div>`);
    $("#modal").onclick = async e => {
      const t = e.target;
      const del = t.closest("[data-del]");
      if (del) { const [k, i] = del.dataset.del.split(":"); st[k].splice(+i, 1); return draw(); }
      const add = t.closest("[data-add]");
      if (add) {
        const k = add.dataset.add, inp = k === "folders" ? $("#pathIn") : k === "music_folders" ? $("#pathIn3") : $("#pathIn2");
        const v = inp.value.trim().replace(/^"|"$/g, "");
        if (v && !st[k].includes(v)) st[k].push(v);
        st.recursive = $("#recIn").checked;
        return draw();
      }
      const pick = t.closest("[data-pick]");
      if (pick) {
        const k = pick.dataset.pick;
        st.recursive = $("#recIn").checked;
        const p = await pickFolder(k === "folders" ? "Bibliotheksordner wählen" : "Podcast-Ordner wählen", st[k][0] || st.folders[0] || "");
        if (p && !st[k].includes(p)) st[k].push(p);
        return draw();
      }
      if (t.closest("#openData")) return api("/api/opendata", {});
      if (await profilesSettingsClick(t)) return;
      if (t.closest("[data-music-out]")) { e.preventDefault(); await musicSignOut(); $("#musicSec").innerHTML = musicSettingsHTML(); return; }
      if (t.closest("[data-pair]")) {
        const code = $("#pairCode").value.trim();
        if (!code) return;
        const d = await api("/api/cloud/pair", { code }).catch(e => ({ error: e.message }));
        if (d.error) return toast("Verbinden fehlgeschlagen: " + d.error, null, null, 7000);
        showCloud(d); $("#cloudSec").innerHTML = cloudSection(); toast(`Verbunden mit player.menet.ch als ${d.user}.`); return;
      }
      if (t.closest("[data-csync]")) { $("#cloudSec").querySelector(".hint").textContent = "Gleiche ab …"; showCloud(await api("/api/cloud/sync", {})); $("#cloudSec").innerHTML = cloudSection(); await loadLibrary(); return; }
      if (t.closest("[data-ccancel]")) { showCloud(await api("/api/cloud/cancel", {})); $("#cloudSec").innerHTML = cloudSection(); return; }
      if (t.closest("[data-unpair]")) { if (!confirm("Verbindung zu player.menet.ch trennen?")) return; showCloud(await api("/api/cloud/unpair", {})); $("#cloudSec").innerHTML = cloudSection(); await loadLibrary(); return; }
      if (t.closest("[data-updcheck]")) {
        $("#updStatus").textContent = "Suche …";
        const u = await checkUpdate(true);
        if (!u) $("#updStatus").textContent = "Konnte nicht nachsehen.";
        else if (u.available) { closeModal(); return updateDialog(); }
        else $("#updStatus").textContent = u.error ? u.error : `Alles aktuell – Version ${window.VERSION} ist die neueste.`;
        return;
      }
      if (t.closest("[data-rescan]")) { await api("/api/rescan", {}); toast("Bibliothek wird neu eingelesen …"); pollStatus(); return closeModal(); }
      if (t.closest("[data-x]")) return closeModal();
      if (t.closest("[data-save]")) {
        st.recursive = $("#recIn").checked;
        // nicht übernommene Eingaben trotzdem mitnehmen
        for (const [id, k] of [["#pathIn", "folders"], ["#pathIn2", "podcast_folders"], ["#pathIn3", "music_folders"]]) {
          const v = $(id).value.trim().replace(/^"|"$/g, ""); if (v && !st[k].includes(v)) st[k].push(v);
        }
        if ($("#sonosHosts")) st.sonos_hosts = $("#sonosHosts").value.split(/[,\s]+/).map(x => x.trim()).filter(Boolean);
        const d = await saveSettings(st);
        OWN.data = null; OWN.cache = {}; applyMusicSetting();   // Musik-Ordner geändert → neu laden, Reiter «Musik» zeigen/verstecken
        closeModal();
        if (d.rescan) { toast("Bibliothek wird neu eingelesen …"); pollStatus(); }
      }
    };
    $("#modal").onchange = e => { if (e.target.id === "musicIn") musicSettingsChange(e.target.checked).then(() => { $("#musicSec").innerHTML = musicSettingsHTML(); }); };
  };
  draw();
}

/* ---------------- Musik (Apple Music über MusicKit JS) ---------------- */
// Gleicher Code im PC-Player (desktop/web/app.js) und im Web-Player (server/public/player/app.js).
// Das Zugangs-Token kommt von player.menet.ch (der Schlüssel bleibt dort); die Person meldet sich mit ihrer Apple-ID an.
const MUSICKIT_URL = "https://js-cdn.music.apple.com/musickit/v3/musickit.js";
const IS_WEB = !window.TOKEN;   // Web-Player (player.menet.ch) oder PC-Player
const M = {
  mk: null, devToken: "", loading: null, sf: "ch",
  lists: null, recent: null, added: null, albums: null,   // Startseite (Mediathek)
  results: null, q: "",                                    // Suche
  stack: [],      // geöffnete Playlists/Alben/Interpreten (Zurück = eins weg)
  cache: {},      // Titel je Playlist/Album/Interpret
  items: {},      // angezeigte Einträge nach "typ:id"
  fresh: false,   // Startseite in dieser Sitzung schon aufgefrischt
  mosaic: {}, mosaicBusy: {},   // Mosaik-Cover je Playlist-ID
};

function musicEnabled() { return !!S.settings.music; }
function applyMusicSetting() {
  const tab = $('#kindSeg button[data-kind="music"]');
  if (tab) tab.hidden = !(musicEnabled() || ownAvailable());
  if (!(musicEnabled() || ownAvailable()) && S.kind === "music") { S.kind = "book"; $$("#kindSeg button").forEach(x => x.classList.toggle("on", x.dataset.kind === "book")); }
}

function loadMusicKit() {
  if (window.MusicKit && MusicKit.getInstance) return Promise.resolve();
  if (M.loading) return M.loading;
  M.loading = new Promise((res, rej) => {
    document.addEventListener("musickitloaded", () => res(), { once: true });
    const s = document.createElement("script");
    s.src = MUSICKIT_URL; s.async = true;
    s.dataset.webComponents = "";
    s.onerror = () => { M.loading = null; rej(new Error("js-cdn.music.apple.com nicht erreichbar")); };
    document.head.append(s);
    setTimeout(() => { M.loading = null; rej(new Error("Zeitüberschreitung")); }, 20000);
  });
  return M.loading;
}

async function musicSetup() {
  if (M.mk) return M.mk;
  // Jeder Schritt mit eigener Meldung, damit klar ist, welche Verbindung fehlt
  const step = async (what, fn) => {
    try { return await fn(); }
    catch (e) { console.error(what, e); throw new Error(`${what} (${(e && e.message) || e})`); }
  };
  const t = await step(IS_WEB ? "Keine Verbindung zu player.menet.ch" : "Keine Verbindung zum Player – bitte MyPlayer neu starten",
    () => api("/api/musik/token", {}));
  if (!t || !t.token) throw new Error((t && t.error) || "Kein Zugang zu Apple Music");
  await step("Apple Music lädt nicht – Internet-Verbindung prüfen", loadMusicKit);
  M.devToken = t.token;
  M.mk = await step("Apple Music antwortet nicht", () => MusicKit.configure({ developerToken: t.token, suppressErrorDialog: true,
    app: { name: "MyPlayer", build: String(window.VERSION || "1") } }));
  M.mk.addEventListener("playbackStateDidChange", musicStateChanged);
  M.mk.addEventListener("nowPlayingItemDidChange", () => { musicBar(); markMusicPlaying(); });
  M.mk.addEventListener("mediaPlaybackError", e => {
    console.error("Apple Music", e);
    const m = e && (e.message || (e.error && e.error.message) || e.errorCode);
    toast("Apple Music konnte den Titel nicht abspielen" + (m && m !== "undefined" ? `: ${m}` : "."), null, null, 6000);
  });
  M.mk.addEventListener("playbackTimeDidChange", () => updateMusicTime());
  M.mk.addEventListener("authorizationStatusDidChange", () => { musicForget(); if (S.kind === "music") renderLibrary(); });
  return M.mk;
}
function musicForget() { M.active = false; M.lists = M.recent = M.added = M.albums = M.results = null; M.q = ""; M.stack = []; M.cache = {}; M.fresh = false; M.mosaic = {}; M.mosaicBusy = {}; }

function musicPlaying() { return !!(M.mk && M.mk.playbackState === MusicKit.PlaybackStates.playing); }
function musicStateChanged() {
  // Musik und Hörbuch nie gleichzeitig: startet Musik, pausiert das Hörbuch
  if (musicPlaying() && P.item && !audio.paused) audio.pause();
  if (musicPlaying() && !OWN.el.paused) { OWN.el.pause(); OWN.active = false; }
  musicBar();
}
// … und startet ein Hörbuch, pausiert die Musik (die Leiste unten zeigt dann wieder das Hörbuch)
audio.addEventListener("play", () => { if (musicPlaying()) M.mk.pause(); M.active = false; musicBar(); });

/* --- Hilfen --- */
function art(a, size = 160) {
  const u = a && a.attributes && a.attributes.artwork && a.attributes.artwork.url;
  return u ? u.replace("{w}", size).replace("{h}", size).replace("{f}", "jpg") : "";
}
function baseType(t) { return String(t || "").replace("library-", ""); }
function itemIds(x) {
  const p = (x && x.attributes && x.attributes.playParams) || (x && x.playParams) || {};
  return [x && x.id, p.id, p.catalogId].filter(Boolean).map(String);
}
function sameItem(x, ids) { const own = itemIds(x); return ids.some(i => own.includes(i)); }
function remember(it) { const k = `${it.type}:${it.id}`; M.items[k] = it; return k; }
function opensDetail(t) { return ["albums", "playlists", "artists"].includes(baseType(t)); }
function itemSub(it) {
  const a = it.attributes || {}, t = baseType(it.type);
  if (t === "songs") return [a.artistName, a.albumName].filter(Boolean).join(" · ");
  if (t === "albums") return [a.artistName, a.releaseDate ? String(a.releaseDate).slice(0, 4) : ""].filter(Boolean).join(" · ");
  if (t === "artists") return "Interpret";
  if (t === "stations") return "Radio";
  return a.curatorName || "Playlist";
}

// Liste über mehrere Seiten holen (Apple liefert höchstens 100 pro Abruf)
// Kennt Apple die Gesamtzahl, werden die übrigen Seiten gleichzeitig geholt (viel schneller als nacheinander).
async function musicFetchAll(path, limit = 100, max = 500) {
  const r = await M.mk.api.music(path, { limit });
  const d = (r && r.data) || {};
  let out = d.data || [];
  const total = d.meta && d.meta.total;
  if (total > out.length && out.length) {
    const offs = [];
    for (let o = out.length; o < Math.min(total, max); o += limit) offs.push(o);
    const pages = await Promise.all(offs.map(o => M.mk.api.music(path, { limit, offset: o })
      .then(x => (x && x.data && x.data.data) || []).catch(() => [])));
    return out.concat(...pages);
  }
  let next = d.next;
  while (next && out.length < max) {
    const x = await M.mk.api.music(next);
    const dd = (x && x.data) || {};
    out = out.concat(dd.data || []);
    next = dd.next;
  }
  return out;
}

/* --- Mosaik-Cover für Playlists ohne eigenes Bild (wie in Apple Music: 4 Cover der Lieder) --- */
function mosaicFrom(tracks) {
  const urls = [];
  for (const t of tracks || []) { const u = art(t, 200); if (u && !urls.includes(u)) urls.push(u); if (urls.length === 4) break; }
  return urls;
}
function mosaicHTML(urls) {
  if (!urls || !urls.length) return icon("music");
  if (urls.length < 4) return `<img loading="lazy" src="${esc(urls[0])}" alt="">`;
  return `<div class="mosaic">${urls.map(u => `<img loading="lazy" src="${esc(u)}" alt="">`).join("")}</div>`;
}
function musicMosaics() {
  const keys = [...new Set($$("[data-mosaic]").map(e => e.dataset.mosaic))];
  for (const key of keys) {
    const it = M.items[key];
    if (!it) continue;
    const fill = urls => $$("[data-mosaic]").filter(e => e.dataset.mosaic === key).forEach(e => { e.innerHTML = mosaicHTML(urls); delete e.dataset.mosaic; });
    if (M.mosaic[it.id]) { fill(M.mosaic[it.id]); continue; }
    if (M.mosaicBusy[it.id]) continue;
    M.mosaicBusy[it.id] = true;
    const path = it.type.startsWith("library-") ? `/v1/me/library/playlists/${encodeURIComponent(it.id)}/tracks` : `/v1/catalog/${M.sf}/playlists/${encodeURIComponent(it.id)}/tracks`;
    M.mk.api.music(path, { limit: 30 }).then(r => (r.data && r.data.data) || []).catch(() => [])
      .then(tr => { M.mosaic[it.id] = mosaicFrom(tr); fill(M.mosaic[it.id]); musicHomeSave(); });
  }
}

/* --- Startseite: sofort mit dem letzten Stand, dann im Hintergrund auffrischen --- */
const MHOME = "player.musik.home:" + (window.USER_NAME || "");
function slim(x) {
  const a = x.attributes || {};
  return { id: x.id, type: x.type, attributes: { name: a.name, artistName: a.artistName, curatorName: a.curatorName, releaseDate: a.releaseDate,
    artwork: a.artwork && a.artwork.url ? { url: a.artwork.url } : undefined, playParams: a.playParams } };
}
function musicHomeSave() {
  try {
    localStorage.setItem(MHOME, JSON.stringify({ lists: (M.lists || []).map(slim), recent: (M.recent || []).map(slim), added: (M.added || []).map(slim),
      albums: M.albums ? M.albums.map(slim) : null, mosaic: M.mosaic }));
  } catch (e) { }
}
function musicHomeCache() {
  if (M.lists || M.recent || M.albums) return;
  try {
    const c = JSON.parse(localStorage.getItem(MHOME) || "null");
    if (c) { M.lists = c.lists; M.recent = c.recent; M.added = c.added; M.albums = c.albums; M.mosaic = c.mosaic || {}; }
  } catch (e) { }
}
function drawMusicHome() {
  const mb = $("#musicBody");
  if (!mb || S.kind !== "music" || M.stack.length || (S.q || "").trim()) return;
  const albums = M.albums ? musicSection(`Meine Alben (${M.albums.length})`, M.albums, true)
    : `<section class="music-sec"><h3>Meine Alben</h3><div class="mloading"><span class="spinner"></span>wird geladen …</div></section>`;
  const html = musicSection("Zuletzt gehört", M.recent, true) + musicSection("Meine Playlists", M.lists, true)
    + musicSection("Neu in der Mediathek", M.added, true) + (M.albums && !M.albums.length ? "" : albums);
  mb.innerHTML = html || `<div class="empty"><p>Deine Mediathek ist noch leer. Oben bei der Lupe kannst du in ganz Apple Music suchen und Alben hinzufügen.</p></div>`;
  musicMosaics();
}
async function musicHome() {
  musicHomeCache();
  drawMusicHome();
  if (M.fresh) return;
  M.fresh = true;
  const mk = M.mk, list = r => (r && r.data && r.data.data) || [];
  await Promise.all([
    musicFetchAll("/v1/me/library/playlists", 100, 300).then(v => { M.lists = v; }),
    mk.api.music("/v1/me/recent/played", { limit: 10 }).then(r => { M.recent = list(r); }),
    mk.api.music("/v1/me/library/recently-added", { limit: 10 }).then(r => { M.added = list(r); }),
  ].map(p => p.catch(() => { }).then(drawMusicHome)));
  const name = x => String((x.attributes && x.attributes.name) || "");
  try { M.albums = (await musicFetchAll("/v1/me/library/albums", 100, 3000)).sort((x, y) => name(x).localeCompare(name(y), "de", { sensitivity: "base" })); }
  catch (e) { if (!M.albums) M.albums = []; }
  drawMusicHome();
  musicHomeSave();
}

/* --- Darstellung: Zeilen und Kacheln --- */
function musicRow(it) {
  const a = it.attributes || {}, k = remember(it), img = art(it, 120), det = opensDetail(it.type);
  const dur = a.durationInMillis ? fmtClock(a.durationInMillis / 1000) : "";
  return `<div class="row music-row" data-mkey="${esc(k)}">
    <div class="rc">${img ? `<img loading="lazy" src="${esc(img)}" alt="">` : `<div class="ph">${icon("music")}</div>`}</div>
    <div class="rt"><b>${esc(a.name || "?")}</b><span>${esc(itemSub(it))}</span></div>
    <div class="rd">${dur}</div>
    <div class="rb">${det && baseType(it.type) !== "artists" ? `<button class="icon-btn" data-mrowplay title="Gleich abspielen">${icon("play")}</button>`
      : det ? `<span class="icon-btn">${icon("chev-left", "flip")}</span>` : `<span class="icon-btn">${icon("play")}</span>`}</div>
  </div>`;
}
function musicCard(it) {
  const a = it.attributes || {}, k = remember(it), img = art(it, 300);
  const mos = !img && baseType(it.type) === "playlists";
  const inner = img ? `<img loading="lazy" src="${esc(img)}" alt="">` : mos && M.mosaic[it.id] ? mosaicHTML(M.mosaic[it.id]) : icon("music");
  return `<div class="mcard" data-mkey="${esc(k)}" title="${esc(a.name || "")}">
    <div class="mc-cover"><div class="mc-art"${mos && !M.mosaic[it.id] ? ` data-mosaic="${esc(k)}"` : ""}>${inner}</div>
      ${baseType(it.type) !== "artists" ? `<button class="mc-play" data-mrowplay title="Gleich abspielen">${icon("play")}</button>` : ""}</div>
    <b>${esc(a.name || "?")}</b><span>${esc(itemSub(it))}</span></div>`;
}
function musicSection(title, items, grid = false) {
  if (!items || !items.length) return "";
  return `<section class="music-sec"><h3>${esc(title)}</h3>${grid ? `<div class="mgrid">${items.map(musicCard).join("")}</div>`
    : `<div class="list">${items.map(i => musicRow(i)).join("")}</div>`}</section>`;
}
function trackRow(tr, i, showArtist) {
  const a = tr.attributes || {}, ok = !!a.playParams;
  const dur = a.durationInMillis ? fmtClock(a.durationInMillis / 1000) : "";
  const sub = showArtist ? [a.artistName, a.albumName].filter(Boolean).join(" · ") : "";
  return `<div class="mtrack${ok ? "" : " off"}" data-tidx="${i}" data-tids="${esc(itemIds(tr).join(","))}"${ok ? "" : ` title="Bei Apple Music nicht verfügbar"`}>
    <span class="tn"><i>${showArtist || !a.trackNumber ? i + 1 : a.trackNumber}</i>${icon("play")}</span>
    <div class="rt"><b>${esc(a.name || "?")}</b>${sub ? `<span>${esc(sub)}</span>` : ""}</div>
    <span class="rd">${dur}</span></div>`;
}

/* --- Seite «Musik» --- */
async function renderMusic(body, head) {
  head.innerHTML = `<h2>Musik</h2><span class="sub">Apple Music</span>`;
  let mk;
  try { mk = await musicSetup(); }
  catch (e) {
    body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><h2>Apple Music</h2><p>${esc(e.message)}</p>
      <button class="btn primary" id="mRetry">${icon("refresh")}Nochmals versuchen</button></div>`;
    $("#mRetry").onclick = () => { body.innerHTML = `<div class="empty"><span class="spinner"></span></div>`; renderLibrary(); };
    return;
  }
  if (!mk.isAuthorized) {
    body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><h2>Mit Apple Music verbinden</h2>
      <p>Melde dich einmal mit deiner Apple-ID an (mit Apple-Music-Abo). Danach findest du hier deine Mediathek, zuletzt Gehörtes und die ganze Apple-Music-Bibliothek.</p>
      <button class="btn primary" id="mAuth">${icon("music")}Mit Apple Music anmelden</button></div>`;
    $("#mAuth").onclick = async () => {
      try { await mk.authorize(); renderLibrary(); }
      catch (e) { toast("Anmeldung bei Apple Music abgebrochen oder fehlgeschlagen."); }
    };
    return;
  }
  M.sf = mk.storefrontId || "ch";
  const q = (S.q || "").trim();
  if (M.stack.length && M.stack[M.stack.length - 1].q !== q) M.stack = [];   // neue Suche → zurück zur Liste
  const top = M.stack[M.stack.length - 1];
  body.innerHTML = `<div id="musicBody"><div class="empty"><span class="spinner"></span></div></div>`;
  const mb = $("#musicBody");
  try {
    if (top) { await renderMusicDetail(mb, top.key); return; }
    if (q) {
      if (M.q !== q) {
        M.q = q; M.results = null;
        await new Promise(r => setTimeout(r, 400));
        if (M.q !== q) return;   // inzwischen weiter getippt
        const r = await mk.api.music(`/v1/catalog/${M.sf}/search`, { term: q, types: ["songs", "albums", "playlists", "artists"], limit: 10 });
        if (M.q !== q) return;
        M.results = (r.data && r.data.results) || {};
      }
      const R = M.results || {};
      const html = musicSection("Interpreten", R.artists && R.artists.data) + musicSection("Titel", R.songs && R.songs.data)
        + musicSection("Alben", R.albums && R.albums.data, true) + musicSection("Playlists", R.playlists && R.playlists.data, true);
      mb.innerHTML = html || `<div class="empty"><p>Nichts gefunden für «${esc(q)}».</p></div>`;
    } else {
      await musicHome();
    }
  } catch (e) {
    mb.innerHTML = `<div class="empty"><p>Apple Music antwortet nicht: ${esc(e.message || e)}</p></div>`;
  }
}

/* --- Geöffnete Playlist / Album / Interpret --- */
async function musicLoadDetail(it) {
  const sf = M.sf, id = encodeURIComponent(it.id), t = it.type;
  const tracks = p => musicFetchAll(p, 100, 1000).catch(() => []);
  if (t === "library-playlists") return { tracks: await tracks(`/v1/me/library/playlists/${id}/tracks`), queue: { playlist: it.id } };
  if (t === "playlists") return { tracks: await tracks(`/v1/catalog/${sf}/playlists/${id}/tracks`), queue: { playlist: it.id } };
  if (t === "library-albums") return { tracks: await tracks(`/v1/me/library/albums/${id}/tracks`), queue: { album: it.id } };
  if (t === "albums") return { tracks: await tracks(`/v1/catalog/${sf}/albums/${id}/tracks`), queue: { album: it.id } };
  if (t === "artists") {
    const [top, albums] = await Promise.all([
      M.mk.api.music(`/v1/catalog/${sf}/artists/${id}/view/top-songs`, { limit: 10 }).then(r => (r.data && r.data.data) || []).catch(() => []),
      musicFetchAll(`/v1/catalog/${sf}/artists/${id}/albums`, 25, 100).catch(() => []),
    ]);
    albums.sort((x, y) => String((y.attributes || {}).releaseDate || "").localeCompare(String((x.attributes || {}).releaseDate || "")));
    return { tracks: top, albums, queue: null };
  }
  return { tracks: [], queue: null };
}

async function renderMusicDetail(mb, key) {
  const it = M.items[key];
  if (!it) { M.stack.pop(); return renderLibrary(); }
  if (!M.cache[key]) M.cache[key] = await musicLoadDetail(it);
  const D = M.cache[key], a = it.attributes || {}, t = it.type, bt = baseType(t);
  const lib = t.startsWith("library-");
  const n = D.tracks.length;
  const kind = { albums: "Album", playlists: "Playlist", artists: "Interpret" }[bt] || "";
  const info = bt === "artists" ? "" : [itemSub(it), `${n} Titel`].filter(Boolean).join(" · ");
  const img = art(it, 400);
  if (!img && bt === "playlists" && !M.mosaic[it.id]) M.mosaic[it.id] = mosaicFrom(D.tracks);
  const showArtist = bt !== "albums" || D.tracks.some(x => (x.attributes || {}).artistName && (x.attributes || {}).artistName !== a.artistName);
  mb.innerHTML = `<button class="btn mback" data-mback>${icon("chev-left")}Zurück</button>
    <div class="mhero">
      <div class="mh-cover${bt === "artists" ? " round" : ""}">${img ? `<img src="${esc(img)}" alt="">` : bt === "playlists" ? mosaicHTML(M.mosaic[it.id]) : icon("music")}</div>
      <div class="mh-txt"><span class="mh-kind">${kind}</span><h2>${esc(a.name || "")}</h2>${info ? `<p>${esc(info)}</p>` : ""}
        <div class="mh-btns">
          ${n ? `<button class="btn primary" data-mplayall>${icon("play")}Abspielen</button><button class="btn" data-mshuffle>${icon("refresh")}Zufällig</button>` : ""}
          ${lib ? `<span class="mh-lib">${icon("check")}In deiner Mediathek</span>`
            : (bt === "albums" || bt === "playlists") ? `<button class="btn" data-madd>${icon("plus")}Zur Mediathek hinzufügen</button>` : ""}
        </div></div></div>
    ${n ? `${bt === "artists" ? "<h3 class=\"mh-sec\">Top-Titel</h3>" : ""}<div class="mtracks">${D.tracks.map((x, i) => trackRow(x, i, showArtist)).join("")}</div>`
      : bt === "artists" ? "" : `<div class="empty"><p>Diese ${kind} ist leer.</p></div>`}
    ${bt === "artists" ? musicSection("Alben", D.albums, true) : ""}`;
  markMusicPlaying();
}

function markMusicPlaying() {
  const now = M.mk && M.mk.nowPlayingItem;
  const ids = now ? itemIds(now) : [];
  $$("[data-tids]").forEach(r => r.classList.toggle("playing", !!ids.length && r.dataset.tids.split(",").some(i => ids.includes(i))));
}

/* --- Abspielen --- */
function musicQueueFor(it) {
  const t = baseType(it.type);
  return t === "playlists" ? { playlist: it.id } : t === "albums" ? { album: it.id } : t === "stations" ? { station: it.id } : t === "songs" ? { song: it.id } : null;
}
async function musicStart(queue, opts = {}) {
  const mk = await musicSetup();
  if (P.item && !audio.paused) audio.pause();
  M.active = true;
  if (!OWN.el.paused) OWN.el.pause();
  OWN.active = false;
  M.lastQueue = queue;   // für «nach dem Update weiterspielen»
  try { mk.shuffleMode = opts.shuffle ? 1 : 0; } catch (e) { }
  await mk.setQueue({ ...queue, ...(opts.startWith != null ? { startWith: opts.startWith } : {}), startPlaying: true });
  // Falls Apple den gewünschten Starttitel nicht übernommen hat: in der Warteschlange suchen und dorthin springen
  if (opts.want && mk.nowPlayingItem && !sameItem(mk.nowPlayingItem, opts.want)) {
    const items = (mk.queue && mk.queue.items) || [];
    const j = items.findIndex(x => sameItem(x, opts.want));
    if (j >= 0 && mk.changeToMediaAtIndex) await mk.changeToMediaAtIndex(j);
  }
  // nur anstossen, wenn Apple nicht schon von selbst spielt oder lädt (doppeltes «Abspielen» gab Fehler)
  const PS = MusicKit.PlaybackStates || {};
  if (![PS.loading, PS.playing, PS.seeking, PS.waiting, PS.stalled].includes(mk.playbackState)) await mk.play().catch(() => { });
  musicBar();
}
async function musicPlayItem(it) {
  const q = musicQueueFor(it);
  if (!q) return;
  try { await musicStart(q); } catch (e) { toast("Abspielen nicht möglich: " + (e.message || e), null, null, 6000); }
}
async function musicPlayTrack(key, idx, shuffle = false) {
  const D = M.cache[key], it = M.items[key];
  if (!D || !it) return;
  const tr = D.tracks[idx];
  if (tr && !(tr.attributes || {}).playParams) return toast("Dieser Titel ist bei Apple Music nicht verfügbar.");
  const queue = D.queue || { songs: D.tracks.filter(x => (x.attributes || {}).playParams).map(x => x.id) };
  try { await musicStart(queue, tr ? { startWith: D.queue ? idx : Math.max(0, queue.songs.indexOf(tr.id)), want: itemIds(tr) } : { shuffle }); }
  catch (e) { toast("Abspielen nicht möglich: " + (e.message || e), null, null, 6000); }
}

/* --- Zur Mediathek hinzufügen --- */
async function musicAddToLibrary(it) {
  const kind = baseType(it.type);
  const r = await fetch(`https://api.music.apple.com/v1/me/library?ids[${kind}]=${encodeURIComponent(it.id)}`, {
    method: "POST", headers: { "Authorization": "Bearer " + M.devToken, "Music-User-Token": M.mk.musicUserToken || "" },
  });
  if (!r.ok) throw new Error(r.status === 403 ? "Apple Music erlaubt das Hinzufügen nicht (Abo/Mediathek-Synchronisierung prüfen)" : `Apple Music: Fehler ${r.status}`);
  M.fresh = false;   // Mediathek beim nächsten Mal neu laden
}

/* --- Leiste unten: zeigt die Musik, solange sie zuletzt gestartet wurde (sonst das Hörbuch) --- */
function musicBar() {
  const bar = $("#mmini");
  if (!bar) return;
  if (sonosActive()) { bar.hidden = true; $("#mini").hidden = true; return; }
  const own = OWN.active && ownTrack();
  const it = !own && M.mk && M.mk.nowPlayingItem;
  const show = !!((own || (M.active && it)) && S.view === "library");
  bar.hidden = !show;
  if (show) $("#mini").hidden = true;
  else if (S.view === "library") $("#mini").hidden = !P.item;
  if (!show) return;
  if (own) {
    const key = "own:" + own.id;
    if (bar.dataset.key !== key) {
      bar.dataset.key = key;
      $("#mmCover").innerHTML = `<span class="ph">${icon("music")}</span>${ownArt(own.album)}`;
    }
    $("#mmTitle").textContent = own.title;
    $("#mmSub").textContent = [own.artist, own.album_title].filter(Boolean).join(" · ");
    $("#mmPlay").innerHTML = icon(OWN.el.paused ? "play" : "pause");
    $("#mmini .badge").textContent = "Meine Musik";
  } else {
    bar.dataset.key = "";
    const a = it.attributes || it;
    const img = String(it.artworkURL || art(it, 200) || "").replace("{w}", 200).replace("{h}", 200);
    $("#mmCover").innerHTML = img ? `<img src="${esc(img)}" alt="">` : `<span class="ph">${icon("music")}</span>`;
    $("#mmTitle").textContent = a.name || it.title || "";
    $("#mmSub").textContent = [a.artistName || it.artistName, a.albumName || it.albumName].filter(Boolean).join(" · ");
    $("#mmPlay").innerHTML = icon(musicPlaying() ? "pause" : "play");
    $("#mmini .badge").textContent = "Apple Music";
  }
  updateMusicTime();
}
function musicNow() {   // Zeit und Länge der gerade laufenden Musik (eigene oder Apple Music)
  if (OWN.active) return { t: OWN.el.currentTime || 0, d: isFinite(OWN.el.duration) ? OWN.el.duration : 0 };
  return M.mk ? { t: M.mk.currentPlaybackTime || 0, d: M.mk.currentPlaybackDuration || 0 } : { t: 0, d: 0 };
}
function updateMusicTime() {
  const bar = $("#mmini");
  if (!bar || bar.hidden) return;
  const { t, d } = musicNow();
  if ($("#mmini .mini-prog").dataset.drag) return;   // wird gerade gezogen
  $("#mmProg").style.width = d ? (t / d * 100) + "%" : "0";
  $("#mmTime").textContent = d ? `${fmtClock(t)} / ${fmtClock(d)}` : "";
}

/* --- Klicks im Bereich «Musik» --- */
/* --- Fortschritt in der Leiste unten mit der Maus (oder dem Finger) ziehen --- */
function bindProgDrag(el, fill, total, seek, label) {
  const frac = e => { const r = el.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); };
  const show = f => { fill.style.width = f * 100 + "%"; if (label) label(f * total()); };
  el.addEventListener("pointerdown", e => {
    if (!total()) return;
    e.preventDefault();
    el.setPointerCapture(e.pointerId);
    el.dataset.drag = "1";
    show(frac(e));
  });
  el.addEventListener("pointermove", e => { if (el.dataset.drag) show(frac(e)); });
  const end = e => { if (!el.dataset.drag) return; delete el.dataset.drag; seek(frac(e) * total()); };
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", () => { delete el.dataset.drag; });
}

function bindMusic() {
  bindProgDrag($("#mini .mini-prog"), $("#miniProg"), () => P.item ? P.total : 0, t => P.seek(t));
  bindProgDrag($("#mmini .mini-prog"), $("#mmProg"), () => musicNow().d,
    t => { if (OWN.active) OWN.el.currentTime = t; else M.mk.seekToTime(t); }, t => { $("#mmTime").textContent = `${fmtClock(t)} / ${fmtClock(musicNow().d)}`; });
  bindOwnMusic();
  bindSonos();
  $("#mmini").addEventListener("click", e => {
    const c = e.target.closest("[data-mctl]");
    if (c && OWN.active) {
      const k = c.dataset.mctl;
      if (k === "toggle") ownToggle();
      if (k === "next") ownStep(1);
      if (k === "prev") ownStep(-1);
      return;
    }
    if (c && M.mk) {
      const k = c.dataset.mctl;
      if (k === "toggle") musicPlaying() ? M.mk.pause() : M.mk.play();
      if (k === "next") M.mk.skipToNextItem();
      if (k === "prev") M.mk.skipToPreviousItem();
      return;
    }
    if (e.target.closest("#mmOpen")) $('#kindSeg button[data-kind="music"]').click();
  });
  $("#libBody").addEventListener("click", async e => {
    if (S.kind !== "music" || musicSource() === "own") return;
    const t = e.target;
    const hit = sel => t.closest(sel);
    const top = M.stack[M.stack.length - 1];
    if (hit("[data-mctl]") && M.mk) {
      e.stopPropagation();
      const c = hit("[data-mctl]").dataset.mctl;
      if (c === "toggle") musicPlaying() ? M.mk.pause() : M.mk.play();
      if (c === "next") M.mk.skipToNextItem();
      if (c === "prev") M.mk.skipToPreviousItem();
      return;
    }
    if (hit("[data-mback]")) { e.stopPropagation(); M.stack.pop(); renderLibrary(); return; }
    if (hit("[data-mplayall]") && top) { e.stopPropagation(); musicPlayTrack(top.key, null); return; }
    if (hit("[data-mshuffle]") && top) { e.stopPropagation(); musicPlayTrack(top.key, null, true); return; }
    if (hit("[data-madd]") && top) {
      e.stopPropagation();
      const b = hit("[data-madd]"); b.disabled = true;
      try {
        await musicAddToLibrary(M.items[top.key]);
        b.outerHTML = `<span class="mh-lib">${icon("check")}Hinzugefügt</span>`;
        toast(`«${(M.items[top.key].attributes || {}).name}» ist jetzt in deiner Mediathek.`);
      } catch (err) { b.disabled = false; toast(err.message || String(err), null, null, 7000); }
      return;
    }
    const tr = hit("[data-tidx]");
    if (tr && top) { e.stopPropagation(); musicPlayTrack(top.key, +tr.dataset.tidx); return; }
    const row = hit("[data-mkey]");
    if (row) {
      e.stopPropagation();
      const it = M.items[row.dataset.mkey];
      if (!it) return;
      if (hit("[data-mrowplay]") || !opensDetail(it.type)) return musicPlayItem(it);
      M.stack.push({ key: row.dataset.mkey, q: (S.q || "").trim() });
      renderLibrary();
      $("#libBody").scrollTop = 0; window.scrollTo(0, 0);
    }
  }, true);
}

async function musicSignOut() {
  if (M.mk) { try { await M.mk.unauthorize(); } catch (e) { } }
  musicForget();
  try { localStorage.setItem(MHOME, "null"); } catch (e) { }
  toast("Von Apple Music abgemeldet.");
}

function musicSettingsHTML() {
  return `<h3>Musik</h3>
    <label class="switch"><input type="checkbox" id="musicIn" ${musicEnabled() ? "checked" : ""}><span class="tr"></span><span>Musik anzeigen (Apple Music)</span></label>
    ${musicEnabled() && M.mk && M.mk.isAuthorized ? `<p class="hint">Mit Apple Music verbunden. <a href="#" data-music-out>Abmelden</a></p>` : ""}`;
}
async function musicSettingsChange(on) {
  S.settings.music = on;
  await saveSettings({ music: on });
  applyMusicSetting();
  renderLibrary();
}
/* --- Nach einem Update: Musik dort weiterspielen, wo sie war --- */
function musicResumeInfo() {
  if (!(M.active && musicPlaying() && M.lastQueue && M.mk.nowPlayingItem)) return null;
  return { queue: M.lastQueue, pos: (M.mk.queue && M.mk.queue.position) || 0, ids: itemIds(M.mk.nowPlayingItem),
    time: M.mk.currentPlaybackTime || 0, shuffle: !!M.mk.shuffleMode };
}
async function musicResume(r) {
  try {
    const mk = await musicSetup();
    if (!mk.isAuthorized || !r || !r.queue) return;
    await musicStart(r.queue, { startWith: r.shuffle ? null : r.pos, want: r.ids, shuffle: r.shuffle });
    if (r.time > 3) {
      for (let i = 0; i < 25 && !musicPlaying(); i++) await new Promise(ok => setTimeout(ok, 200));   // warten, bis der Titel läuft
      await mk.seekToTime(r.time);
    }
    toast(`Aktualisiert auf Version ${window.VERSION}. Die Musik läuft weiter.`);
  } catch (e) { console.error("Musik weiterspielen", e); }
}

// Medientasten: läuft gerade Musik, gehört Play/Pause der Musik
function musicMediaKey() { if (musicPlaying()) { M.mk.pause(); return true; } return false; }

/* ---------------- Meine Musik (eigene Sammlung, z. B. FLAC vom NAS) ---------------- */
// Nur PC-Player und Heimserver (dort liegt die Sammlung; auf player.menet.ch gibt es sie nicht).
// Eigenes Audio-Element: so bleiben Hörbuch-Stand und Musik sauber getrennt.
const OWN = { el: new Audio(), queue: [], idx: -1, active: false, data: null, view: "albums", stack: [], cache: {}, tracksQ: "", tracksFound: null, refresh: null };
OWN.el.preload = "auto";
function ownAvailable() { return !!((S.settings.music_folders || []).length); }
function ownTrack() { return OWN.idx >= 0 ? OWN.queue[OWN.idx] || null : null; }
function ownPlaying() { return OWN.active && !OWN.el.paused; }
function ownCover(aid, big) { return aid ? `/musik/cover/${aid}${big ? "?gross=1" : ""}` : ""; }
function ownArt(aid, big, cls = "") { return aid ? `<img class="own-img ${cls}" loading="lazy" src="${ownCover(aid, big)}" alt="" onerror="this.remove()">` : ""; }

// --- Abspielen
function ownPlayList(tracks, idx = 0, shuffle = false) {
  if (!tracks || !tracks.length) return;
  const q = tracks.slice();
  if (shuffle) { for (let i = q.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [q[i], q[j]] = [q[j], q[i]]; } idx = 0; }
  OWN.queue = q; OWN.idx = Math.max(0, Math.min(idx, q.length - 1));
  ownLoad(true);
}
function ownLoad(play) {
  const t = ownTrack();
  if (!t) return;
  OWN.active = true; M.active = false;
  if (P.item && !audio.paused) audio.pause();
  if (musicPlaying()) M.mk.pause();
  OWN.el.src = `/musik/datei/${t.id}.${t.ext || "flac"}`;
  if (play) OWN.el.play().catch(e => { if (e.name !== "AbortError") toast("Abspielen nicht möglich: " + e.message); });
  ownMediaSession(); musicBar(); markOwnPlaying();
}
function ownStep(d) {
  if (!OWN.queue.length) return;
  if (d < 0 && OWN.el.currentTime > 4) { OWN.el.currentTime = 0; return; }   // wie überall: zuerst an den Anfang des Titels
  const n = OWN.idx + d;
  if (n < 0) { OWN.el.currentTime = 0; return; }
  if (n >= OWN.queue.length) { OWN.el.pause(); OWN.el.currentTime = 0; musicBar(); return; }
  OWN.idx = n; ownLoad(true);
}
function ownToggle() { if (OWN.el.paused) OWN.el.play().catch(() => { }); else OWN.el.pause(); }
let _ownErr = 0;
OWN.el.addEventListener("ended", () => ownStep(1));
OWN.el.addEventListener("playing", () => { _ownErr = 0; });
OWN.el.addEventListener("error", () => {
  if (!OWN.active || !OWN.el.getAttribute("src")) return;
  if (++_ownErr > 3) { toast("Mehrere Titel liessen sich nicht abspielen – ist der Musik-Ordner erreichbar?", null, null, 7000); return; }
  toast("Dieser Titel lässt sich hier nicht abspielen – weiter zum nächsten.");
  setTimeout(() => ownStep(1), 700);
});
OWN.el.addEventListener("play", () => {
  OWN.active = true; M.active = false;
  if (P.item && !audio.paused) audio.pause();
  if (musicPlaying()) M.mk.pause();
  musicBar();
});
OWN.el.addEventListener("pause", () => musicBar());
OWN.el.addEventListener("timeupdate", () => updateMusicTime());
// Startet ein Hörbuch, hält die eigene Musik an
audio.addEventListener("play", () => { if (!OWN.el.paused) OWN.el.pause(); OWN.active = false; musicBar(); });

function ownMediaSession() {
  const t = ownTrack();
  if (!("mediaSession" in navigator) || !t) return;
  navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist || "", album: t.album_title || "",
    artwork: t.album ? [{ src: location.origin + ownCover(t.album, true), sizes: "512x512" }] : [] });
}
function markOwnPlaying() {
  const t = ownTrack();
  $$("[data-otid]").forEach(r => r.classList.toggle("playing", !!t && OWN.active && r.dataset.otid === t.id));
}

// --- Daten
async function ownData(force) {
  if (force || !OWN.data) OWN.data = await api("/api/musik/uebersicht");
  return OWN.data;
}
async function ownAlbum(id) {
  if (!OWN.cache[id]) {
    const a = await api("/api/musik/album?id=" + encodeURIComponent(id));
    a.tracks.forEach(t => { t.album_title = a.title; t.album_artist = a.artist; });
    OWN.cache[id] = a;
  }
  return OWN.cache[id];
}

// --- Darstellung
function ownAlbumCard(a) {
  return `<div class="mcard" data-oalbum="${esc(a.id)}" title="${esc(a.title)}">
    <div class="mc-cover"><div class="mc-art">${icon("music")}${ownArt(a.id)}</div>
      <button class="mc-play" data-oplay="${esc(a.id)}" title="Gleich abspielen">${icon("play")}</button></div>
    <b>${esc(a.title)}</b><span>${esc([a.artist, a.year].filter(Boolean).join(" · "))}</span></div>`;
}
function ownArtistCard(r) {
  return `<div class="mcard" data-oartist="${esc(r.id)}" title="${esc(r.name)}">
    <div class="mc-cover round"><div class="mc-art">${icon("mic")}${ownArt(r.cover)}</div></div>
    <b>${esc(r.name)}</b><span>${r.n} ${r.n === 1 ? "Album" : "Alben"}</span></div>`;
}
function ownTrackRow(t, i, showAlbum) {
  const sub = showAlbum ? [t.artist, t.album_title].filter(Boolean).join(" · ") : (t.artist && t.album_artist && t.artist !== t.album_artist ? t.artist : "");
  return `<div class="mtrack" data-otidx="${i}" data-otid="${esc(t.id)}">
    <span class="tn"><i>${showAlbum ? i + 1 : (t.no || i + 1)}</i>${icon("play")}</span>
    <div class="rt"><b>${esc(t.title)}</b>${sub ? `<span>${esc(sub)}</span>` : ""}</div>
    <span class="rd">${t.duration ? fmtClock(t.duration) : ""}</span></div>`;
}
function musicSourceTabs() {
  if (!(ownAvailable() && musicEnabled())) return "";
  const src = musicSource();
  return `<div class="seg msrc"><button data-msrc="own" class="${src === "own" ? "on" : ""}">Meine Musik</button><button data-msrc="apple" class="${src === "apple" ? "on" : ""}">Apple Music</button></div>`;
}
function musicSource() {
  const own = ownAvailable(), apple = musicEnabled();
  if (own && apple) return S.settings.music_src === "apple" ? "apple" : "own";
  return own ? "own" : "apple";
}
function renderMusicArea(body, head) {
  if (musicSource() === "own") renderOwnMusic(body, head); else renderMusic(body, head);
  head.insertAdjacentHTML("beforeend", musicSourceTabs());
}

async function renderOwnMusic(body, head) {
  head.innerHTML = `<h2>Musik</h2><span class="sub">Meine Musik</span>`;
  clearTimeout(OWN.refresh);
  let D;
  try { D = await ownData(); }
  catch (e) { body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><p>Musik konnte nicht geladen werden: ${esc(e.message)}</p></div>`; return; }
  const st = D.status || {};
  if (st.running) OWN.refresh = setTimeout(async () => { await ownData(true).catch(() => { }); if (S.kind === "music" && musicSource() === "own" && !OWN.stack.length) renderLibrary(); }, 8000);
  if (!D.albums.length) {
    body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><h2>Meine Musik</h2>
      <p>${st.running ? `Deine Musik wird eingelesen … ${st.total ? `${st.done} von ${st.total} Dateien` : ""}<br><span class="hint">Beim ersten Mal dauert das bei einer grossen Sammlung einige Minuten.</span>`
        : `Noch keine Musik gefunden. Trage in den Einstellungen unter «Musik-Ordner» ein, wo deine Musik liegt${S.server ? " (z. B. /mnt/musik)" : ""}.`}</p></div>`;
    return;
  }
  const q = (S.q || "").trim();
  const top = OWN.stack[OWN.stack.length - 1];
  if (top && top.q !== q) OWN.stack = [];
  if (OWN.stack.length) return renderOwnDetail(body, OWN.stack[OWN.stack.length - 1]);
  const info = `<span class="sub">${D.status.albums} Alben · ${D.status.tracks} Titel${st.running ? " · wird aktualisiert …" : ""}</span>`;
  head.insertAdjacentHTML("beforeend", info);
  if (q) {
    const ql = q.toLowerCase();
    const ar = D.artists.filter(r => r.name.toLowerCase().includes(ql)).slice(0, 24);
    const al = D.albums.filter(a => a.title.toLowerCase().includes(ql) || a.artist.toLowerCase().includes(ql)).slice(0, 60);
    body.innerHTML = (ar.length ? `<section class="music-sec"><h3>Interpreten</h3><div class="mgrid">${ar.map(ownArtistCard).join("")}</div></section>` : "")
      + (al.length ? `<section class="music-sec"><h3>Alben</h3><div class="mgrid">${al.map(ownAlbumCard).join("")}</div></section>` : "")
      + `<section class="music-sec"><h3>Titel</h3><div class="mtracks" id="ownTracks"><div class="mloading"><span class="spinner"></span>suche …</div></div></section>`;
    if (OWN.tracksQ !== q) {
      OWN.tracksQ = q; OWN.tracksFound = null;
      await new Promise(r => setTimeout(r, 300));
      if (OWN.tracksQ !== q) return;
      const r = await api("/api/musik/suche?q=" + encodeURIComponent(q)).catch(() => ({ tracks: [] }));
      if (OWN.tracksQ !== q) return;
      OWN.tracksFound = r.tracks || [];
    }
    const el = $("#ownTracks");
    if (el) el.innerHTML = OWN.tracksFound.length ? OWN.tracksFound.map((t, i) => ownTrackRow(t, i, true)).join("") : `<p class="hint" style="padding:0 12px">Keine Titel gefunden.</p>`;
    markOwnPlaying();
    return;
  }
  const view = OWN.view;
  body.innerHTML = `<div class="own-bar"><div class="seg"><button data-oview="albums" class="${view === "albums" ? "on" : ""}">Alben</button><button data-oview="artists" class="${view === "artists" ? "on" : ""}">Interpreten</button><button data-oview="new" class="${view === "new" ? "on" : ""}">Neu</button></div>
      <button class="btn" data-omix>${icon("refresh")}Zufallsmix</button></div>
    <div class="mgrid">${view === "artists" ? D.artists.map(ownArtistCard).join("")
      : (view === "new" ? D.albums.slice().sort((a, b) => b.added - a.added).slice(0, 60) : D.albums).map(ownAlbumCard).join("")}</div>`;
}

async function renderOwnDetail(body, d) {
  body.innerHTML = `<div class="empty"><span class="spinner"></span></div>`;
  if (d.type === "album") {
    let a;
    try { a = await ownAlbum(d.id); } catch (e) { body.innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`; return; }
    const discs = new Set(a.tracks.map(t => t.disc)).size > 1;
    let rows = "", lastDisc = null;
    a.tracks.forEach((t, i) => {
      if (discs && t.disc !== lastDisc) { rows += `<h3 class="mh-sec">CD ${t.disc}</h3>`; lastDisc = t.disc; }
      rows += ownTrackRow(t, i, false);
    });
    body.innerHTML = `<button class="btn mback" data-oback>${icon("chev-left")}Zurück</button>
      <div class="mhero"><div class="mh-cover">${icon("music")}${ownArt(a.id, true)}</div>
        <div class="mh-txt"><span class="mh-kind">Album</span><h2>${esc(a.title)}</h2>
          <p><a href="#" data-oartist="${esc(a.artist_id)}">${esc(a.artist)}</a>${a.year ? " · " + esc(a.year) : ""} · ${a.tracks.length} Titel · ${fmtDur(a.duration)}</p>
          <div class="mh-btns"><button class="btn primary" data-oall>${icon("play")}Abspielen</button><button class="btn" data-oshuffle>${icon("refresh")}Zufällig</button></div></div></div>
      <div class="mtracks">${rows}</div>`;
  } else {
    let r;
    try { r = await api("/api/musik/interpret?id=" + encodeURIComponent(d.id)); } catch (e) { body.innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`; return; }
    const al = r.albums.map(x => ({ ...x, artist: r.name })).reverse();
    body.innerHTML = `<button class="btn mback" data-oback>${icon("chev-left")}Zurück</button>
      <div class="mhero"><div class="mh-cover round">${icon("mic")}${al.length ? ownArt(al[0].id, true) : ""}</div>
        <div class="mh-txt"><span class="mh-kind">Interpret</span><h2>${esc(r.name)}</h2><p>${al.length} ${al.length === 1 ? "Album" : "Alben"}</p>
          <div class="mh-btns"><button class="btn primary" data-oartall>${icon("play")}Alles abspielen</button><button class="btn" data-oartshuffle>${icon("refresh")}Zufällig</button></div></div></div>
      <section class="music-sec"><h3>Alben</h3><div class="mgrid">${al.map(ownAlbumCard).join("")}</div></section>`;
    d.albums = r.albums.map(x => x.id);
  }
  markOwnPlaying();
}

function ownOpen(type, id) {
  OWN.stack.push({ type, id, q: (S.q || "").trim() });
  renderLibrary();
  $("#libBody").scrollTop = 0; window.scrollTo(0, 0);
}
async function ownArtistTracks(d) {
  const all = [];
  for (const id of d.albums || []) all.push(...(await ownAlbum(id)).tracks);
  return all;
}

function bindOwnMusic() {
  $("#libHead").addEventListener("click", e => {
    const b = e.target.closest("[data-msrc]");
    if (!b) return;
    S.settings.music_src = b.dataset.msrc;
    saveSettingsSoon({ music_src: b.dataset.msrc });
    renderLibrary();
  });
  $("#libBody").addEventListener("click", async e => {
    if (S.kind !== "music" || musicSource() !== "own") return;
    const t = e.target, hit = s => t.closest(s);
    const top = OWN.stack[OWN.stack.length - 1];
    const stop = () => { e.preventDefault(); e.stopPropagation(); };
    if (hit("[data-oview]")) { stop(); OWN.view = hit("[data-oview]").dataset.oview; renderLibrary(); return; }
    if (hit("[data-omix]")) { stop(); const r = await api("/api/musik/zufall").catch(() => ({ tracks: [] })); ownPlayList(r.tracks, 0); return; }
    if (hit("[data-oback]")) { stop(); OWN.stack.pop(); renderLibrary(); return; }
    if (hit("[data-oplay]")) { stop(); const a = await ownAlbum(hit("[data-oplay]").dataset.oplay); ownPlayList(a.tracks, 0); return; }
    if (hit("[data-oall]") && top) { stop(); ownPlayList((await ownAlbum(top.id)).tracks, 0); return; }
    if (hit("[data-oshuffle]") && top) { stop(); ownPlayList((await ownAlbum(top.id)).tracks, 0, true); return; }
    if (hit("[data-oartall]") && top) { stop(); ownPlayList(await ownArtistTracks(top), 0); return; }
    if (hit("[data-oartshuffle]") && top) { stop(); ownPlayList(await ownArtistTracks(top), 0, true); return; }
    const row = hit("[data-otidx]");
    if (row) {
      stop();
      const i = +row.dataset.otidx;
      if (top && top.type === "album") ownPlayList((await ownAlbum(top.id)).tracks, i);
      else if (OWN.tracksFound) ownPlayList(OWN.tracksFound, i);
      return;
    }
    if (hit("[data-oalbum]")) { stop(); ownOpen("album", hit("[data-oalbum]").dataset.oalbum); return; }
    if (hit("[data-oartist]")) { stop(); ownOpen("artist", hit("[data-oartist]").dataset.oartist); return; }
  }, true);
}

/* ---------------- Sonos (nur Heimserver) ---------------- */
// Die Box holt den Ton selbst vom Heimserver; diese Seite ist nur Fernbedienung. Der Heimserver speichert beim Hörbuch den Hörstand.
const SON = { st: null, timer: null, busy: false, seekAt: 0 };
function sonosActive() { return !!(SON.st && SON.st.active); }
function sonosBook(id) { return sonosActive() && SON.st.kind === "book" && (!id || SON.st.item === id); }

async function sonosPicker() {
  openModal(`<h2>Lautsprecher</h2><p class="hint">Suche Sonos-Räume im Heimnetz …</p><div class="empty"><span class="spinner"></span></div>`);
  $("#modal").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); };
  const draw = (groups, err) => {
    const cur = sonosActive() ? SON.st.group : null;
    $("#modal").innerHTML = `<h2>Lautsprecher</h2>
      <p class="hint">Wähle, wo ${OWN.active || (sonosActive() && SON.st.kind === "music") ? "die Musik" : "das Hörbuch"} spielen soll. Die Sonos-Box holt den Ton direkt vom Heimserver – dieses Gerät ist dann nur noch Fernbedienung.</p>
      <div class="spk-list">
        <button class="spk${cur ? "" : " on"}" data-spk-local>${icon("headphones")}<span><b>Dieses Gerät</b><small>${cur ? "Wiedergabe zurückholen" : "spielt hier"}</small></span></button>
        ${(groups || []).map(g => `<button class="spk${g.id === cur ? " on" : ""}" data-spk-group="${esc(g.id)}">${icon("speaker")}<span><b>${esc(g.name)}</b><small>Sonos${g.id === cur ? " · spielt hier" : ""}</small></span></button>`).join("")}
      </div>
      ${err ? `<p class="hint" style="color:var(--accent)">${esc(err)}</p>` : (groups && !groups.length ? `<p class="hint">Keine Sonos-Boxen gefunden. Sind sie eingeschaltet und im gleichen Netz wie der Heimserver? Sonst ihre Adresse in den Einstellungen unter «Sonos» eintragen.</p>` : "")}
      <div class="foot"><button class="btn" data-spk-refresh>${icon("refresh")}Neu suchen</button><span style="flex:1"></span><button class="btn" data-x>Schliessen</button></div>`;
  };
  const load = async fresh => {
    const r = await api("/api/sonos/raeume", { neu: fresh }).catch(e => ({ error: e.message }));
    draw(r.groups || [], r.error);
  };
  $("#modal").onclick = async e => {
    const t = e.target;
    if (t.closest("[data-x]")) return closeModal();
    if (t.closest("[data-spk-refresh]")) { $("#modal").querySelector(".spk-list").style.opacity = .5; return load(true); }
    if (t.closest("[data-spk-local]")) { closeModal(); if (sonosActive()) await sonosBackHere(); return; }
    const g = t.closest("[data-spk-group]");
    if (g) { closeModal(); await sonosStart(g.dataset.spkGroup); }
  };
  load(false);
}

async function sonosStart(group) {
  let body;
  const music = ownPlaying() || (!(P.item && P.playing) && OWN.active && ownTrack());   // was gerade läuft, hat Vorrang
  if (music) {
    body = { group, kind: "music", ids: OWN.queue.map(t => t.id), idx: OWN.idx, t: OWN.el.currentTime || 0 };
    OWN.el.pause();
  } else if (sonosActive()) {
    // läuft schon auf Sonos: in einen anderen Raum umziehen
    const old = await api("/api/sonos/befehl", { cmd: "stop" }).catch(() => null);
    if (!old) return;
    body = old.kind === "book" ? { group, kind: "book", id: old.item, pos: old.pos } : { group, kind: "music", ids: old.ids, idx: old.idx, t: old.rel };
  } else if (P.item) {
    const pos = P.pos();
    audio.pause();
    await saveProgress(true);
    body = { group, kind: "book", id: P.item.id, pos };
  } else {
    return toast("Starte zuerst ein Hörbuch oder Musik – dann kannst du es auf Sonos weitergeben.");
  }
  toast("Verbinde mit Sonos …", null, null, 2500);
  const r = await api("/api/sonos/start", body).catch(e => ({ error: e.message }));
  if (r.error) return toast("Sonos: " + r.error, null, null, 7000);
  OWN.active = false;
  sonosShow(r);
  toast(`Spielt jetzt auf «${r.group_name}».`);
}

async function sonosBackHere() {
  const r = await api("/api/sonos/befehl", { cmd: "stop" }).catch(e => ({ error: e.message }));
  SON.st = null; sonosShow(null);
  if (!r || r.error) return toast("Sonos: " + ((r && r.error) || "keine Antwort"));
  if (r.kind === "book" && r.item) {
    if (!(P.item && P.item.id === r.item)) { await openItem(r.item, false); showView("library"); }
    P.seek(r.pos, true);
    if (!P.playing) togglePlay();      // innerhalb derselben Datei springt seek nur, ohne abzuspielen
  } else if (r.kind === "music" && r.ids && r.ids.length) {
    const same = OWN.queue.length === r.ids.length && OWN.queue.every((t, i) => t.id === r.ids[i]);
    if (same) {
      OWN.idx = r.idx; ownLoad(true);
      OWN.el.addEventListener("loadedmetadata", () => { OWN.el.currentTime = r.rel || 0; }, { once: true });
    }
  }
  toast("Spielt wieder auf diesem Gerät.");
}

async function sonosCmd(cmd, value) {
  if (!sonosActive()) return;
  if (cmd === "seek" || cmd === "skip") SON.seekAt = Date.now();
  const r = await api("/api/sonos/befehl", { cmd, value }).catch(e => ({ error: e.message }));
  if (r.error) return toast("Sonos: " + r.error, null, null, 6000);
  sonosShow(r);
}

function sonosShow(st) {
  SON.st = st && st.active ? st : null;
  const bar = $("#sbar");
  if (!bar) return;
  clearTimeout(SON.timer);
  if (!SON.st) {
    bar.hidden = true;
    musicBar();          // normale Leiste unten wieder zeigen (Hörbuch oder Musik)
    if (S.view === "library" && P.item && !OWN.active) $("#mini").hidden = false;
    return;
  }
  const s = SON.st;
  bar.hidden = false;
  $("#mini").hidden = true; $("#mmini").hidden = true;
  if (bar.dataset.cover !== s.cover) { bar.dataset.cover = s.cover || ""; $("#sbCover").innerHTML = `<span class="ph">${icon(s.kind === "book" ? "headphones" : "music")}</span>` + (s.cover ? `<img class="own-img" src="${esc(s.cover)}" alt="" onerror="this.remove()">` : ""); }
  $("#sbTitle").textContent = s.title || "";
  $("#sbSub").textContent = s.sub || "";
  $("#sbRoom").innerHTML = `${icon("speaker")}${esc(s.group_name)}`;
  $("#sbBack").innerHTML = icon(s.kind === "book" ? "back" : "prev");
  $("#sbFwd").innerHTML = icon(s.kind === "book" ? "fwd" : "next");
  $("#sbBack").title = s.kind === "book" ? "30 s zurück" : "Voriger Titel";
  $("#sbFwd").title = s.kind === "book" ? "30 s vor" : "Nächster Titel";
  $("#sbPlay").innerHTML = icon(s.playing ? "pause" : "play");
  if (s.volume != null && document.activeElement !== $("#sbVol")) $("#sbVol").value = s.volume;
  if (!$("#sbar .mini-prog").dataset.drag && Date.now() - SON.seekAt > 1500) {
    $("#sbProg").style.width = s.total ? Math.min(100, s.pos / s.total * 100) + "%" : "0";
    $("#sbTime").textContent = s.total ? `${fmtClock(s.pos)} / ${fmtClock(s.total)}` : "";
  }
  if (s.error) $("#sbSub").textContent = "⚠ " + s.error;
  SON.timer = setTimeout(sonosPoll, document.hidden ? 5000 : 1000);
}
async function sonosPoll() {
  const r = await api("/api/sonos/stand", {}).catch(() => null);
  if (!r) { SON.timer = setTimeout(sonosPoll, 3000); return; }
  if (sonosActive() && !r.active) toast("Sonos spielt nicht mehr von MyPlayer (z. B. in der Sonos-App etwas anderes gewählt).", null, null, 6000);
  sonosShow(r);
}

function bindSonos() {
  const bar = $("#sbar");
  if (!bar) return;
  bar.addEventListener("click", e => {
    const t = e.target, s = SON.st;
    if (!s) return;
    if (t.closest("#sbPlay")) return sonosCmd("toggle");
    if (t.closest("#sbBack")) return s.kind === "book" ? sonosCmd("skip", -30) : sonosCmd("prev");
    if (t.closest("#sbFwd")) return s.kind === "book" ? sonosCmd("skip", 30) : sonosCmd("next");
    if (t.closest("#sbRoom")) return sonosPicker();
  });
  $("#sbVol").addEventListener("input", debounce(e => sonosCmd("volume", +e.target.value), 250));
  bindProgDrag($("#sbar .mini-prog"), $("#sbProg"), () => (SON.st && SON.st.total) || 0, t => sonosCmd("seek", t),
    t => { $("#sbTime").textContent = `${fmtClock(t)} / ${fmtClock(SON.st.total)}`; });
  $$("[data-spk]").forEach(b => { b.onclick = e => { e.stopPropagation(); sonosPicker(); }; });
  // startet hier etwas, endet die Wiedergabe auf Sonos (immer nur eine Wiedergabe je Person)
  const localStarted = () => {
    if (!sonosActive() || SON.busy) return;
    const name = SON.st.group_name;
    api("/api/sonos/befehl", { cmd: "stop" }).catch(() => { });
    SON.st = null; sonosShow(null);
    toast(`Wiedergabe auf «${name}» beendet – spielt jetzt hier.`);
  };
  audio.addEventListener("play", localStarted);
  OWN.el.addEventListener("play", localStarted);
}

/* ---------------- Mini-Player ---------------- */
// PC-Player: eigenes kleines Edge-Fenster «MyPlayer (mini)» (desktop/web/mini.html), das hier ferngesteuert wird.
// Web: Document Picture-in-Picture (Chrome/Edge am Computer; auf dem iPhone gibt es das nicht → Knopf bleibt versteckt).
const PIP = { win: null, timer: null, mode: "", key: null, miniSeen: 0, ch: null };
function pipSupported() { return "documentPictureInPicture" in window; }

// Was gerade läuft – für beide Arten von Mini-Player
function pipState() {
  const now = M.active && M.mk && M.mk.nowPlayingItem;
  const theme = document.documentElement.dataset.theme || "dark";
  if (sonosActive()) {
    const x = SON.st;
    return { mode: x.kind === "book" ? "book" : "music", key: "sonos:" + (x.item || x.track || ""), title: x.title, sub: `${x.sub} · ${x.group_name}`,
      cover: x.cover ? location.origin + x.cover : null, t: x.pos || 0, dur: x.total || 0, playing: !!x.playing, theme };
  }
  const own = OWN.active && ownTrack();
  if (own) {
    const { t, d } = musicNow();
    return { mode: "music", key: "own:" + own.id, title: own.title, sub: own.artist || "", cover: own.album ? location.origin + ownCover(own.album) : null,
      t, dur: d, playing: !OWN.el.paused, theme };
  }
  if (now) {
    const a = now.attributes || now;
    const img = String(now.artworkURL || art(now, 200) || "").replace("{w}", 200).replace("{h}", 200);
    return { mode: "music", key: now.id, title: a.name || now.title || "", sub: a.artistName || now.artistName || "", cover: img || null,
      t: M.mk.currentPlaybackTime || 0, dur: M.mk.currentPlaybackDuration || 0, playing: musicPlaying(), theme };
  }
  if (P.item) {
    const img = $("#miniCover img");
    return { mode: "book", key: P.item.id, title: $("#miniTitle").textContent, sub: $("#miniSub").textContent, cover: img ? img.src : null,
      t: P.pos(), dur: P.total, playing: !audio.paused, theme };
  }
  return { mode: "none", key: null, title: "Gerade läuft nichts", sub: "Wähle im grossen Fenster ein Hörbuch oder Musik.", cover: null, t: 0, dur: 0, playing: false, theme };
}
// Tasten des Mini-Players
function pipCommand(k, t) {
  if (sonosActive()) {
    const book = SON.st.kind === "book";
    if (k === "toggle") sonosCmd("toggle");
    if (k === "back") book ? sonosCmd("skip", -30) : sonosCmd("prev");
    if (k === "fwd") book ? sonosCmd("skip", 30) : sonosCmd("next");
    if (k === "seek" && t != null) sonosCmd("seek", t);
    return;
  }
  if (OWN.active && ownTrack()) {
    if (k === "toggle") ownToggle();
    if (k === "back") ownStep(-1);
    if (k === "fwd") ownStep(1);
    if (k === "seek" && t != null) OWN.el.currentTime = t;
    return;
  }
  const music = !!(M.active && M.mk && M.mk.nowPlayingItem);
  if (k === "toggle") { if (music) musicPlaying() ? M.mk.pause() : M.mk.play(); else if (P.item) togglePlay(); }
  if (k === "back") music ? M.mk.skipToPreviousItem() : skip(-SKIP);
  if (k === "fwd") music ? M.mk.skipToNextItem() : skip(SKIP);
  if (k === "seek" && t != null) music ? M.mk.seekToTime(t) : P.item && P.seek(t);
}

async function openMiniPlayer() {
  if (!IS_WEB && !S.server) {
    miniChannel();
    const r = await api("/api/fenster", { aktion: "mini_oeffnen" }).catch(() => ({}));
    if (!r || !r.ok) toast("Das Mini-Fenster liess sich nicht öffnen (Edge nicht gefunden?).");
    return;
  }
  if (PIP.win) { PIP.win.focus(); return; }
  let w;
  try { w = await documentPictureInPicture.requestWindow({ width: 400, height: 150 }); }
  catch (e) { toast("Der Mini-Player liess sich nicht öffnen: " + (e.message || e)); return; }
  PIP.win = w; PIP.mode = ""; PIP.key = null;
  const d = w.document;
  const base = d.createElement("base"); base.href = location.origin + "/"; d.head.append(base);
  // Aussehen übernehmen; das Fenster erst zeigen, wenn es geladen ist (sonst kurz ungestaltet)
  d.documentElement.style.visibility = "hidden";
  const loads = [];
  for (const l of document.querySelectorAll('link[rel="stylesheet"]')) {
    const n = d.createElement("link"); n.rel = "stylesheet"; n.href = l.href;
    loads.push(new Promise(r => { n.onload = n.onerror = r; }));
    d.head.append(n);
  }
  Promise.race([Promise.all(loads), new Promise(r => setTimeout(r, 1500))]).then(() => { d.documentElement.style.visibility = ""; });
  for (const st of document.querySelectorAll("style")) d.head.append(st.cloneNode(true));
  d.title = "MyPlayer (mini)";
  d.body.className = "pip-body";
  const sprite = document.querySelector('body > svg[aria-hidden="true"]');
  if (sprite) d.body.append(sprite.cloneNode(true));
  d.body.insertAdjacentHTML("beforeend", `<div class="pip">
    <div class="pip-cover" id="pipCover"></div>
    <div class="pip-main">
      <div class="pip-head"><div class="pip-txt"><b id="pipTitle"></b><span id="pipSub"></span></div>
        <button class="icon-btn sm" data-pip="big" title="Grosses Fenster">${icon("expand")}</button></div>
      <div class="pip-ctl">
        <button class="ctl sm" data-pip="back" id="pipBack"></button>
        <button class="ctl play sm" data-pip="toggle" id="pipPlay" title="Abspielen / Pause"></button>
        <button class="ctl sm" data-pip="fwd" id="pipFwd"></button>
        <span class="pip-time" id="pipTime"></span></div>
      <div class="mini-prog" id="pipBar"><div id="pipProg"></div></div>
    </div></div>`);
  const g = id => d.getElementById(id);
  d.addEventListener("click", e => {
    const b = e.target.closest("[data-pip]");
    if (!b) return;
    if (b.dataset.pip === "big") { w.close(); return; }
    pipCommand(b.dataset.pip);
    setTimeout(pipUpdate, 150);
  });
  d.addEventListener("keydown", e => {
    if (e.code === "Space") { e.preventDefault(); pipCommand("toggle"); }
    if (e.key === "ArrowLeft") pipCommand("back");
    if (e.key === "ArrowRight") pipCommand("fwd");
  });
  bindProgDrag(g("pipBar"), g("pipProg"), () => pipState().dur, t => pipCommand("seek", t));
  w.addEventListener("pagehide", () => { clearInterval(PIP.timer); PIP.win = null; });
  pipUpdate();
  PIP.timer = w.setInterval(pipUpdate, 500);
}

function pipUpdate() {
  const w = PIP.win;
  if (!w) return;
  const d = w.document, g = id => d.getElementById(id), s = pipState();
  d.documentElement.dataset.theme = s.theme;
  if (s.mode !== PIP.mode) {
    PIP.mode = s.mode; PIP.key = undefined;
    g("pipBack").innerHTML = icon(s.mode === "music" ? "prev" : "back");
    g("pipFwd").innerHTML = icon(s.mode === "music" ? "next" : "fwd");
    g("pipBack").title = s.mode === "music" ? "Voriger Titel" : "30 s zurück";
    g("pipFwd").title = s.mode === "music" ? "Nächster Titel" : "30 s vor";
  }
  if (PIP.key !== s.key) {
    PIP.key = s.key;
    g("pipCover").innerHTML = s.cover ? `<img src="${esc(s.cover)}" alt="">` : `<span class="ph">${icon(s.mode === "music" ? "music" : "headphones")}</span>`;
  }
  g("pipTitle").textContent = s.title;
  g("pipSub").textContent = s.sub;
  const pl = s.playing ? "pause" : "play";
  if (g("pipPlay").dataset.st !== pl) { g("pipPlay").dataset.st = pl; g("pipPlay").innerHTML = icon(pl); }
  g("pipTime").textContent = s.dur ? `${fmtClock(s.t)} / ${fmtClock(s.dur)}` : "";
  if (!g("pipBar").dataset.drag) g("pipProg").style.width = s.dur ? (s.t / s.dur * 100) + "%" : "0";
}

// PC-Player: Verbindung zum Mini-Fenster (gleiche Adresse → BroadcastChannel)
function miniChannel() {
  if (PIP.ch || IS_WEB || !("BroadcastChannel" in window)) return;
  const ch = PIP.ch = new BroadcastChannel("myplayer-mini");
  const post = () => ch.postMessage({ typ: "stand", ...pipState() });
  ch.onmessage = e => {
    const m = e.data || {};
    if (m.cmd === "hallo") { PIP.miniSeen = Date.now(); post(); return; }
    if (m.cmd === "tschuess" || m.cmd === "gross") { PIP.miniSeen = 0; api("/api/fenster", { aktion: "vorne" }).catch(() => { }); return; }
    pipCommand(m.cmd, m.t);
    setTimeout(post, 150);
  };
  setInterval(() => { if (Date.now() - PIP.miniSeen < 3000) post(); }, 500);
  window.addEventListener("pagehide", () => ch.postMessage({ typ: "zu" }));   // grosses Fenster zu → Mini auch
}
if (!IS_WEB) miniChannel();   // auch ein noch offenes Mini-Fenster (z. B. nach Neuladen) wieder verbinden

{
  const b = $("#pipBtn");
  if (b) { b.hidden = IS_WEB && !pipSupported(); b.onclick = openMiniPlayer; }
}

/* ---------------- Heimserver: Profile («Wer hört?») ---------------- */
// Nur auf dem Heimserver (Start mit --server): jede Person hat ihren eigenen Hörstand, ihre Einstellungen und ihr Konto bei player.menet.ch.
function profileAvatar(p, cls = "pf-av") {
  return `<span class="${cls}" style="background:${esc(p.color || "#f4a640")}">${esc((p.name || "?").trim().charAt(0).toUpperCase())}</span>`;
}
function currentProfile() { return S.profiles && S.profiles.list.find(p => p.id === S.profiles.current); }
function renderProfileBtn() {
  const b = $("#profileBtn"), p = currentProfile();
  if (!b) return;
  b.hidden = !(S.server && p);
  if (p) { b.innerHTML = profileAvatar(p, "pf-av sm"); b.title = `${p.name} – Profil wechseln`; b.onclick = () => showProfilePicker(false); }
}
function showProfilePicker(required) {
  document.querySelector(".profiles-ov")?.remove();
  const ov = document.createElement("div");
  ov.className = "profiles-ov";
  const draw = () => {
    const list = (S.profiles && S.profiles.list) || [];
    ov.innerHTML = `<div class="pf-box">
      <div class="pf-logo">${icon("headphones")}</div>
      <h1>Wer hört?</h1>
      <p class="hint">${list.length ? "Jede Person hat ihren eigenen Hörstand, ihre Lesezeichen und Einstellungen." : "Lege für jede Person ein Profil an – mit eigenem Hörstand, Lesezeichen und Einstellungen."}</p>
      <div class="pf-grid">
        ${list.map(p => `<button class="pf-tile${p.id === S.profiles.current ? " on" : ""}" data-pf="${esc(p.id)}">${profileAvatar(p)}<b>${esc(p.name)}</b></button>`).join("")}
        <button class="pf-tile pf-new" data-pf-new><span class="pf-av">${icon("plus")}</span><b>Neues Profil</b></button>
      </div>
      <form class="pf-form" hidden><input type="text" maxlength="40" placeholder="Name, z. B. Thomas" autocomplete="off"><button class="btn primary">Anlegen</button></form>
      ${required ? "" : `<button class="btn pf-x" data-pf-x>Abbrechen</button>`}
    </div>`;
  };
  draw();
  document.body.append(ov);
  ov.onclick = async e => {
    const t = e.target;
    if (t.closest("[data-pf-x]")) { ov.remove(); return; }
    if (t.closest("[data-pf-new]")) { const f = ov.querySelector(".pf-form"); f.hidden = false; f.querySelector("input").focus(); return; }
    const tile = t.closest("[data-pf]");
    if (tile) {
      const r = await api("/api/profil/waehlen", { id: tile.dataset.pf }).catch(err => ({ error: err.message }));
      if (r.error) return toast(r.error);
      location.reload();
    }
  };
  ov.onsubmit = async e => {
    e.preventDefault();
    const name = ov.querySelector(".pf-form input").value.trim();
    if (!name) return;
    const r = await api("/api/profil/neu", { name }).catch(err => ({ error: err.message }));
    if (r.error) return toast(r.error);
    location.reload();
  };
}
function profilesSettingsHTML() {
  if (!S.server) return "";
  const list = (S.profiles && S.profiles.list) || [];
  return `<h3>Profile</h3><p class="hint">Wer den Heimserver benutzt. Entfernen behält eine Sicherung des Hörstands auf dem Server.</p>
    <ul class="folders pf-list">${list.map(p => `<li>${profileAvatar(p, "pf-av sm")}<span>${esc(p.name)}${p.id === S.profiles.current ? " (du)" : ""}</span>
      <button class="icon-btn sm" data-pf-ren="${esc(p.id)}" title="Umbenennen">${icon("edit")}</button>
      ${p.id === S.profiles.current ? "" : `<button class="icon-btn sm" data-pf-del="${esc(p.id)}" title="Entfernen">${icon("trash")}</button>`}</li>`).join("")}</ul>`;
}
async function profilesSettingsClick(t) {
  const ren = t.closest("[data-pf-ren]"), del = t.closest("[data-pf-del]");
  if (!ren && !del) return false;
  const id = (ren || del).dataset.pfRen || (ren || del).dataset.pfDel;
  const p = S.profiles.list.find(x => x.id === id);
  if (ren) {
    const name = prompt("Neuer Name:", p ? p.name : "");
    if (!name) return true;
    const r = await api("/api/profil/umbenennen", { id, name }).catch(err => ({ error: err.message }));
    if (r.error) { toast(r.error); return true; }
    S.profiles = r.profiles;
  } else {
    if (!confirm(`Profil «${p ? p.name : id}» entfernen? Der Hörstand bleibt als Sicherung auf dem Server.`)) return true;
    const r = await api("/api/profil/loeschen", { id }).catch(err => ({ error: err.message }));
    if (r.error) { toast(r.error); return true; }
    S.profiles = r.profiles;
  }
  $("#pfSec").innerHTML = profilesSettingsHTML();
  renderProfileBtn();
  return true;
}
// Nach einem Update auf dem Heimserver: warten, bis die neue Version läuft, dann neu laden
function waitForRestart() {
  const t = setInterval(async () => {
    try {
      const r = await fetch("/api/init", { cache: "no-store" });
      if (r.ok && (await r.json()).version !== window.VERSION) { clearInterval(t); location.reload(); }
    } catch (e) { }
  }, 2500);
}

/* ---------------- Media Session (Medientasten) ---------------- */
function updateMediaSession() {
  if (!("mediaSession" in navigator) || !P.item) return;
  const ch = P.chapters[P.chapterIdx()];
  const art = P.item.cover ? [{ src: location.origin + "/cover/" + P.item.cover + "?big=1", sizes: "512x512" }] : [];
  navigator.mediaSession.metadata = new MediaMetadata({
    title: P.chapters.length > 1 && ch ? ch.title : P.item.title,
    artist: P.item.author || P.item.show || "",
    album: P.item.title, artwork: art,
  });
}
if ("mediaSession" in navigator) {
  const ms = navigator.mediaSession;
  const h = (a, f) => { try { ms.setActionHandler(a, f); } catch (e) { } };
  const own = () => OWN.active && ownTrack();   // läuft gerade «Meine Musik»?
  const son = () => sonosActive();                 // läuft gerade etwas auf Sonos?
  const sh = (a, f) => h(a, d => son() ? ({ play: () => sonosCmd("play"), pause: () => sonosCmd("pause"), seekbackward: () => sonosCmd(SON.st.kind === "book" ? "skip" : "prev", -30),
    seekforward: () => sonosCmd(SON.st.kind === "book" ? "skip" : "next", 30), previoustrack: () => sonosCmd("prev"), nexttrack: () => sonosCmd("next"),
    seekto: () => sonosCmd("seek", d.seekTime) }[a] || (() => { }))() : f(d));
  sh("play", () => own() ? OWN.el.play() : togglePlay()); sh("pause", () => { if (own()) OWN.el.pause(); else if (!musicMediaKey()) audio.pause(); });
  sh("seekbackward", () => own() ? (OWN.el.currentTime -= 10) : skip(-SKIP)); sh("seekforward", () => own() ? (OWN.el.currentTime += 10) : skip(SKIP));
  sh("previoustrack", () => own() ? ownStep(-1) : prevChapter()); sh("nexttrack", () => own() ? ownStep(1) : nextChapter());
  sh("seekto", d => own() ? (OWN.el.currentTime = d.seekTime) : P.seek(d.seekTime));
  h("stop", () => audio.pause());
}

/* ---------------- Ereignisse ---------------- */
function bind() {
  $("#kindSeg").onclick = e => { const b = e.target.closest("button"); if (!b) return; S.kind = b.dataset.kind; $$("#kindSeg button").forEach(x => x.classList.toggle("on", x === b)); showView("library"); renderLibrary(); };
  $("#chipFav").onclick = () => { S.fav = !S.fav; if (S.fav) S.arch = false; syncChips(); showView("library"); renderLibrary(); };
  $("#chipArch").onclick = () => { S.arch = !S.arch; if (S.arch) S.fav = false; syncChips(); showView("library"); renderLibrary(); };
  $("#search").oninput = debounce(e => { S.q = e.target.value; if (S.view !== "library") showView("library"); renderLibrary(); }, 120);
  $("#sortSel").onchange = e => { S.settings.sort = e.target.value; saveSettingsSoon({ sort: e.target.value }); renderLibrary(); };
  $("#viewBtn").onclick = () => { S.settings.view = S.settings.view === "list" ? "grid" : "list"; saveSettingsSoon({ view: S.settings.view }); syncViewBtn(); showView("library"); renderLibrary(); };
  $("#themeBtn").onclick = () => { S.settings.theme = S.settings.theme === "light" ? "dark" : "light"; applyTheme(); saveSettingsSoon({ theme: S.settings.theme }); };
  $("#settingsBtn").onclick = settingsDialog;
  $("#updPill").onclick = updateDialog;
  $("#cloudInfo").onclick = settingsDialog;
  $("#updBanner").onclick = e => {
    const b = e.target.closest("[data-u]"); if (!b) return;
    if (b.dataset.u === "notes") updateDialog();
    if (b.dataset.u === "apply") applyUpdate();
    if (b.dataset.u === "later") { S.updDismissed = S.update.latest; showUpdate(S.update); }
  };
  bindMusic();
  $("#libBody").addEventListener("click", libClick);
  bindLongPress();
  // Handy (Heimserver): Lupe in der Titelleiste klappt das Suchfeld auf; schliessen löscht die Suche
  const setSearch = open => {
    document.body.classList.toggle("search-open", open);
    $("#searchBtn").classList.toggle("on", open);
    if (open) setTimeout(() => $("#search").focus(), 30);
    else if (S.q) { $("#search").value = ""; S.q = ""; renderLibrary(); }
  };
  $("#searchBtn").onclick = () => setSearch(!document.body.classList.contains("search-open"));
  $("#searchClose").onclick = e => { e.preventDefault(); setSearch(false); };
  // Handy: Kapitel/Lesezeichen als Blatt von unten
  $("#sheetBtn").onclick = () => { document.body.classList.add("sheet-open"); scrollToCurrentChapter(true); };
  $("#sheetClose").onclick = () => document.body.classList.remove("sheet-open");
  $("#chapterList").addEventListener("click", () => document.body.classList.remove("sheet-open"));
  $("#libBody").addEventListener("keydown", e => { if (e.key === "Enter" && e.target.closest(".card")) openItem(e.target.closest(".card").dataset.id, true); });
  $("#libBody").addEventListener("contextmenu", e => {
    const el = e.target.closest("[data-id]"); if (!el) return; e.preventDefault();
    if (S.sel.size && !S.sel.has(el.dataset.id)) S.sel.add(el.dataset.id), refreshSel();
    if (S.sel.size > 1) return showMenu(selMenuEntries(), e.clientX, e.clientY);
    itemMenu(el.dataset.id, null, { x: e.clientX, y: e.clientY });
  });
  $("#selBar").onclick = e => {
    const b = e.target.closest("[data-sel]"); if (!b) return;
    const a = b.dataset.sel;
    if (a === "podcast" || a === "book") bulk({ kind: a });
    else if (a === "more") { const r = b.getBoundingClientRect(); showMenu(selMenuEntries(), r.left, r.top - 330); }
    else if (a === "all") { domIds().forEach(i => S.sel.add(i)); refreshSel(); }
    else if (a === "clear") clearSel();
  };
  document.addEventListener("click", e => { if (!e.target.closest("#menu") && !e.target.closest("[data-act=menu]") && !e.target.closest("#plMore") && !e.target.closest("[data-sel=more]")) hideMenu(); });
  document.addEventListener("contextmenu", e => { if (!e.target.closest("input,textarea")) e.preventDefault(); });
  $("#modalWrap").addEventListener("mousedown", e => { if (e.target.id === "modalWrap") closeModal(null); });

  $("#playBtn").onclick = togglePlay; $("#mPlay").onclick = togglePlay;
  $("#backSkip").onclick = () => skip(-SKIP); $("#mBack").onclick = () => skip(-SKIP);
  $("#fwdSkip").onclick = () => skip(SKIP); $("#mFwd").onclick = () => skip(SKIP);
  $("#prevBtn").onclick = prevChapter; $("#nextBtn").onclick = nextChapter;
  $("#backBtn").onclick = () => { showView("library"); renderLibrary(); };
  $("#miniOpen").onclick = () => showView("player");
  $("#plFav").onclick = () => P.item && setFlags(P.item.id, { fav: !P.item.fav });
  $("#plMore").onclick = e => P.item && itemMenu(P.item.id, $("#plMore"));
  $("#bmAdd").onclick = addBookmark; $("#bmAddSide").onclick = addBookmark;
  $("#bookmarkList").onclick = bookmarkAction;
  $("#sleepBtn").onclick = sleepDialog;
  // AirPlay (Safari auf iPhone/iPad/Mac): Knopf nur zeigen, wenn ein AirPlay-Gerät (z. B. Sonos) im Netz ist
  if (window.WebKitPlaybackTargetAvailabilityEvent) {
    audio.setAttribute("x-webkit-airplay", "allow");
    audio.addEventListener("webkitplaybacktargetavailabilitychanged", e => { $("#airplayBtn").hidden = e.availability !== "available"; });
    $("#airplayBtn").onclick = () => audio.webkitShowPlaybackTargetPicker();
  }
  $$(".side-tabs button").forEach(b => b.onclick = () => sideTab(b.dataset.tab));
  $("#chapterList").onclick = e => { const li = e.target.closest("li"); if (!li) return; P.seek(P.chapters[+li.dataset.i].start, true); if (!P.playing) togglePlay(); };
  $("#speedSeg").onclick = e => { const b = e.target.closest("button"); if (b) setSpeed(+b.dataset.s); };
  $("#volSlider").oninput = e => setVolume(e.target.value / 100);
  $("#muteBtn").onclick = () => { if (audio.volume > 0) { S._vol = audio.volume; setVolume(0); } else setVolume(S._vol || 1); };

  // Schieberegler: Kapitel & Gesamt
  const chS = $("#chSlider"), toS = $("#totSlider");
  chS.addEventListener("input", () => {
    dragging = "ch"; chS.style.setProperty("--p", chS.value / 10 + "%");
    const ch = P.chapters[P.chapterIdx()]; $("#chElapsed").textContent = fmtClock((ch.end - ch.start) * chS.value / 1000);
  });
  chS.addEventListener("change", () => { const ch = P.chapters[P.chapterIdx()]; dragging = null; P.seek(ch.start + (ch.end - ch.start) * chS.value / 1000); });
  toS.addEventListener("input", () => { dragging = "tot"; toS.style.setProperty("--p", toS.value / 10 + "%"); $("#totElapsed").textContent = fmtClock(P.total * toS.value / 1000); });
  toS.addEventListener("change", () => { dragging = null; P.seek(P.total * toS.value / 1000); });

  document.addEventListener("keydown", onKey);
  window.addEventListener("pagehide", () => {
    if (P.item) fetch("/api/progress", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: JSON.stringify({ id: P.item.id, pos: P.pos(), duration: P.total, flush: true }) });
    fetch("/api/bye", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: "{}" });
  });
}

function onKey(e) {
  if (e.target.closest("input[type=text],input[type=search],textarea,select")) {
    if (e.key === "Escape") { e.target.blur(); if (e.target.id === "search" && S.q) { e.target.value = ""; S.q = ""; renderLibrary(); } }
    return;
  }
  if (!$("#modalWrap").hidden) { if (e.key === "Escape") closeModal(null); return; }
  const k = e.key;
  if ((e.ctrlKey && k.toLowerCase() === "f") || k === "/") { e.preventDefault(); $("#search").focus(); return; }
  if (e.ctrlKey && k.toLowerCase() === "a" && S.view === "library") { e.preventDefault(); domIds().forEach(i => S.sel.add(i)); refreshSel(); return; }
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const map = {
    " ": togglePlay, "k": togglePlay,
    "ArrowLeft": () => e.shiftKey ? prevChapter() : skip(-SKIP), "ArrowRight": () => e.shiftKey ? nextChapter() : skip(SKIP),
    "j": () => skip(-SKIP), "l": () => skip(SKIP),
    "PageUp": prevChapter, "PageDown": nextChapter,
    "ArrowUp": () => setVolume((S.settings.volume ?? 1) + 0.05), "ArrowDown": () => setVolume((S.settings.volume ?? 1) - 0.05),
    "b": addBookmark, "B": addBookmark, "f": () => P.item && setFlags(P.item.id, { fav: !P.item.fav }),
    "m": () => $("#muteBtn").click(),
    "+": () => { const i = SPEEDS.findIndex(s => s >= (S.settings.speed || 1) - 0.001); setSpeed(SPEEDS[Math.min(SPEEDS.length - 1, i + 1)]); },
    "-": () => { const i = SPEEDS.findIndex(s => s >= (S.settings.speed || 1) - 0.001); setSpeed(SPEEDS[Math.max(0, i - 1)]); },
    "Escape": () => { hideMenu(); if (S.sel.size) return clearSel(); if (S.view === "player") { showView("library"); renderLibrary(); } },
  };
  if (map[k]) {
    if (k === " " && e.target.closest("button")) e.target.blur();
    e.preventDefault(); map[k]();
  }
}

function syncChips() { $("#chipFav").classList.toggle("on", S.fav); $("#chipArch").classList.toggle("on", S.arch); $("#chipFav").innerHTML = icon(S.fav ? "heart-f" : "heart") + "Favoriten"; }
function syncViewBtn() { $("#viewBtn").innerHTML = icon(S.settings.view === "list" ? "grid" : "list"); $("#viewBtn").title = S.settings.view === "list" ? "Kachelansicht" : "Listenansicht"; }
function applyTheme() { document.documentElement.dataset.theme = S.settings.theme === "light" ? "light" : "dark"; $("#themeBtn").innerHTML = icon(S.settings.theme === "light" ? "moon" : "sun"); }

let pollTimer = null;
function pollStatus() {
  clearTimeout(pollTimer);
  pollTimer = setTimeout(async () => {
    try {
      const st = await api("/api/status");
      if (st.running) { setScan(st); await loadLibrary(); pollStatus(); }
      else { setScan(st); await loadLibrary(); }
    } catch (e) { pollStatus(); }
  }, 1200);
}

/* ---------------- player.menet.ch ---------------- */
S.cloud = null;
let cloudTimer = null;
function showCloud(c) {
  const before = S.cloud;
  S.cloud = c;
  if (!c) return;
  const busy = c.uploading || (c.queue && c.queue.length);
  $("#cloudInfo").hidden = !busy;
  if (busy) {
    const u = c.uploading;
    const pctTxt = u && u.total ? ` · ${Math.floor(u.done / u.total * 100)} %` : "";
    const more = c.queue.length > 1 ? ` (noch ${c.queue.length - 1})` : "";
    $("#cloudText").textContent = u ? `Lade hoch: ${u.title}${pctTxt}${more}` : `Hochladen …${more}`;
    clearTimeout(cloudTimer); cloudTimer = setTimeout(() => api("/api/cloud").then(showCloud).catch(() => { }), 1500);
  }
  if (before && before.changes !== c.changes) loadLibrary();
  if (before && (before.uploading || (before.queue || []).length) && !busy && !c.error) toast("Hochladen fertig – die Titel sind auf player.menet.ch.");
  if (c.error && (!before || before.error !== c.error)) toast("player.menet.ch: " + c.error, null, null, 7000);
}
async function cloudUpload(ids) {
  const d = await api("/api/cloud/upload", { ids });
  toast(d.added ? `${d.added} Titel ${d.added === 1 ? "wird" : "werden"} hochgeladen. Du kannst weiterhören.` : "Schon in der Warteschlange.");
  showCloud(d);
}
async function cloudDelete(id) {
  const it = S.byId[id];
  if (!confirm(`«${it.title}» von player.menet.ch entfernen? Die Datei auf dem PC bleibt. Auf dem Handy ist das Buch danach weg (für die ganze Familie).`)) return;
  const d = await api("/api/cloud/delete", { id });
  if (d.error) toast(d.error); else { toast("Vom Server entfernt."); await loadLibrary(); }
}
function cloudSection() {
  const c = S.cloud || {};
  if (!c.connected) return `<h3>player.menet.ch</h3>
    <p class="hint">Verbinde den Player mit player.menet.ch: Hörstand und Lesezeichen werden abgeglichen und du kannst Bücher fürs Handy hochladen.
      Auf player.menet.ch → <b>Geräte</b> → «Code erzeugen», dann den Code hier eingeben.</p>
    <div class="add-row"><input id="pairCode" type="text" placeholder="Code, z. B. ABCD-EFGH" autocomplete="off"><button class="btn primary" data-pair>${icon("cloud")}Verbinden</button></div>`;
  const when = c.last_sync ? new Date(c.last_sync * 1000).toLocaleTimeString("de-CH", { hour: "2-digit", minute: "2-digit" }) : "noch nie";
  return `<h3>player.menet.ch</h3>
    <p class="hint">Verbunden als <b>${esc(c.user || "?")}</b>${c.admin ? " (Admin – darf hochladen)" : ""} · zuletzt abgeglichen: ${when}${c.error ? ` · <span style="color:#ff8a7a">${esc(c.error)}</span>` : ""}</p>
    <div class="add-row"><button class="btn" data-csync>${icon("refresh")}Jetzt abgleichen</button>${c.uploading || (c.queue || []).length ? `<button class="btn" data-ccancel>${icon("x")}Hochladen stoppen</button>` : ""}<span style="flex:1"></span><button class="btn danger" data-unpair>Trennen</button></div>
    ${c.admin ? `<p class="hint" style="margin-top:8px">Hochladen: Rechtsklick auf einen Titel (oder mehrere auswählen) → «Auf player.menet.ch hochladen».</p>` : ""}`;
}

/* ---------------- Updates ---------------- */
S.update = null;
function mdLite(t) { // einfache Darstellung der Änderungsliste
  let html = "", inList = false;
  for (const raw of String(t || "").split(/\r?\n/)) {
    const line = raw.trim();
    const li = line.match(/^[-*]\s+(.*)/);
    if (li) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${esc(li[1]).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")}</li>`; continue; }
    if (inList) { html += "</ul>"; inList = false; }
    if (!line) continue;
    const h = line.match(/^#+\s+(.*)/);
    html += h ? `<h4>${esc(h[1])}</h4>` : `<p>${esc(line).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")}</p>`;
  }
  return html + (inList ? "</ul>" : "");
}
function showUpdate(u) {
  S.update = u;
  const av = !!(u && u.available);
  $("#updPill").hidden = !av;
  if (av) $("#updPillText").textContent = `Version ${u.latest}`;
  const b = $("#updBanner");
  if (!av || S.updDismissed === u.latest) { b.hidden = true; return; }
  b.hidden = false;
  b.innerHTML = `<span class="upd-ic">${icon("refresh")}</span><div class="upd-t"><b>Neue Version ${esc(u.latest)} verfügbar</b><span>Du hast ${esc(u.current)}. Das Update dauert nur einen Moment, deine Daten bleiben erhalten.</span></div>
    <button class="btn" data-u="notes">Was ist neu?</button><button class="btn primary" data-u="apply">Jetzt aktualisieren</button><button class="icon-btn sm" data-u="later" title="Später">${icon("x")}</button>`;
}
function updateDialog() {
  const u = S.update || {};
  openModal(`<h2>${u.available ? `Version ${esc(u.latest)} ist da` : "Updates"}</h2>
    <p class="hint">Installiert: ${esc(u.current || window.VERSION)}${u.latest ? ` · Neueste: ${esc(u.latest)}` : ""}</p>
    ${u.notes ? `<div class="notes">${mdLite(u.notes)}</div>` : ""}
    ${u.error ? `<p class="hint" style="color:#ff8a7a">${esc(u.error)}</p>` : ""}
    <div class="foot"><button class="btn" data-x>Schliessen</button>${u.available ? `<button class="btn primary" data-u="apply">Jetzt aktualisieren</button>` : ""}</div>`);
  $("#modal").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); if (e.target.closest("[data-u=apply]")) applyUpdate(); };
}
async function checkUpdate(force) {
  try { const u = await api("/api/update/check", { force: !!force }); showUpdate(u); return u; } catch (e) { return null; }
}
async function applyUpdate() {
  openModal(`<h2>Update wird installiert</h2><p class="hint" style="display:flex;gap:10px;align-items:center"><span class="spinner"></span>Neue Version wird heruntergeladen …</p>
    <p class="hint">Der Player schliesst sich gleich und startet von selbst neu – an derselben Stelle.</p>`);
  const playing = P.playing;
  const music = musicResumeInfo();
  if (music) M.mk.pause();
  if (P.item) { audio.pause(); await saveProgress(true); }
  try {
    const r = await api("/api/update/apply", { playing, music });
    if (!r.ok) { openModal(`<h2>Update nicht möglich</h2><p class="hint">${esc(r.error || "Unbekannter Fehler")}</p><div class="foot"><button class="btn" data-x>Schliessen</button></div>`); $("#modal").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); }; return; }
    $("#modal").innerHTML = `<h2>Fast fertig …</h2><p class="hint" style="display:flex;gap:10px;align-items:center"><span class="spinner"></span>Der Player startet in wenigen Sekunden neu.</p>`;
    S.updating = true;
    if (S.server) waitForRestart(); else setTimeout(() => window.close(), 1800);
  } catch (e) { toast("Update fehlgeschlagen: " + e.message, null, null, 8000); closeModal(); }
}

let pendingBusy = false;
async function checkPending() {
  if (pendingBusy) return;
  pendingBusy = true;
  try {
    const d = await api("/api/pending", {});
    if (d.id) {
      if (!S.byId[d.id]) await loadLibrary();
      if (S.sel.size) clearSel();
      await openItem(d.id, true);
    } else if (d.error) toast(d.error, null, null, 7000);
  } catch (e) { }
  pendingBusy = false;
}

async function heartbeat() {
  try {
    const d = await api("/api/heartbeat", {});
    if (d.cloud) showCloud(d.cloud);
    if (d.status && d.status.running && !S.scanning) { setScan(d.status); pollStatus(); }
  } catch (e) { }
}

/* ---------------- Start ---------------- */
async function init() {
  bind();
  const d = await api("/api/init");
  if (d.server) {
    // Heimserver: zuerst wählen, wer hört
    S.server = true; S.profiles = d.profiles || { list: [], current: null };
    document.body.classList.add("server-mode");
    $("#pipBtn").hidden = !pipSupported();
    if (!S.profiles.current) { S.settings = d.settings; applyTheme(); showProfilePicker(true); return; }
    renderProfileBtn();
    $$("[data-spk]").forEach(b => { b.hidden = false; });                   // Sonos gibt es nur auf dem Heimserver
    api("/api/sonos/stand", {}).then(sonosShow).catch(() => { });          // läuft schon etwas (z. B. von einem anderen Gerät gestartet)?
  }
  if (d.update) showUpdate(d.update);
  api("/api/cloud").then(showCloud).catch(() => { });
  setTimeout(() => api("/api/update").then(showUpdate).catch(() => { }), 9000);
  S.settings = d.settings; S.dataDir = d.data_dir;
  applyTheme(); syncViewBtn(); syncChips(); renderSpeed(); applyMusicSetting();
  $("#sortSel").value = S.settings.sort || "recent";
  setVolume(S.settings.volume ?? 1);
  await loadLibrary();
  if (d.status.running) pollStatus();
  heartbeat(); setInterval(heartbeat, 15000);
  await checkPending(); setInterval(checkPending, 1500);
  // zuletzt gehörten Titel bereitlegen (ohne abzuspielen)
  const last = S.settings.last_item;
  const tryLast = async () => {
    if (P.item || !last || P.loadingId) return;
    if (S.byId[last]) {
      await openItem(last, !!d.resume_play);
      if (!d.resume_play) { showView("library"); renderLibrary(); }
      else toast(`Aktualisiert auf Version ${window.VERSION}. Es geht weiter, wo du warst.`);
    }
    else if (S.scanning) setTimeout(tryLast, 1500);
  };
  tryLast();
  if (d.resume_music && musicEnabled()) musicResume(d.resume_music);
}
init().catch(e => { console.error(e); document.body.insertAdjacentHTML("beforeend", `<div class="toast" style="position:fixed;left:20px;bottom:20px">Fehler beim Start: ${esc(e.message)}</div>`); });
