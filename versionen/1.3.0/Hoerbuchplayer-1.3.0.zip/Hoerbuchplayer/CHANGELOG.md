# Änderungen

## 1.3.0
- **Automatische Updates:** Der Player schaut beim Start auf GitHub nach einer neuen Version und kann sich mit einem Klick selbst aktualisieren. Danach geht es an derselben Stelle weiter.
- In den Einstellungen: **Nach Updates suchen**.

## 1.2.0
- **Mehrfachauswahl:** mehrere Titel auf einmal als Podcast/Hörbuch markieren, zu Favoriten, ins Archiv.
- **Installation** mit Eintrag im Startmenü (`installieren.bat`) und eigener `Hoerbuchplayer.exe`.
- **Standard-Player für .m4b:** Doppelklick auf eine .m4b-Datei öffnet sie im Player.

## 1.1.0
- Podcasts nach Sendung gruppiert und **auf-/zuklappbar**, Knopf «Weiterhören».
- Folgen nach Folgennummer sortiert.

## 1.0.0
- Erste Version: Bibliothek, Player mit Kapiteln, Lesezeichen, Favoriten, Archiv, Schlaf-Timer.
