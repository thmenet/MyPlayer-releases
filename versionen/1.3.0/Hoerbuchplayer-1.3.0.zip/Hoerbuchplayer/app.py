"""Hörbuch-Player – Startpunkt.

Startet einen kleinen Server nur auf diesem Computer (127.0.0.1) und öffnet die Oberfläche
als eigenes App-Fenster in Microsoft Edge. Schliesst man das Fenster, beendet sich das Programm.
"""
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from hoerbuch import VERSION, APP_NAME  # noqa: E402
from hoerbuch import storage  # noqa: E402

PREFERRED_PORT = 48219
DEBUG = "--debug" in sys.argv or "--konsole" in sys.argv
NO_BROWSER = "--no-browser" in sys.argv
OPEN_FILE = next((a for a in sys.argv[1:] if not a.startswith("--") and os.path.isfile(a)), None)


def setup_logging(data):
    log_path = os.path.join(data, "protokoll.txt")
    try:
        if os.path.exists(log_path) and os.path.getsize(log_path) > 2_000_000:
            os.replace(log_path, log_path + ".alt")
    except OSError:
        pass
    handlers = [logging.FileHandler(log_path, encoding="utf-8")]
    if sys.stderr is not None and DEBUG:
        handlers.append(logging.StreamHandler(sys.stderr))
    logging.basicConfig(level=logging.INFO, handlers=handlers,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    # pythonw hat keine Konsole: Ausgaben ins Protokoll umleiten, damit nichts abstürzt
    if sys.stdout is None or sys.stderr is None:
        f = open(log_path, "a", encoding="utf-8", buffering=1)
        if sys.stdout is None:
            sys.stdout = f
        if sys.stderr is None:
            sys.stderr = f
    return log_path


def find_edge():
    cands = []
    for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
    if sys.platform == "win32":
        try:
            import winreg
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                try:
                    k = winreg.OpenKey(hive, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe")
                    cands.append(winreg.QueryValue(k, None))
                except OSError:
                    pass
        except ImportError:
            pass
    for c in cands:
        if c and os.path.isfile(c):
            return c
    for name in ("msedge", "microsoft-edge", "chromium", "google-chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None


def open_window(url, data):
    edge = find_edge()
    if edge:
        profile = os.path.join(data, "edge-profil")
        args = [edge, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                "--no-default-browser-check", "--window-size=1320,880",
                "--autoplay-policy=no-user-gesture-required", "--disable-background-mode",
                "--disable-features=Translate,msEdgeStartupBoost"]
        logging.info("Öffne Fenster mit %s", edge)
        return subprocess.Popen(args)
    logging.warning("Edge nicht gefunden – öffne Standardbrowser")
    webbrowser.open(url)
    return None


def already_running(data):
    """Läuft das Programm schon? Dann (Adresse, Info) zurückgeben."""
    p = os.path.join(data, "laeuft.json")
    try:
        with open(p, "r", encoding="utf-8") as f:
            info = json.load(f)
        url = f"http://127.0.0.1:{info['port']}/api/init"
        with urllib.request.urlopen(url, timeout=1.5) as r:
            if r.status == 200:
                return f"http://127.0.0.1:{info['port']}/?t={info['token']}", info
    except Exception:
        return None, None
    return None, None


def send_open(info, path):
    """Einer laufenden Instanz sagen, dass sie eine Datei abspielen soll."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{info['port']}/api/open",
                                     data=json.dumps({"path": os.path.abspath(path)}).encode("utf-8"),
                                     headers={"Content-Type": "application/json", "X-Token": info["token"]})
        with urllib.request.urlopen(req, timeout=3) as r:
            return r.status == 200
    except Exception as e:
        logging.warning("Datei konnte nicht übergeben werden: %s", e)
        return False


def bring_window_to_front():
    """Das Player-Fenster (Edge-App-Fenster mit unserem Titel) nach vorne holen."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        found = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _):
            if user32.IsWindowVisible(hwnd):
                n = user32.GetWindowTextLengthW(hwnd)
                if n:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    if buf.value.startswith(APP_NAME):
                        found.append(hwnd)
                        return False
            return True
        user32.EnumWindows(proto(cb), 0)
        if not found:
            return False
        h = found[0]
        if user32.IsIconic(h):
            user32.ShowWindow(h, 9)  # wiederherstellen
        user32.SetForegroundWindow(h)
        return True
    except Exception as e:
        logging.warning("Fenster nach vorne holen fehlgeschlagen: %s", e)
        return False


def main():
    data = storage.data_dir()
    log_path = setup_logging(data)
    logging.info("=== %s %s startet (Python %s) ===", APP_NAME, VERSION, sys.version.split()[0])

    url, info = already_running(data)
    if url and not NO_BROWSER:
        if OPEN_FILE:
            logging.info("Läuft bereits – übergebe Datei %s", OPEN_FILE)
            send_open(info, OPEN_FILE)
        if not bring_window_to_front():
            logging.info("Läuft bereits – öffne nur das Fenster")
            open_window(url, data)
        return

    from hoerbuch.library import Library
    from hoerbuch.server import App, start_server

    store = storage.Store()
    lib = Library(store)
    app = App(store, lib)
    httpd, port = start_server(app, PREFERRED_PORT)
    url = f"http://127.0.0.1:{port}/?t={app.token}"
    if OPEN_FILE:
        app.pending_open = os.path.abspath(OPEN_FILE)
        logging.info("Öffne Datei %s", OPEN_FILE)
    running_file = os.path.join(data, "laeuft.json")
    storage.save_json(running_file, {"port": port, "token": app.token, "pid": os.getpid()})
    logging.info("Server läuft auf %s", url.split("?")[0])
    if DEBUG:
        print(f"{APP_NAME} {VERSION}")
        print(f"Daten & Protokoll: {data}")
        print(f"Adresse: {url}")
        print("Dieses Fenster offen lassen. Beenden: Programmfenster schliessen oder Strg+C.")

    lib.start_scan()
    app.updater.check_async()   # still im Hintergrund nach einer neuen Version schauen

    started = time.time()
    proc = None if NO_BROWSER else open_window(url, data)
    proc_tracked = proc is not None
    last_flush = time.time()
    try:
        while True:
            time.sleep(1)
            now = time.time()
            if now - last_flush > 10:
                store.flush()
                last_flush = now
            # Fenster geschlossen?
            if proc_tracked and proc.poll() is not None:
                if now - started < 10:
                    proc_tracked = False   # Edge hat an einen anderen Prozess übergeben -> Herzschlag nutzen
                else:
                    logging.info("Fenster geschlossen")
                    break
            if app.quit_event.is_set():
                logging.info("Beende für Update")
                time.sleep(0.5)
                break
            if NO_BROWSER:
                continue
            if app.bye_at and now - app.bye_at > 8 and app.last_beat < app.bye_at:
                logging.info("Oberfläche hat sich abgemeldet")
                break
            if app.had_beat and now - app.last_beat > 240:
                logging.info("Kein Lebenszeichen der Oberfläche mehr")
                break
            if not app.had_beat and now - started > 300:
                logging.info("Oberfläche hat sich nie gemeldet")
                break
    except KeyboardInterrupt:
        pass
    finally:
        store.flush(force=True)
        store.save_settings()
        try:
            os.remove(running_file)
        except OSError:
            pass
        httpd.shutdown()
        logging.info("Beendet")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        logging.exception("Unerwarteter Fehler")
        if DEBUG:
            raise
