VERSION = "1.19.2"
APP_NAME = "MyPlayer"
