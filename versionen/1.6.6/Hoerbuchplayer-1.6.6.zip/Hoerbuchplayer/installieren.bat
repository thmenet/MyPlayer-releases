@echo off
setlocal
title MyPlayer installieren
set "QUELLE=%~dp0"
if "%QUELLE:~-1%"=="\" set "QUELLE=%QUELLE:~0,-1%"
set "ZIEL=%LOCALAPPDATA%\Programs\Hoerbuchplayer"

echo ============================================================
echo  MyPlayer installieren / aktualisieren
echo  Ziel: %ZIEL%
echo  (Deine Daten wie Fortschritt und Lesezeichen bleiben erhalten.)
echo  Bitte den Player vorher schliessen, falls er laeuft.
echo ============================================================
echo.

if not exist "%QUELLE%\app.py" (
  echo FEHLER: Bitte die ZIP-Datei zuerst entpacken
  echo ^(Rechtsklick - "Alle extrahieren"^) und dann installieren.bat
  echo im entpackten Ordner starten.
  pause
  exit /b 1
)

rem --- Programmdateien kopieren (die .venv wird am Ziel neu angelegt)
if /i "%QUELLE%"=="%ZIEL%" goto einrichten
if not exist "%ZIEL%" mkdir "%ZIEL%"
echo Kopiere Programmdateien ...
robocopy "%QUELLE%" "%ZIEL%" /E /XD .venv __pycache__ /XF *.zip /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo FEHLER beim Kopieren. Laeuft der Player noch? Bitte schliessen und erneut versuchen.
  pause
  exit /b 1
)

:einrichten
cd /d "%ZIEL%"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo FEHLER: Python wurde nicht gefunden.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Programmumgebung wird eingerichtet ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo FEHLER: Programmumgebung konnte nicht angelegt werden.
    pause
    exit /b 1
  )
)
fc /b requirements.txt ".venv\requirements.installed" >nul 2>nul
if errorlevel 1 (
  echo Benoetigte Pakete werden installiert. Das dauert 1-2 Minuten ...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo FEHLER bei der Installation der Pakete ^(siehe oben^).
    pause
    exit /b 1
  )
  copy /y requirements.txt ".venv\requirements.installed" >nul
)

rem --- Verknuepfungen im Startmenue (und optional auf dem Desktop)
echo.
choice /c JN /n /m "Auch eine Verknuepfung auf dem Desktop anlegen? [J/N] "
if errorlevel 2 (set "DESK=0") else (set "DESK=1")
powershell -NoProfile -ExecutionPolicy Bypass -File "%ZIEL%\tools\verknuepfungen.ps1" -Ziel "%ZIEL%" -Desktop %DESK%
if errorlevel 1 (
  echo Die Verknuepfung konnte nicht angelegt werden ^(siehe oben^).
)

echo.
echo ============================================================
echo  Fertig! Du findest den Player jetzt im Startmenue unter
echo  "MyPlayer". Tipp: Rechtsklick darauf - "An Start anheften".
echo  Den entpackten Download-Ordner kannst du jetzt loeschen.
echo ============================================================
echo.
choice /c JN /n /m "Player jetzt starten? [J/N] "
if errorlevel 2 goto standard
start "" "%ZIEL%\MyPlayer.exe"
:standard
echo.
echo Als Standard-Player fuer .m4b-Dateien festlegen:
echo   Rechtsklick auf eine .m4b-Datei - "Oeffnen mit" - "Andere App auswaehlen"
echo   - "MyPlayer" waehlen - "Immer" anklicken.
echo.
pause
exit /b 0
exit /b 0
