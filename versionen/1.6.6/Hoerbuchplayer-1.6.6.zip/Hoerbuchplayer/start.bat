@echo off
setlocal
cd /d "%~dp0"
title MyPlayer

rem --- Python suchen (bevorzugt den Python-Launcher "py")
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo Python wurde nicht gefunden. Bitte Python von python.org installieren.
  pause
  exit /b 1
)

rem --- Beim ersten Start: eigene Programmumgebung (.venv) anlegen
if not exist ".venv\Scripts\python.exe" (
  echo Erster Start: Programmumgebung wird eingerichtet ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Die Programmumgebung konnte nicht angelegt werden.
    pause
    exit /b 1
  )
)

rem --- Pakete nur (neu) installieren, wenn sich requirements.txt geaendert hat
fc /b requirements.txt ".venv\requirements.installed" >nul 2>nul
if errorlevel 1 (
  echo Benoetigte Pakete werden installiert. Das dauert beim ersten Mal 1-2 Minuten ...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo.
    echo Die Installation ist fehlgeschlagen. Bitte fehlersuche.bat starten
    echo und einen Screenshot der Meldung schicken.
    pause
    exit /b 1
  )
  copy /y requirements.txt ".venv\requirements.installed" >nul
)

rem --- Programm ohne Konsolenfenster starten
start "" ".venv\Scripts\pythonw.exe" "%~dp0app.py"
exit /b 0
