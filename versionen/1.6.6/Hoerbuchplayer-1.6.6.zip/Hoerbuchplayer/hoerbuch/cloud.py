"""Verbindung zu player.menet.ch: Gerät verbinden, Hörbücher hochladen, Hörstand und Lesezeichen abgleichen.

- Anmeldung mit Geräte-Schlüssel (einmal mit Code von player.menet.ch → Geräte verbunden), kein Passwort im PC-Player.
- Jedes Buch hat einen Fingerabdruck (uid) aus Grösse, Anfang und Ende seiner Dateien. So erkennen PC und Server
  dasselbe Buch, auch wenn es auf dem PC in einem anderen Ordner liegt.
- Abgleich: bei Hörstand und Lesezeichen gewinnt die neueste Änderung (changed_ms).
"""
import hashlib
import http.client
import json
import logging
import os
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from . import VERSION

log = logging.getLogger("cloud")

DEFAULT_URL = "https://player.menet.ch"
FP_BYTES = 256 * 1024          # so viel vom Anfang und vom Ende einer Datei fliesst in den Fingerabdruck
SYNC_EVERY = 120               # Sekunden zwischen zwei automatischen Abgleichen


class CloudError(Exception):
    pass


def _ssl_context():
    """Zertifikate prüfen mit dem Windows-Speicher UND der Liste von certifi.
    Grund: Windows lädt manche Stammzertifikate (z. B. das von Let's Encrypt) erst nach, wenn ein Browser sie braucht –
    Python sieht sie dann nicht und meldet «Zertifikat ungültig», obwohl die Seite im Browser geht."""
    ctx = ssl.create_default_context()
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception as e:  # certifi fehlt: nur der Windows-Speicher
        log.info("certifi nicht verfügbar: %s", e)
    return ctx


SSL_CONTEXT = _ssl_context()

# --- Vorübergehende Ausnahme, bis green.ch das richtige Zertifikat für player.menet.ch einspielt (Stand 19.11.2026):
# green.ch liefert dort noch sein eigenes Zertifikat «*.servicehoster.ch» aus. Nur für diese eine Adresse und nur für genau
# diesen Namen akzeptieren wir es – die Echtheit des Zertifikats (offizielle Stelle, gültig) wird weiterhin voll geprüft.
# Sobald das richtige Zertifikat da ist, klappt die normale Prüfung und diese Ausnahme wird nicht mehr benutzt.
INTERIM_HOSTS = {"player.menet.ch"}
INTERIM_NAMES = {"*.servicehoster.ch", "servicehoster.ch"}
INTERIM_UNTIL = time.mktime((2027, 2, 20, 0, 0, 0, 0, 0, -1))   # Ablauf des green.ch-Zertifikats


def _interim_context():
    ctx = _ssl_context()
    ctx.check_hostname = False          # Name prüfen wir selbst (nur INTERIM_NAMES) …
    ctx.verify_mode = ssl.CERT_REQUIRED  # … die Echtheit des Zertifikats bleibt Pflicht
    return ctx


def _cert_names(cert):
    names = {v for k, v in cert.get("subjectAltName", ()) if k == "DNS"}
    for rdn in cert.get("subject", ()):
        for k, v in rdn:
            if k == "commonName":
                names.add(v)
    return names


def interim_request(url, method, data, headers, timeout):
    """Anfrage mit der vorübergehenden Ausnahme. Gibt (Status, Inhalt) zurück."""
    u = urllib.parse.urlsplit(url)
    conn = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=timeout, context=_interim_context())
    try:
        conn.connect()
        names = _cert_names(conn.sock.getpeercert() or {})
        if not (names & INTERIM_NAMES):
            raise CloudError(f"Unerwartetes Zertifikat für {u.hostname} ({', '.join(sorted(names)) or 'ohne Namen'})")
        path = u.path + (("?" + u.query) if u.query else "")
        conn.request(method, path, body=data, headers=headers)
        r = conn.getresponse()
        return r.status, r.read()
    finally:
        conn.close()


def now_ms():
    return int(time.time() * 1000)


def file_fingerprint(path, size=None):
    size = os.path.getsize(path) if size is None else size
    h = hashlib.sha1(str(size).encode())
    with open(path, "rb") as f:
        h.update(f.read(FP_BYTES))
        if size > FP_BYTES:
            f.seek(max(FP_BYTES, size - FP_BYTES))
            h.update(f.read(FP_BYTES))
    return h.hexdigest()


class Cloud:
    def __init__(self, store, library):
        self.store = store
        self.lib = library
        self.lock = threading.RLock()
        self.server_uids = set()          # Bücher, die auf dem Server liegen
        self.uid_by_item = {}             # lokale Titel-ID -> Fingerabdruck (nach dem ersten Abgleich bekannt)
        self.status = {"connected": bool(self.token), "user": self.store.settings.get("cloud_user"),
                       "admin": bool(self.store.settings.get("cloud_admin")), "last_sync": 0, "error": None,
                       "syncing": False, "queue": [], "uploading": None, "changes": 0,
                       "interim_cert": False}
        self._queue = []
        self._worker = None
        self._cancel = threading.Event()
        self._fp_new = False

    # ------------------------------------------------------------------ Grundlagen
    @property
    def url(self):
        return (self.store.settings.get("cloud_url") or DEFAULT_URL).rstrip("/")

    @property
    def token(self):
        return self.store.settings.get("cloud_token") or ""

    def _request(self, method, path, body=None, raw=None, timeout=30):
        headers = {"Accept": "application/json", "User-Agent": f"Hoerbuchplayer/{VERSION}"}
        data = None
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        if raw is not None:
            data = raw
            headers["Content-Type"] = "application/octet-stream"
        elif body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=SSL_CONTEXT) as r:
                if self.status.get("interim_cert"):
                    log.info("Richtiges Zertifikat für %s ist da – Ausnahme nicht mehr nötig", self.url)
                    self.status["interim_cert"] = False
                return json.loads(r.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as e:
            return self._status(e.code, e.read())
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError) as e:
            reason = getattr(e, "reason", e)
            host = urllib.parse.urlsplit(self.url).hostname
            if (isinstance(reason, ssl.SSLCertVerificationError) and "mismatch" in str(reason).lower()
                    and host in INTERIM_HOSTS and time.time() < INTERIM_UNTIL):
                try:
                    code, body = interim_request(self.url + path, method, data, headers, timeout)
                except (OSError, ssl.SSLError, http.client.HTTPException) as e2:
                    raise CloudError(f"Keine Verbindung zu player.menet.ch ({e2})") from e2
                if not self.status.get("interim_cert"):
                    log.info("Vorübergehende Zertifikat-Ausnahme für %s aktiv (green.ch-Zertifikat)", host)
                self.status["interim_cert"] = True
                if code >= 400:
                    return self._status(code, body)
                return json.loads(body.decode("utf-8") or "{}")
            log.warning("Keine Verbindung zu %s: %r", self.url, reason)
            if isinstance(reason, ssl.SSLCertVerificationError) or "CERTIFICATE" in str(reason).upper():
                raise CloudError(f"Das Sicherheitszertifikat von player.menet.ch konnte nicht geprüft werden ({getattr(reason, 'verify_message', reason)})") from e
            if isinstance(reason, (socket.timeout, TimeoutError)) or "timed out" in str(reason):
                raise CloudError("player.menet.ch antwortet nicht (Zeitüberschreitung)") from e
            if isinstance(reason, socket.gaierror):
                raise CloudError("player.menet.ch wurde nicht gefunden – Internet-Verbindung prüfen") from e
            raise CloudError(f"Keine Verbindung zu player.menet.ch ({reason})") from e

    def _status(self, code, raw):
        """Fehlerantwort des Servers in eine verständliche Meldung übersetzen"""
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            payload = {}
        if code == 401:
            self.status["connected"] = False
        if code == 409 and "received" in payload:
            return payload | {"_conflict": True}
        msg = payload.get("error") or payload.get("message")
        if not msg:
            msg = {404: "player.menet.ch antwortet noch nicht richtig (Seite nicht gefunden) – ist der Server schon bereitgestellt?",
                   500: "Fehler auf player.menet.ch (500)", 502: "player.menet.ch ist gerade nicht erreichbar (502)",
                   503: "player.menet.ch wird gerade aktualisiert – bitte gleich nochmals versuchen"}.get(code, f"Fehler {code}")
        raise CloudError(msg)

    def music_token(self):
        """Apple-Music-Token von player.menet.ch (gilt 12 Std., hier zwischengespeichert)"""
        c = getattr(self, "_music", None)
        if c and c.get("expires", 0) - 600 > time.time():
            return c
        self._music = self._request("GET", "/api/musik/token")
        return self._music

    # ------------------------------------------------------------------ Verbinden
    def pair(self, code, name=None):
        name = name or f"PC {socket.gethostname()}"[:80]
        self.store.settings["cloud_token"] = ""
        d = self._request("POST", "/api/geraete/verbinden", {"code": code.strip(), "name": name})
        self.store.settings.update(cloud_token=d["token"], cloud_user=d["user"]["name"], cloud_admin=bool(d["user"]["admin"]))
        self.store.save_settings()
        self.status.update(connected=True, user=d["user"]["name"], admin=bool(d["user"]["admin"]), error=None)
        log.info("Mit %s verbunden als %s", self.url, d["user"]["name"])
        self.sync_async()
        return self.public()

    def unpair(self):
        try:
            if self.token:
                self._request("POST", "/api/abmelden", {})
        except CloudError:
            pass
        for k in ("cloud_token", "cloud_user", "cloud_admin"):
            self.store.settings.pop(k, None)
        self.store.save_settings()
        self.server_uids = set()
        self.status.update(connected=False, user=None, admin=False, error=None)
        return self.public()

    def is_on_server(self, iid):
        u = self.uid_by_item.get(iid)
        return bool(u and u in self.server_uids)

    def public(self):
        s = dict(self.status)
        s["url"] = self.url
        s["queue"] = [q["title"] for q in self._queue]
        return s

    # ------------------------------------------------------------------ Fingerabdruck
    def uid_for(self, item):
        """Fingerabdruck eines Titels (im Datei-Cache der Bibliothek gemerkt)."""
        fps = []
        for t in item["tracks"]:
            info = self.lib.file_info(t["path"])
            if info is None:
                return None
            fp = info.get("fp")
            if not fp:
                fp = file_fingerprint(t["path"], info["size"])
                info["fp"] = fp
                self._fp_new = True
            fps.append(fp)
        if not fps:
            return None
        return (fps[0] if len(fps) == 1 else hashlib.sha1("".join(fps).encode()).hexdigest())[:32]

    def uid_map(self):
        """uid -> lokale Titel-ID für die ganze Bibliothek"""
        out = {}
        self._fp_new = False
        for it in self.lib.all():
            try:
                u = self.uid_for(it)
            except OSError:
                u = None
            if u:
                out[u] = it["id"]
                self.uid_by_item[it["id"]] = u
        if self._fp_new:   # neue Fingerabdrücke im Datei-Cache sichern (nur einmal rechnen)
            from . import storage
            storage.save_json(self.lib.cache_path, self.lib.cache)
        return out

    # ------------------------------------------------------------------ Abgleich
    def sync(self):
        if not self.token:
            return self.public()
        with self.lock:
            self.status["syncing"] = True
            try:
                umap = self.uid_map()
                inv = {v: k for k, v in umap.items()}
                items, bms = [], []
                with self.store.lock:
                    for iid, st in self.store.state["items"].items():
                        uid = inv.get(iid)
                        if not uid:
                            continue
                        if st.get("changed_ms"):
                            entry = {"uid": uid, "changed_ms": int(st["changed_ms"]), "pos": float(st.get("pos", 0)),
                                     "finished": bool(st.get("finished")), "fav": bool(st.get("fav")), "archived": bool(st.get("archived"))}
                            if self.status.get("admin") and st.get("kind") in ("book", "podcast"):
                                entry["kind"] = st["kind"]
                            items.append(entry)
                        for b in st.get("bookmarks") or []:
                            bms.append({"book_uid": uid, "uid": b["id"], "pos": float(b["pos"]), "note": b.get("note", ""),
                                        "deleted": bool(b.get("deleted")), "changed_ms": int(b.get("changed_ms") or b.get("created", 0) * 1000)})
                d = self._request("POST", "/api/abgleich", {"items": items, "bookmarks": bms}, timeout=60)
                self.server_uids = {b["uid"] for b in d.get("books", [])}
                changed = self._merge(d, umap)
                self.store.flush()
                self.status.update(connected=True, last_sync=time.time(), error=None, user=d.get("user", {}).get("name", self.status["user"]),
                                   admin=bool(d.get("user", {}).get("admin", self.status["admin"])))
                if changed:
                    self.status["changes"] += 1
                    log.info("Abgleich: %d Änderungen vom Server übernommen", changed)
            except CloudError as e:
                self.status["error"] = str(e)
                log.warning("Abgleich fehlgeschlagen: %s", e)
            finally:
                self.status["syncing"] = False
        return self.public()

    def _merge(self, d, umap):
        changed = 0
        with self.store.lock:
            for s in d.get("items", []):
                iid = umap.get(s["uid"])
                if not iid:
                    continue
                st = self.store.item(iid, create=True)
                if int(s.get("changed_ms", 0)) > int(st.get("changed_ms", 0)):
                    st.update(pos=round(float(s["pos"]), 2), changed_ms=int(s["changed_ms"]), updated=int(s["changed_ms"]) / 1000)
                    for k in ("finished", "fav", "archived"):
                        if s.get(k):
                            st[k] = True
                        else:
                            st.pop(k, None)
                    changed += 1
            for b in d.get("bookmarks", []):
                iid = umap.get(b["book_uid"])
                if not iid:
                    continue
                st = self.store.item(iid, create=True)
                bms = st.setdefault("bookmarks", [])
                mine = next((x for x in bms if x["id"] == b["uid"]), None)
                if mine and int(mine.get("changed_ms", 0)) >= int(b["changed_ms"]):
                    continue
                if not mine:
                    mine = {"id": b["uid"], "created": int(b["changed_ms"]) / 1000}
                    bms.append(mine)
                mine.update(pos=float(b["pos"]), note=b.get("note") or "", changed_ms=int(b["changed_ms"]))
                if b.get("deleted"):
                    mine["deleted"] = True
                else:
                    mine.pop("deleted", None)
                bms.sort(key=lambda x: x["pos"])
                changed += 1
            if changed:
                self.store.mark_dirty()
        return changed

    def sync_async(self):
        threading.Thread(target=self.sync, daemon=True).start()

    # ------------------------------------------------------------------ Hochladen
    def enqueue(self, item_ids):
        added = 0
        for iid in item_ids:
            it = self.lib.get(iid)
            if it and not any(q["id"] == iid for q in self._queue):
                self._queue.append({"id": iid, "title": it["title"]})
                added += 1
        if not self._worker or not self._worker.is_alive():
            self._cancel.clear()
            self._worker = threading.Thread(target=self._run_queue, daemon=True)
            self._worker.start()
        return added

    def cancel_uploads(self):
        self._queue.clear()
        self._cancel.set()

    def _run_queue(self):
        while self._queue and not self._cancel.is_set():
            job = self._queue[0]
            try:
                self.upload(job["id"])
            except CloudError as e:
                self.status["error"] = f"«{job['title']}»: {e}"
                log.warning("Hochladen fehlgeschlagen (%s): %s", job["title"], e)
                time.sleep(3)
                # bei Verbindungsfehler: nicht endlos wiederholen – Auftrag bleibt, Benutzer kann neu starten
                if "Verbindung" in str(e):
                    break
            except Exception:
                log.exception("Hochladen fehlgeschlagen")
            if self._queue and self._queue[0] is job:
                self._queue.pop(0)
        self.status["uploading"] = None
        self.sync_async()

    def upload(self, iid):
        it = self.lib.get(iid)
        if not it:
            return
        st = self.store.item(iid) or {}
        uid = self.uid_for(it)
        kind = st.get("kind") or it["auto_kind"]
        meta = {
            "uid": uid, "kind": kind, "title": it["title"][:300], "author": (it.get("author") or "")[:300],
            "narrator": (it.get("narrator") or "")[:300], "show": (it.get("show") or "")[:300] if kind == "podcast" else "",
            "genre": (it.get("genre") or "")[:100], "date": str(it.get("date") or "")[:40],
            "description": (it.get("description") or "")[:20000], "duration": float(it["duration"] or 0),
            "chapters": [{"title": (c.get("title") or "")[:300], "start": float(c["start"])} for c in it["chapters"]][:2000],
            "tracks": [{"name": os.path.basename(t["path"])[:300], "ext": os.path.splitext(t["path"])[1].lower().lstrip("."),
                        "size": os.path.getsize(t["path"]), "duration": float(t["duration"] or 0)} for t in it["tracks"]],
        }
        total = sum(t["size"] for t in meta["tracks"]) or 1
        self.status["uploading"] = {"id": iid, "title": it["title"], "done": 0, "total": total}
        d = self._request("POST", "/api/hochladen", meta, timeout=60)
        chunk = int(d.get("chunk_size") or 8 * 1024 * 1024)
        received = {t["idx"]: int(t["received"]) for t in d["tracks"]}
        if not d.get("has_cover") and it.get("cover"):
            self._upload_cover(uid, it["cover"])
        for i, t in enumerate(it["tracks"]):
            size = meta["tracks"][i]["size"]
            off = received.get(i, 0)
            with open(t["path"], "rb") as f:
                while off < size:
                    if self._cancel.is_set():
                        raise CloudError("abgebrochen")
                    f.seek(off)
                    data = f.read(chunk)
                    r = self._request("POST", f"/api/hochladen/{uid}/{i}?offset={off}", raw=data, timeout=120)
                    off = int(r["received"])
                    received[i] = off
                    self.status["uploading"]["done"] = sum(received.values())
        self.server_uids.add(uid)
        self.uid_by_item[iid] = uid
        self.status["changes"] += 1
        log.info("Hochgeladen: %s", it["title"])

    def _upload_cover(self, uid, cover_id):
        base = os.path.join(self.lib.covers_dir, cover_id)
        for p in [base + ".orig.jpg", base + ".orig.png", base + ".orig.jpeg", base + ".jpg"]:
            if os.path.exists(p) and os.path.getsize(p) < 5 * 1024 * 1024:
                with open(p, "rb") as f:
                    data = f.read()
                if data[:2] == b"\xff\xd8" or data[:4] == b"\x89PNG":
                    try:
                        self._request("POST", f"/api/hochladen/{uid}/cover", raw=data)
                    except CloudError as e:
                        log.warning("Cover nicht hochgeladen: %s", e)
                    return

    def delete_remote(self, iid):
        it = self.lib.get(iid)
        uid = self.uid_for(it) if it else None
        if not uid:
            return False
        self._request("DELETE", f"/api/buecher/{uid}")
        self.server_uids.discard(uid)
        self.status["changes"] += 1
        return True

    # ------------------------------------------------------------------ Hintergrund
    def loop_forever(self, stop_event):
        last = 0
        while not stop_event.is_set():
            if self.token and time.time() - last > SYNC_EVERY and not self.lib.status.get("running"):
                self.sync()
                last = time.time()
            stop_event.wait(5)
