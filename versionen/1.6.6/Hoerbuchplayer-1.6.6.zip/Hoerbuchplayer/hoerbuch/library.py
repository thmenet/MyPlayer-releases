"""Bibliothek: Ordner durchsuchen, Metadaten (Titel, Kapitel, Cover) lesen und zwischenspeichern."""
import hashlib
import logging
import os
import re
import subprocess
import sys
import threading
import time

from . import storage

log = logging.getLogger("bibliothek")

AUDIO_EXT = {".m4b", ".m4a", ".mp4", ".mp3", ".aac", ".ogg", ".oga", ".opus", ".flac", ".wav"}
MIME = {
    ".m4b": "audio/mp4", ".m4a": "audio/mp4", ".mp4": "audio/mp4", ".aac": "audio/aac",
    ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".opus": "audio/ogg",
    ".flac": "audio/flac", ".wav": "audio/wav",
}
CACHE_VERSION = 3
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def norm(p):
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def make_id(key):
    return hashlib.sha1(key.encode("utf-8", "surrogatepass")).hexdigest()[:16]


def natural_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


# --------------------------------------------------------------------------- ffmpeg
_ffmpeg = None


def ffmpeg_exe():
    global _ffmpeg
    if _ffmpeg is None:
        try:
            import imageio_ffmpeg
            _ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception as e:  # pragma: no cover
            log.warning("ffmpeg nicht verfügbar: %s", e)
            _ffmpeg = ""
    return _ffmpeg


def _run_ffmpeg(args, timeout=60):
    exe = ffmpeg_exe()
    if not exe:
        return None
    try:
        return subprocess.run([exe, "-hide_banner", "-nostdin"] + args, capture_output=True,
                              timeout=timeout, creationflags=NO_WINDOW)
    except Exception as e:
        log.warning("ffmpeg-Fehler: %s", e)
        return None


def ffmpeg_chapters(path):
    """Kapitel über ffmpeg lesen (QuickTime-Kapitelspur, wie sie z. B. Libation schreibt)."""
    r = _run_ffmpeg(["-i", path, "-f", "ffmetadata", "-"])
    if not r or r.returncode != 0:
        return []
    text = r.stdout.decode("utf-8", "replace")
    chapters, cur = [], None
    tb = 1 / 1000
    for line in text.splitlines():
        line = line.strip()
        if line == "[CHAPTER]":
            cur = {"start": 0.0, "title": ""}
            chapters.append(cur)
            tb = 1 / 1000
        elif line.startswith("[") and line.endswith("]"):
            cur = None
        elif cur is not None and "=" in line:
            k, v = line.split("=", 1)
            k = k.upper()
            if k == "TIMEBASE":
                try:
                    a, b = v.split("/")
                    tb = int(a) / int(b)
                except ValueError:
                    pass
            elif k == "START":
                try:
                    cur["_start"] = int(v)
                except ValueError:
                    pass
            elif k == "TITLE":
                cur["title"] = v.replace("\\=", "=").replace("\\;", ";").replace("\\#", "#").replace("\\\\", "\\")
        if cur is not None and "_start" in cur:
            cur["start"] = cur["_start"] * tb
    for c in chapters:
        c.pop("_start", None)
    return chapters


def make_thumb(src_bytes, ext, dest):
    """Speichert ein Cover; grosse Bilder werden (wenn ffmpeg da ist) auf 500px verkleinert."""
    with open(dest + ".orig" + ext, "wb") as f:
        f.write(src_bytes)
    ok = False
    if len(src_bytes) > 120_000:
        r = _run_ffmpeg(["-y", "-loglevel", "error", "-i", dest + ".orig" + ext, "-vf",
                         "scale='min(500,iw)':-2", "-q:v", "3", dest + ".jpg"], timeout=30)
        ok = bool(r and r.returncode == 0 and os.path.exists(dest + ".jpg"))
    if not ok:
        with open(dest + ".jpg", "wb") as f:
            f.write(src_bytes)
    return True


# --------------------------------------------------------------------------- Tags lesen
def _first(v):
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        v = v[0] if v else ""
    return str(v).strip()


def read_file_meta(path):
    """Liest Tags, Dauer, Kapitel und Cover-Bytes einer Audiodatei."""
    import mutagen
    meta = {"title": "", "artist": "", "album": "", "genre": "", "date": "", "comment": "",
            "narrator": "", "duration": 0.0, "chapters": []}
    cover = None
    try:
        f = mutagen.File(path)
    except Exception as e:
        log.warning("Kann %s nicht lesen: %s", path, e)
        f = None
    ext = os.path.splitext(path)[1].lower()
    if f is not None:
        if getattr(f, "info", None) is not None:
            meta["duration"] = float(getattr(f.info, "length", 0) or 0)
        tags = f.tags
        tname = type(f).__name__
        if tname == "MP4" and tags is not None:
            g = tags.get
            meta["title"] = _first(g("©nam"))
            meta["artist"] = _first(g("©ART")) or _first(g("aART"))
            meta["album"] = _first(g("©alb"))
            meta["genre"] = _first(g("©gen"))
            meta["date"] = _first(g("©day"))
            meta["comment"] = _first(g("desc")) or _first(g("ldes")) or _first(g("©cmt"))
            nar = g("----:com.apple.iTunes:NARRATOR") or g("©nrt") or g("©wrt")
            if nar:
                v = nar[0]
                meta["narrator"] = v.decode("utf-8", "replace") if isinstance(v, bytes) else str(v)
            covr = g("covr")
            if covr:
                c = covr[0]
                cover = (bytes(c), ".png" if getattr(c, "imageformat", 13) == 14 else ".jpg")
            try:
                chs = getattr(f, "chapters", None)
                if chs:
                    meta["chapters"] = [{"start": float(c.start), "title": c.title or ""} for c in chs]
            except Exception:
                pass
        elif tags is not None and hasattr(tags, "getall"):  # ID3 (MP3, auch AIFF/WAV)
            def t(fid):
                fr = tags.get(fid)
                return _first(fr.text) if fr is not None and hasattr(fr, "text") else ""
            meta["title"] = t("TIT2")
            meta["artist"] = t("TPE1") or t("TPE2")
            meta["album"] = t("TALB")
            meta["genre"] = t("TCON")
            meta["date"] = t("TDRC") or t("TYER")
            meta["narrator"] = t("TCOM")
            comms = tags.getall("COMM")
            if comms:
                meta["comment"] = _first(comms[0].text)
            pics = tags.getall("APIC")
            if pics:
                p = pics[0]
                cover = (p.data, ".png" if "png" in (p.mime or "") else ".jpg")
            chaps = []
            for ch in tags.getall("CHAP"):
                title = ""
                try:
                    sub = ch.sub_frames.get("TIT2")
                    title = _first(sub.text) if sub is not None else ""
                except Exception:
                    pass
                chaps.append({"start": ch.start_time / 1000.0, "title": title})
            chaps.sort(key=lambda c: c["start"])
            meta["chapters"] = chaps
        elif tags is not None:  # Vorbis/FLAC u. a.
            def t(k):
                try:
                    return _first(tags.get(k))
                except Exception:
                    return ""
            meta["title"] = t("title")
            meta["artist"] = t("artist") or t("albumartist")
            meta["album"] = t("album")
            meta["genre"] = t("genre")
            meta["date"] = t("date")
            meta["comment"] = t("description") or t("comment")
            pics = getattr(f, "pictures", None)
            if pics:
                cover = (pics[0].data, ".png" if "png" in pics[0].mime else ".jpg")
    # MP4 ohne "chpl"-Kapitel: QuickTime-Kapitel über ffmpeg lesen
    if ext in (".m4b", ".m4a", ".mp4") and len(meta["chapters"]) < 2:
        chs = ffmpeg_chapters(path)
        if len(chs) >= 2:
            meta["chapters"] = chs
    # Doppelte/leere Kapitel bereinigen
    clean = []
    for i, c in enumerate(meta["chapters"]):
        if clean and abs(c["start"] - clean[-1]["start"]) < 0.5:
            continue
        clean.append({"start": max(0.0, c["start"]), "title": c["title"] or f"Kapitel {i + 1}"})
    meta["chapters"] = clean
    return meta, cover


FOLDER_COVER_NAMES = ["cover", "folder", "front", "albumart", "poster"]


def folder_cover(d):
    try:
        names = os.listdir(d)
    except OSError:
        return None
    imgs = [n for n in names if os.path.splitext(n)[1].lower() in (".jpg", ".jpeg", ".png", ".webp")]
    for want in FOLDER_COVER_NAMES:
        for n in imgs:
            if os.path.splitext(n)[0].lower() == want:
                return os.path.join(d, n)
    return os.path.join(d, sorted(imgs)[0]) if imgs else None


# --------------------------------------------------------------------------- Bibliothek
class Library:
    def __init__(self, store):
        self.store = store
        self.cache_path = os.path.join(store.dir, "cache.json")
        c = storage.load_json(self.cache_path, {})
        if not isinstance(c, dict) or c.get("version") != CACHE_VERSION:
            c = {"version": CACHE_VERSION, "files": {}}
        self.cache = c
        self.items = {}           # id -> Titel
        self.extra = {}           # per Doppelklick geöffnete Dateien ausserhalb der Bibliothek
        self.lock = threading.RLock()
        self.status = {"running": False, "done": 0, "total": 0, "message": "", "finished_at": 0}
        self._scan_thread = None
        self._rescan_again = False
        self.covers_dir = os.path.join(store.dir, "covers")

    # ---- Datei-Metadaten (mit Cache)
    def file_info(self, path):
        try:
            st = os.stat(path)
        except OSError:
            return None
        key = norm(path)
        c = self.cache["files"].get(key)
        if c and c.get("mtime") == st.st_mtime and c.get("size") == st.st_size:
            return c
        meta, cover = read_file_meta(path)
        cid = None
        if cover and cover[0]:
            cid = make_id(key + "|cover")
            try:
                make_thumb(cover[0], cover[1], os.path.join(self.covers_dir, cid))
            except OSError as e:
                log.warning("Cover nicht speicherbar: %s", e)
                cid = None
        c = {"mtime": st.st_mtime, "size": st.st_size, "meta": meta, "cover": cid}
        self.cache["files"][key] = c
        return c

    def folder_cover_id(self, d):
        p = folder_cover(d)
        if not p:
            return None
        try:
            st = os.stat(p)
        except OSError:
            return None
        key = norm(p)
        c = self.cache["files"].get(key)
        if c and c.get("mtime") == st.st_mtime and c.get("size") == st.st_size:
            return c.get("cover")
        cid = make_id(key + "|cover")
        try:
            with open(p, "rb") as f:
                data = f.read()
            make_thumb(data, os.path.splitext(p)[1].lower(), os.path.join(self.covers_dir, cid))
        except OSError:
            return None
        self.cache["files"][key] = {"mtime": st.st_mtime, "size": st.st_size, "meta": None, "cover": cid}
        return cid

    # ---- Suche
    def start_scan(self):
        with self.lock:
            if self.status["running"]:
                self._rescan_again = True
                return
            self.status.update(running=True, done=0, total=0, message="Suche Dateien …")
            self._scan_thread = threading.Thread(target=self._scan_safe, daemon=True)
            self._scan_thread.start()

    def _scan_safe(self):
        while True:
            try:
                self._scan()
            except Exception:
                log.exception("Fehler beim Einlesen der Bibliothek")
                self.status["message"] = "Fehler beim Einlesen – siehe Protokoll"
            with self.lock:
                if self._rescan_again:
                    self._rescan_again = False
                    continue
                self.status["running"] = False
                self.status["finished_at"] = time.time()
                break

    def _list_dirs(self):
        s = self.store.settings
        dirs = {}  # norm(dir) -> (dir, [dateien])
        seen = set()
        for root in s.get("folders") or []:
            if not root or not os.path.isdir(root):
                continue
            if s.get("recursive", True):
                walker = os.walk(root)
            else:
                try:
                    walker = [(root, [], os.listdir(root))]
                except OSError:
                    continue
            for d, subdirs, files in walker:
                subdirs[:] = [x for x in subdirs if not x.startswith(".") and x.lower() not in ("$recycle.bin", "system volume information")]
                nd = norm(d)
                if nd in seen:
                    continue
                seen.add(nd)
                audio = sorted((f for f in files if os.path.splitext(f)[1].lower() in AUDIO_EXT
                                and not f.startswith("._")), key=natural_key)
                if audio:
                    dirs[nd] = (d, [os.path.join(d, f) for f in audio])
        return dirs

    def is_podcast_dir(self, d):
        nd = norm(d)
        for p in self.store.settings.get("podcast_folders") or []:
            if not p:
                continue
            np_ = norm(p)
            if nd == np_ or nd.startswith(np_.rstrip("\\/") + os.sep):
                return True
        return False

    def _scan(self):
        dirs = self._list_dirs()
        total = sum(len(f) for _, f in dirs.values())
        self.status.update(total=total, done=0, message="Lese Titel …")
        new_items = {}
        last_save = time.time()
        for nd, (d, files) in dirs.items():
            infos = []
            for p in files:
                info = self.file_info(p)
                self.status["done"] += 1
                if info:
                    infos.append((p, info))
                if time.time() - last_save > 20:
                    storage.save_json(self.cache_path, self.cache)
                    last_save = time.time()
            for it in self._build_items(d, infos):
                new_items[it["id"]] = it
            # Zwischenstand sichtbar machen
            with self.lock:
                merged = dict(self.items)
                merged.update(new_items)
                self.items = merged
        with self.lock:
            self.items = new_items
        # Cache aufräumen (Dateien, die es nicht mehr gibt)
        alive = set()
        for _, files in dirs.values():
            alive.update(norm(p) for p in files)
        for k in list(self.cache["files"].keys()):
            if self.cache["files"][k].get("meta") is not None and k not in alive:
                if not os.path.exists(k):
                    del self.cache["files"][k]
        storage.save_json(self.cache_path, self.cache)
        self.status["message"] = f"{len(new_items)} Titel"
        log.info("Bibliothek eingelesen: %d Titel aus %d Dateien", len(new_items), total)

    # ---- Titel bilden
    def _build_items(self, d, infos):
        podcast_dir = self.is_podcast_dir(d)
        fcover = None

        def get_fcover():
            nonlocal fcover
            if fcover is None:
                fcover = self.folder_cover_id(d) or ""
            return fcover or None

        items = []
        rest = list(infos)
        any_podcast_genre = any("podcast" in (i["meta"]["genre"] or "").lower() for _, i in infos)

        # Ordner mit mehreren Dateien eines Buchs -> EIN Hörbuch, Kapitel = Dateien
        # (MP3 pro Kapitel, oder von Libation "nach Kapiteln aufgeteilte" M4B-Dateien)
        if not podcast_dir and len(infos) >= 2 and not any_podcast_genre:
            albums = {(i["meta"]["album"] or "").strip().lower() for _, i in infos}
            has_m4b = any(os.path.splitext(p)[1].lower() == ".m4b" for p, _ in infos)
            m4b_with_chapters = any(os.path.splitext(p)[1].lower() == ".m4b" and len(i["meta"]["chapters"]) >= 2
                                    for p, i in infos)
            numbered = all(re.match(r"^\s*(cd\s*)?\d", os.path.basename(p), re.I) for p, _ in infos)
            if len(albums) == 1 and not m4b_with_chapters and (albums != {""} or (numbered and not has_m4b)):
                items.append(self._folder_book(d, infos, get_fcover))
                rest = []

        for p, info in rest:
            items.append(self._single(p, info, podcast_dir, get_fcover))
        return items

    def _folder_book(self, d, files, get_fcover):
        m0 = files[0][1]["meta"]
        title = m0["album"] or os.path.basename(d.rstrip("\\/"))
        tracks, chapters, off = [], [], 0.0
        for p, info in files:
            m = info["meta"]
            dur = m["duration"] or 0.0
            tracks.append({"path": p, "duration": dur, "mime": MIME.get(os.path.splitext(p)[1].lower(), "audio/mpeg")})
            ctitle = m["title"] or os.path.splitext(os.path.basename(p))[0]
            chapters.append({"start": off, "title": ctitle})
            off += dur
        cover = next((i["cover"] for _, i in files if i.get("cover")), None) or get_fcover()
        key = norm(d) + "|ordner"
        return {
            "id": make_id(key), "path": d, "folder": True,
            "title": title, "author": m0["artist"], "narrator": m0["narrator"], "album": m0["album"],
            "genre": m0["genre"], "date": m0["date"], "description": m0["comment"],
            "duration": off, "chapters": chapters, "tracks": tracks, "cover": cover,
            "auto_kind": "book", "kind_reason": "Ordner mit mehreren Dateien",
            "show": "", "added": max(i["mtime"] for _, i in files),
        }

    def _single(self, p, info, podcast_dir, get_fcover):
        m = info["meta"]
        ext = os.path.splitext(p)[1].lower()
        genre = (m["genre"] or "").lower()
        chapters = m["chapters"] or []
        if podcast_dir:
            kind, why = "podcast", "Podcast-Ordner"
        elif "podcast" in genre:
            kind, why = "podcast", "Genre «Podcast»"
        elif ext == ".m4b":
            kind, why = "book", "M4B-Datei"
        elif len(chapters) >= 2:
            kind, why = "book", "hat Kapitelmarken"
        elif (m["duration"] or 0) >= 2 * 3600:
            kind, why = "book", "länger als 2 Stunden"
        else:
            kind, why = "podcast", "einzelne Datei ohne Kapitel"
        if not chapters:
            chapters = [{"start": 0.0, "title": m["title"] or os.path.splitext(os.path.basename(p))[0]}]
        d = os.path.dirname(p)
        show = m["album"] or os.path.basename(d.rstrip("\\/")) or m["artist"]
        return {
            "id": make_id(norm(p)), "path": p, "folder": False,
            "title": m["title"] or os.path.splitext(os.path.basename(p))[0],
            "author": m["artist"], "narrator": m["narrator"], "album": m["album"], "genre": m["genre"],
            "date": m["date"], "description": m["comment"], "duration": m["duration"] or 0.0,
            "chapters": chapters,
            "tracks": [{"path": p, "duration": m["duration"] or 0.0, "mime": MIME.get(ext, "application/octet-stream")}],
            "cover": info.get("cover") or get_fcover(),
            "auto_kind": kind, "kind_reason": why, "show": show, "added": info["mtime"],
        }

    # ---- Zugriff
    def get(self, item_id):
        with self.lock:
            return self.items.get(item_id) or self.extra.get(item_id)

    def all(self):
        with self.lock:
            return list(self.items.values()) + [v for k, v in self.extra.items() if k not in self.items]

    def in_library_folder(self, path):
        np_ = norm(path)
        for root in self.store.settings.get("folders") or []:
            nr = norm(root).rstrip("\\/")
            if root and (np_.startswith(nr + os.sep)):
                return True
        return False

    def find_or_add_file(self, path):
        """Titel-ID zu einer Datei (z. B. per Doppelklick im Explorer geöffnet).
        Gibt None zurück, solange die Bibliothek diese Datei noch einliest."""
        np_ = norm(path)
        with self.lock:
            for it in list(self.items.values()) + list(self.extra.values()):
                if any(norm(t["path"]) == np_ for t in it["tracks"]):
                    return it["id"]
        if self.status.get("running") and self.in_library_folder(path):
            return None
        info = self.file_info(path)
        if not info:
            return ""
        d = os.path.dirname(path)
        it = self._single(path, info, self.is_podcast_dir(d), lambda: self.folder_cover_id(d))
        it["extern"] = True
        with self.lock:
            self.extra[it["id"]] = it
        return it["id"]
