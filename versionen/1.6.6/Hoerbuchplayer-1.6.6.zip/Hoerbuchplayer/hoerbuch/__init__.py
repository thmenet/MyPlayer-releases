VERSION = "1.6.6"
APP_NAME = "MyPlayer"
