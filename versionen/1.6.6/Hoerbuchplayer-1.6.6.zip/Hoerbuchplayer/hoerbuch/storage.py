"""Speichern und Laden der Daten (Einstellungen, Fortschritt, Cache) als JSON."""
import json
import os
import threading
import time

def data_dir():
    base = os.environ.get("HOERBUCH_DATA") or os.environ.get("APPDATA") or os.path.expanduser("~/.config")
    d = os.path.join(base, "Hoerbuchplayer")
    os.makedirs(d, exist_ok=True)
    os.makedirs(os.path.join(d, "covers"), exist_ok=True)
    return d


def _load(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception:
        # beschädigte Datei: Sicherungskopie behalten, mit Standard weitermachen
        try:
            os.replace(path, path + ".kaputt-" + time.strftime("%Y%m%d-%H%M%S"))
        except OSError:
            pass
        bak = path + ".bak"
        if os.path.exists(bak):
            try:
                with open(bak, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return default


def _save(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    if os.path.exists(path):
        try:
            os.replace(path, path + ".bak")
        except OSError:
            pass
    os.replace(tmp, path)


DEFAULT_SETTINGS = {
    "folders": [],            # Bibliotheksordner
    "recursive": True,        # Unterordner einbeziehen
    "podcast_folders": [],    # Ordner, die als Podcast gelten
    "theme": "dark",          # dark | light
    "speed": 1.0,
    "volume": 1.0,
    "view": "grid",           # grid | list
    "sort": "recent",
    "skip_back": 30,
    "skip_fwd": 30,
    "last_item": None,
}


class Store:
    """Hält settings.json und state.json im Speicher und schreibt sie sicher auf die Platte."""

    def __init__(self):
        self.dir = data_dir()
        self.lock = threading.RLock()
        self.settings_path = os.path.join(self.dir, "settings.json")
        self.state_path = os.path.join(self.dir, "state.json")
        s = _load(self.settings_path, {})
        self.settings = dict(DEFAULT_SETTINGS)
        self.settings.update(s if isinstance(s, dict) else {})
        st = _load(self.state_path, {})
        self.state = st if isinstance(st, dict) else {}
        self.state.setdefault("items", {})
        self._dirty = False

    # ---- Einstellungen
    def save_settings(self):
        with self.lock:
            _save(self.settings_path, self.settings)

    # ---- Zustand pro Titel
    def item(self, item_id, create=False):
        with self.lock:
            it = self.state["items"].get(item_id)
            if it is None and create:
                it = {}
                self.state["items"][item_id] = it
            return it

    def update_item(self, item_id, **kw):
        with self.lock:
            it = self.item(item_id, create=True)
            for k, v in kw.items():
                if v is None:
                    it.pop(k, None)
                else:
                    it[k] = v
            self._dirty = True
            return it

    def mark_dirty(self):
        self._dirty = True

    def flush(self, force=False):
        with self.lock:
            if self._dirty or force:
                _save(self.state_path, self.state)
                self._dirty = False


def load_json(path, default):
    return _load(path, default)


def save_json(path, data):
    _save(path, data)
