﻿# Legt die Verknüpfungen für MyPlayer an und meldet ihn bei Windows als Player für .m4b an (oder entfernt alles wieder).
# Alles nur für den aktuellen Benutzer, ohne Admin-Rechte. Alte Einträge «Hörbuch-Player» (bis 1.4.3) werden ersetzt.
#   -Desktop 1 = auch auf dem Desktop, 0 = nein, -1 = nur wenn es dort schon eine gab
#   -NurWennVorhanden 1 = nur aktualisieren, wenn es schon eine Verknüpfung im Startmenü gibt (beim automatischen Update)
param(
  [Parameter(Mandatory = $true)][string]$Ziel,
  [int]$Desktop = 0,
  [int]$Entfernen = 0,
  [int]$NurWennVorhanden = 0
)
$ErrorActionPreference = 'Stop'
$name = 'MyPlayer'
$oldName = 'Hörbuch-Player'
$exe = Join-Path $Ziel 'MyPlayer.exe'
$oldExe = Join-Path $Ziel 'Hoerbuchplayer.exe'   # Name bis 1.6.5
$ico = Join-Path $Ziel 'web\icon.ico'
$programs = [Environment]::GetFolderPath('Programs')
$deskDir = [Environment]::GetFolderPath('Desktop')
$startmenu = Join-Path $programs "$name.lnk"
$desk = Join-Path $deskDir "$name.lnk"
$oldStart = Join-Path $programs "$oldName.lnk"
$oldDesk = Join-Path $deskDir "$oldName.lnk"
$progId = 'Hoerbuchplayer.Hoerbuch'
$exts = @('.m4b')
$cls = 'HKCU:\Software\Classes'

function Set-Key([string]$path, [string]$valueName, [string]$value) {
  if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
  if ($valueName -eq '') { Set-Item -LiteralPath $path -Value $value }
  else { New-ItemProperty -LiteralPath $path -Name $valueName -Value $value -PropertyType String -Force | Out-Null }
}
function Refresh-Shell {
  try {
    Add-Type -Namespace Hb -Name Shell -MemberDefinition '[DllImport("shell32.dll")] public static extern void SHChangeNotify(int e, int f, System.IntPtr a, System.IntPtr b);'
    [Hb.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
  } catch { }
}

if ($Entfernen -eq 1) {
  foreach ($p in @($startmenu, $desk, $oldStart, $oldDesk)) { if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force } }
  foreach ($k in @("$cls\$progId", "$cls\Applications\MyPlayer.exe", "$cls\Applications\Hoerbuchplayer.exe", 'HKCU:\Software\Hoerbuchplayer')) {
    if (Test-Path -LiteralPath $k) { Remove-Item -LiteralPath $k -Recurse -Force }
  }
  foreach ($e in $exts) {
    $k = "$cls\$e\OpenWithProgids"
    if (Test-Path -LiteralPath $k) { Remove-ItemProperty -LiteralPath $k -Name $progId -ErrorAction SilentlyContinue }
  }
  foreach ($n in @($name, $oldName)) { Remove-ItemProperty -LiteralPath 'HKCU:\Software\RegisteredApplications' -Name $n -ErrorAction SilentlyContinue }
  Refresh-Shell
  Write-Host 'Verknüpfungen und Dateizuordnung entfernt.'
  exit 0
}

$hadStart = (Test-Path -LiteralPath $startmenu) -or (Test-Path -LiteralPath $oldStart)
$hadDesk = (Test-Path -LiteralPath $desk) -or (Test-Path -LiteralPath $oldDesk)
if ($NurWennVorhanden -eq 1 -and -not $hadStart) { Write-Host 'Keine Verknüpfung im Startmenü – nichts zu tun.'; exit 0 }
if ($Desktop -eq -1) { $Desktop = [int]$hadDesk }

# --- Download-Markierung entfernen (sonst warnt Windows beim Start der .exe)
Get-ChildItem -LiteralPath $Ziel -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notlike '*\.venv\*' } | Unblock-File -ErrorAction SilentlyContinue

# --- alte Verknüpfungen «Hörbuch-Player» weg, neue «MyPlayer» anlegen
foreach ($p in @($oldStart, $oldDesk)) { if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force } }
if ($Desktop -ne 1 -and (Test-Path -LiteralPath $desk)) { Remove-Item -LiteralPath $desk -Force }
$links = @($startmenu)
if ($Desktop -eq 1) { $links += $desk }
$ws = New-Object -ComObject WScript.Shell
foreach ($p in $links) {
  $s = $ws.CreateShortcut($p)
  $s.TargetPath = $exe
  $s.WorkingDirectory = $Ziel
  $s.IconLocation = "$ico,0"
  $s.Description = 'MyPlayer – Hörbücher und Podcasts'
  $s.Save()
  Write-Host "Verknüpfung angelegt: $p"
}

# --- an Taskleiste/Start angeheftete oder selbst angelegte Verknüpfungen auf die alte Hoerbuchplayer.exe umstellen
$pinned = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned'
$lnks = @()
foreach ($d in @($pinned, $programs)) { if (Test-Path -LiteralPath $d) { $lnks += Get-ChildItem -LiteralPath $d -Filter *.lnk -Recurse -ErrorAction SilentlyContinue } }
if (Test-Path -LiteralPath $deskDir) { $lnks += Get-ChildItem -LiteralPath $deskDir -Filter *.lnk -ErrorAction SilentlyContinue }
foreach ($f in $lnks) {
  try {
    $l = $ws.CreateShortcut($f.FullName)
    if ($l.TargetPath -ieq $oldExe) { $l.TargetPath = $exe; $l.Save(); Write-Host "Umgestellt auf MyPlayer.exe: $($f.FullName)" }
  } catch { }
}

# --- Dateityp anmelden (erscheint unter «Öffnen mit» und in «Standard-Apps»)
$cmd = '"' + $exe + '" "%1"'
Set-Key "$cls\$progId" '' 'Hörbuch'
Set-Key "$cls\$progId" 'FriendlyTypeName' 'Hörbuch'
Set-Key "$cls\$progId\DefaultIcon" '' "$ico,0"
Set-Key "$cls\$progId\Application" 'ApplicationName' $name
Set-Key "$cls\$progId\Application" 'ApplicationIcon' "$ico,0"
Set-Key "$cls\$progId\shell\open" 'FriendlyAppName' $name
Set-Key "$cls\$progId\shell\open\command" '' $cmd
Set-Key "$cls\Applications\MyPlayer.exe" 'FriendlyAppName' $name
Set-Key "$cls\Applications\MyPlayer.exe\DefaultIcon" '' "$ico,0"
Set-Key "$cls\Applications\MyPlayer.exe\shell\open\command" '' $cmd
# alter Eintrag (falls bei «Öffnen mit» einmal Hoerbuchplayer.exe gewählt wurde) zeigt neu auf MyPlayer.exe
if (Test-Path -LiteralPath "$cls\Applications\Hoerbuchplayer.exe") {
  Set-Key "$cls\Applications\Hoerbuchplayer.exe\shell\open\command" '' $cmd
  Remove-Item -LiteralPath "$cls\Applications\Hoerbuchplayer.exe\SupportedTypes" -Recurse -Force -ErrorAction SilentlyContinue
}
foreach ($e in $exts) {
  Set-Key "$cls\$e\OpenWithProgids" $progId ''
  Set-Key "$cls\Applications\MyPlayer.exe\SupportedTypes" $e ''
  Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities\FileAssociations' $e $progId
}
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationName' $name
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationDescription' 'MyPlayer – Hörbücher und Podcasts'
Set-Key 'HKCU:\Software\Hoerbuchplayer\Capabilities' 'ApplicationIcon' "$ico,0"
Remove-ItemProperty -LiteralPath 'HKCU:\Software\RegisteredApplications' -Name $oldName -ErrorAction SilentlyContinue
Set-Key 'HKCU:\Software\RegisteredApplications' $name 'Software\Hoerbuchplayer\Capabilities'
# alte Hoerbuchplayer.exe weg, sobald MyPlayer.exe da ist
if ((Test-Path -LiteralPath $exe) -and (Test-Path -LiteralPath $oldExe)) { Remove-Item -LiteralPath $oldExe -Force -ErrorAction SilentlyContinue }
Refresh-Shell
Write-Host 'Dateityp .m4b angemeldet.'
