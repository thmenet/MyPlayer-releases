VERSION = "1.13.1"
APP_NAME = "MyPlayer"
