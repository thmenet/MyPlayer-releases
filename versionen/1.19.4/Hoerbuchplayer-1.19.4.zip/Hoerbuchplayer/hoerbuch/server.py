"""Kleiner Webserver: liefert Oberfläche, Audio (mit Spulen) und die Daten.
PC-Player: nur auf diesem Computer (127.0.0.1). Heimserver (--server): im Heimnetz, mit Profilen je Person."""
import http.cookies
import ipaddress
import json
import logging
import mimetypes
import os
import re
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import VERSION, APP_NAME
from .modus import SERVER
from .storage import Profiles, SHARED_KEYS
from .jukebox import Jukebox

log = logging.getLogger("server")
WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
CHUNK = 256 * 1024
# feste Dateitypen (die Windows-Registry liefert manchmal falsche Werte)
STATIC_TYPES = {".html": "text/html", ".css": "text/css", ".js": "application/javascript",
                ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon"}
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

PICK_SCRIPT = r"""
import sys, tkinter
from tkinter import filedialog
r = tkinter.Tk(); r.withdraw(); r.attributes('-topmost', True)
p = filedialog.askdirectory(parent=r, title=sys.argv[2], initialdir=sys.argv[3] or None, mustexist=True)
r.destroy()
open(sys.argv[1], 'w', encoding='utf-8').write(p or '')
"""


def visible_bookmarks(st):
    return [x for x in (st.get("bookmarks") or []) if not x.get("deleted")]


class App:
    """Verbindet Server, Bibliothek und Speicher."""

    def __init__(self, store, library):
        self.main_store = store           # Bibliothek, gemeinsame Einstellungen (PC-Player: alles)
        self.server_mode = SERVER
        self.profiles = Profiles(store) if SERVER else None
        self._local = threading.local()   # pro Anfrage: welches Profil
        self._clouds = {}
        self.cloud_stop = threading.Event()
        self.lib = library
        self.token = self._load_token(store) if SERVER else secrets.token_urlsafe(18)
        self.last_beat = time.time()
        self.had_beat = False
        self.bye_at = None
        self.quit_event = threading.Event()
        self.pending_open = None   # Datei, die die Oberfläche öffnen soll
        from .updater import Updater
        from .cloud import Cloud
        self.updater = Updater(store)
        from .musik import Musik
        self.musik = Musik(store)          # «Meine Musik» (Musik-Ordner gelten für alle)
        self.jukebox = Jukebox(self.musik, store.dir)   # gemeinsame Playlist fürs ganze Haus
        self.port = 0
        self.sonos = None
        if SERVER:                         # Sonos nur auf dem Heimserver (die Boxen holen den Ton von dort)
            from .sonos import Sonos
            self.sonos = Sonos(self)
        self._Cloud = Cloud
        self._cloud_main = Cloud(store, library)

    # ---- Profile (nur Heimserver)
    def set_profile(self, pid):
        """Für die laufende Anfrage das Profil wählen (aus dem Cookie)."""
        if not self.server_mode:
            return
        st = self.profiles.get(pid) if pid else None
        self._local.pid = pid if st else None
        self._local.store = st

    @property
    def profile_id(self):
        return getattr(self._local, "pid", None) if self.server_mode else None

    @property
    def store(self):
        """Speicher des aktuellen Profils (PC-Player: der einzige Speicher)."""
        return (getattr(self._local, "store", None) if self.server_mode else None) or self.main_store

    @staticmethod
    def _load_token(store):
        """Heimserver: Schlüssel für Änderungen in der Datei «schluessel» merken. Sonst hätte jede offene Seite
        (Handy, iPad mit TV-Ansicht) nach einem Update einen alten Schlüssel und bekäme nur noch «verboten»."""
        path = os.path.join(store.dir, "schluessel")
        try:
            with open(path, encoding="utf-8") as f:
                t = f.read().strip()
            if len(t) >= 20:
                return t
        except OSError:
            pass
        t = secrets.token_urlsafe(18)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(t)
            os.chmod(path, 0o600)
        except OSError:
            pass
        return t

    @property
    def cloud(self):
        return self.cloud_for(self.profile_id)

    def cloud_for(self, pid):
        """Verbindung zu player.menet.ch – je Profil ein eigenes Konto (eigener Hörstand)."""
        if not self.server_mode or not pid:
            return self._cloud_main
        c = self._clouds.get(pid)
        if c is None:
            st = self.profiles.get(pid)
            if st is None:
                return self._cloud_main
            c = self._clouds[pid] = self._Cloud(st, self.lib)
            threading.Thread(target=c.loop_forever, args=(self.cloud_stop,), daemon=True).start()
        return c

    def start_clouds(self):
        """Heimserver: Abgleich für alle Profile im Hintergrund starten; PC-Player: den einen."""
        if self.server_mode:
            for p in self.profiles.list:
                self.cloud_for(p["id"])
        else:
            threading.Thread(target=self._cloud_main.loop_forever, args=(self.cloud_stop,), daemon=True).start()

    def all_clouds(self):
        return list(self._clouds.values()) if self.server_mode else [self._cloud_main]

    def flush_all(self, force=False):
        self.main_store.flush(force)
        if self.server_mode:
            self.profiles.flush_all(force)

    def settings_view(self):
        """Einstellungen für die Oberfläche: persönliche des Profils + gemeinsame (Bibliotheksordner)."""
        s = dict(self.store.settings)
        if self.server_mode:
            for k in SHARED_KEYS:
                if k in self.main_store.settings:
                    s[k] = self.main_store.settings[k]
            for k in ("cloud_token",):
                s.pop(k, None)
        return s

    def profile_info(self):
        if not self.server_mode:
            return None
        return {"list": self.profiles.list, "current": self.profile_id}

    # ---- Darstellung eines Titels
    def light(self, it):
        st = self.store.item(it["id"]) or {}
        kind = st.get("kind") or it["auto_kind"]
        return {
            "id": it["id"], "title": it["title"], "author": it["author"], "narrator": it.get("narrator", ""),
            "show": it["show"], "kind": kind, "auto_kind": it["auto_kind"], "kind_reason": it["kind_reason"],
            "kind_manual": bool(st.get("kind")), "duration": it["duration"], "cover": it["cover"],
            "pos": st.get("pos", 0), "finished": bool(st.get("finished")), "fav": bool(st.get("fav")),
            "archived": bool(st.get("archived")), "updated": st.get("updated", 0), "added": it["added"],
            "date": it.get("date", ""), "folder": it["folder"], "nchapters": len(it["chapters"]),
            "nbookmarks": len(visible_bookmarks(st)), "on_server": self.cloud.is_on_server(it["id"]), "path": it["path"], "genre": it.get("genre", ""),
        }

    def full(self, it):
        d = self.light(it)
        st = self.store.item(it["id"]) or {}
        d.update({
            "description": it.get("description", ""), "album": it.get("album", ""),
            "chapters": it["chapters"],
            "tracks": [{"duration": t["duration"], "mime": t["mime"], "name": os.path.basename(t["path"])} for t in it["tracks"]],
            "bookmarks": visible_bookmarks(st),
        })
        return d


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "Hoerbuchplayer"

        def log_message(self, fmt, *args):  # keine Konsolen-Ausgabe (pythonw!)
            pass

        # ---- Hilfen
        def _host_ok(self):
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
            if host in ("127.0.0.1", "localhost"):
                return True
            if not app.server_mode:
                return False
            # Heimserver: nur über eine IP-Adresse oder einen bekannten Namen – nie über fremde Domains
            # (Schutz davor, dass eine Webseite im Browser über einen Trick Geräte im Heimnetz anspricht)
            try:
                ipaddress.ip_address(host)
                return True
            except ValueError:
                pass
            # Tailscale («tailscale serve» macht https://<name>.<tailnet>.ts.net und reicht lokal an uns weiter):
            # solche Namen nur, wenn die Anfrage vom eigenen Gerät kommt – also wirklich über Tailscale
            if host.endswith(".ts.net") and ipaddress.ip_address(self.client_address[0]).is_loopback:
                return True
            return host in allowed_names()

        def _cookie_profile(self):
            try:
                c = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
                return c["mp_profil"].value if "mp_profil" in c else None
            except http.cookies.CookieError:
                return None

        def send_json(self, obj, status=200, headers=None):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def send_bytes(self, data, ctype, status=200, cache=None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", cache or "no-cache")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        def not_found(self):
            self.send_bytes(b"Nicht gefunden", "text/plain; charset=utf-8", 404)

        def read_body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return {}
            if n > 2_000_000:
                self.close_connection = True     # Rest nicht lesen → Verbindung danach schliessen
            raw = self.rfile.read(min(n, 2_000_000))
            try:
                return json.loads(raw.decode("utf-8"))
            except Exception:
                return {}

        # ---- GET
        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            if not self._host_ok():
                return self.send_bytes(b"", "text/plain", 403)
            app.set_profile(self._cookie_profile())
            try:
                self._get()
            except (ConnectionError, BrokenPipeError, TimeoutError):
                pass
            except Exception:
                log.exception("Fehler bei GET %s", self.path)
                try:
                    self.send_json({"error": "Interner Fehler"}, 500)
                except Exception:
                    pass

        def _musik_get(self, path, q):
            mu = app.musik
            arg = lambda k: (q.get(k) or [""])[0]
            if path == "/api/musik/uebersicht":
                return self.send_json(mu.overview())
            if path == "/api/musik/status":
                return self.send_json(mu.public_status())
            if path == "/api/musik/album":
                a = mu.album(arg("id"))
                return self.send_json(a) if a else self.send_json({"error": "Album nicht gefunden"}, 404)
            if path == "/api/musik/interpret":
                r = mu.artist(arg("id"))
                return self.send_json(r) if r else self.send_json({"error": "Interpret nicht gefunden"}, 404)
            if path == "/api/musik/suche":
                return self.send_json({"tracks": mu.search(arg("q"))})
            if path == "/api/musik/zufall":
                return self.send_json({"tracks": mu.random(100, arg("genre") or None)})
            if path == "/api/musik/genre":
                g = mu.genre(arg("name"))
                return self.send_json(g) if g else self.send_json({"error": "Genre nicht gefunden"}, 404)
            if path == "/api/musik/jukebox":
                return self.send_json(app.jukebox.state())
            m = re.match(r"^/musik/datei/([0-9a-f]{16})", path)
            if m:
                app.last_media = time.time()
                fp, ctype = mu.track_file(m.group(1))
                return self.send_file(fp, ctype) if fp else self.not_found()
            m = re.match(r"^/musik/cover/([0-9a-f]{12})", path)
            if m:
                cp = mu.cover(m.group(1), big=bool(arg("gross")))
                if not cp:
                    return self.not_found()
                with open(cp, "rb") as f:
                    data = f.read()
                ctype = "image/png" if cp.lower().endswith(".png") else "image/jpeg"
                return self.send_bytes(data, ctype, cache="max-age=604800")
            return self.not_found()

        def _sonos(self, action, b):
            if not app.sonos:
                return self.send_json({"error": "Sonos gibt es nur auf dem Heimserver."}, 400)
            from .sonos import SonosError
            pid = app.profile_id or ""
            try:
                if action == "raeume":
                    gs = app.sonos.groups(fresh=bool(b.get("neu")))
                    return self.send_json({"groups": [{"id": g["id"], "name": g["name"]} for g in gs],
                                           "rooms": [{k: r[k] for k in ("id", "name", "group", "coordinator")} for r in app.sonos.rooms()]})
                if action == "gruppe":
                    st = app.sonos.regroup(pid, str(b.get("room") or ""), bool(b.get("join")))
                    return self.send_json(st | {"rooms": [{k: r[k] for k in ("id", "name", "group", "coordinator")} for r in app.sonos.rooms()]})
                if action == "start":
                    kw = {k: b.get(k) for k in ("id", "pos", "ids", "idx", "t")}
                    return self.send_json(app.sonos.start(pid, str(b.get("group") or ""), b.get("kind") if b.get("kind") in ("book", "jukebox") else "music", **kw))
                if action == "befehl":
                    return self.send_json(app.sonos.command(pid, str(b.get("cmd") or ""), b.get("value")))
                if action == "stand":
                    return self.send_json(app.sonos.state(pid))
            except SonosError as e:
                return self.send_json({"error": str(e)}, 400)
            return self.not_found()

        def _profil(self, action, b):
            if not app.server_mode:
                return self.send_json({"error": "Profile gibt es nur auf dem Heimserver."}, 400)
            pr = app.profiles
            cookie = lambda pid: {"Set-Cookie": f"mp_profil={pid}; Path=/; Max-Age=31536000; SameSite=Lax"}
            try:
                if action == "waehlen":
                    pid = str(b.get("id") or "")
                    if not pr.find(pid):
                        return self.send_json({"error": "Profil nicht gefunden"}, 404)
                    app.cloud_for(pid)
                    return self.send_json({"ok": True, "profiles": {"list": pr.list, "current": pid}}, headers=cookie(pid))
                if action == "neu":
                    p = pr.add(b.get("name"))
                    app.cloud_for(p["id"])
                    return self.send_json({"ok": True, "profile": p, "profiles": {"list": pr.list, "current": p["id"]}}, headers=cookie(p["id"]))
                if action == "umbenennen":
                    pr.rename(str(b.get("id") or ""), b.get("name"))
                    return self.send_json({"ok": True, "profiles": app.profile_info()})
                if action == "loeschen":
                    pid = str(b.get("id") or "")
                    c = app._clouds.pop(pid, None)
                    pr.remove(pid)
                    return self.send_json({"ok": True, "profiles": app.profile_info()})
            except ValueError as e:
                return self.send_json({"error": str(e)}, 400)
            return self.not_found()

        def _get(self):
            u = urlparse(self.path)
            path = u.path
            q = parse_qs(u.query)
            if path == "/" or path == "/index.html":
                return self.static("index.html")
            if path == "/mini":
                return self.static("mini.html")
            if path == "/gast" and app.server_mode and app.profiles:
                # Link aus dem QR-Code der TV-Ansicht: als Gast anmelden und gleich zur Jukebox
                g = next((x for x in app.profiles.list if x.get("guest")), None)
                self.send_response(302)
                if g:
                    self.send_header("Set-Cookie", f"mp_profil={g['id']}; Path=/; Max-Age=31536000; SameSite=Lax")
                self.send_header("Location", "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            if path == "/api/qr":
                from .qr import svg
                try:
                    return self.send_bytes(svg((q.get("text") or [""])[0][:180]).encode(), "image/svg+xml", cache="max-age=86400")
                except ValueError:
                    return self.send_bytes(b"", "text/plain", 400)
            if path.startswith("/static/"):
                return self.static(path[len("/static/"):])
            if path.startswith("/media/"):
                app.last_media = time.time()
                m = re.match(r"^/media/([0-9a-f]+)/(\d+)", path)
                it = app.lib.get(m.group(1)) if m else None
                if not it:
                    return self.not_found()
                n = int(m.group(2))
                if n >= len(it["tracks"]):
                    return self.not_found()
                t = it["tracks"][n]
                return self.send_file(t["path"], t["mime"])
            if path.startswith("/cover/"):
                cid = path[len("/cover/"):]
                if not re.fullmatch(r"[0-9a-f]{16}", cid):
                    return self.not_found()
                base = os.path.join(app.lib.covers_dir, cid)
                p = base + ".jpg"
                if q.get("big"):
                    for ext in (".jpg", ".png", ".jpeg", ".webp"):
                        if os.path.exists(base + ".orig" + ext):
                            p = base + ".orig" + ext
                            break
                if not os.path.exists(p):
                    return self.not_found()
                with open(p, "rb") as f:
                    data = f.read()
                ctype = STATIC_TYPES.get(os.path.splitext(p)[1].lower()) or mimetypes.guess_type(p)[0] or "image/jpeg"
                return self.send_bytes(data, ctype, cache="max-age=86400")
            if path == "/api/init":
                rp = app.store.settings.pop("resume_play", None)
                resume = bool(rp) and rp != VERSION   # nur nach erfolgreichem Update weiterspielen
                rm = app.store.settings.pop("resume_music", None)
                resume_music = rm if isinstance(rm, dict) and rm.get("version") != VERSION else None
                if rp is not None or rm is not None:
                    app.store.save_settings()
                return self.send_json({"version": VERSION, "name": APP_NAME, "settings": app.settings_view(),
                                       "server": app.server_mode, "profiles": app.profile_info(), "lan_origin": lan_origin(app) if app.server_mode else "",
                                       "status": app.lib.status, "data_dir": app.store.dir,
                                       "resume_play": resume, "resume_music": resume_music, "update": app.updater.public()})
            if path == "/api/update":
                return self.send_json(app.updater.public())
            if path.startswith("/api/musik/") or path.startswith("/musik/"):
                return self._musik_get(path, q)
            if path == "/api/library":
                items = [app.light(i) for i in app.lib.all()]
                return self.send_json({"items": items, "status": app.lib.status})
            if path == "/api/status":
                return self.send_json(app.lib.status)
            if path == "/api/item":
                it = app.lib.get((q.get("id") or [""])[0])
                if not it:
                    return self.send_json({"error": "Titel nicht gefunden"}, 404)
                # Vor dem Abspielen den neuesten Stand von player.menet.ch holen (z. B. im Auto weitergehört)
                if app.cloud.token and app.cloud.is_on_server(it["id"]) and time.time() - app.cloud.status["last_sync"] > 20:
                    app.cloud.sync()
                return self.send_json(app.full(it))
            return self.not_found()

        def static(self, rel):
            rel = rel.split("?")[0]
            p = os.path.normpath(os.path.join(WEB_DIR, rel))
            if not p.startswith(os.path.normpath(WEB_DIR)) or not os.path.isfile(p):
                return self.not_found()
            with open(p, "rb") as f:
                data = f.read()
            if rel in ("index.html", "mini.html"):
                data = data.replace(b"__TOKEN__", app.token.encode()).replace(b"__VERSION__", VERSION.encode())
            ctype = STATIC_TYPES.get(os.path.splitext(p)[1].lower()) or mimetypes.guess_type(p)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
                ctype += "; charset=utf-8"
            self.send_bytes(data, ctype)

        def send_file(self, path, ctype):
            """Datei mit HTTP-Range-Unterstützung senden (nötig zum Spulen)."""
            try:
                size = os.path.getsize(path)
                f = open(path, "rb")
            except OSError:
                return self.not_found()
            with f:
                start, end = 0, size - 1
                status = 200
                rng = self.headers.get("Range")
                if rng:
                    m = re.match(r"bytes=(\d*)-(\d*)", rng.strip())
                    if m:
                        a, b = m.groups()
                        if a == "" and b != "":
                            start = max(0, size - int(b))
                        else:
                            start = int(a or 0)
                            if b:
                                end = min(int(b), size - 1)
                        if start >= size or start > end:
                            self.send_response(416)
                            self.send_header("Content-Range", f"bytes */{size}")
                            self.send_header("Content-Length", "0")
                            self.end_headers()
                            return
                        status = 206
                length = end - start + 1
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(length))
                self.send_header("Cache-Control", "no-cache")
                if status == 206:
                    self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
                self.end_headers()
                if self.command == "HEAD":
                    return
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)

        # ---- POST
        def do_POST(self):
            if not self._host_ok() or self.headers.get("X-Token") != app.token:
                # Inhalt trotzdem lesen (bzw. Verbindung schliessen) – sonst bleibt er in der Leitung und die nächste
                # Anfrage auf derselben Verbindung scheitert mit «501»
                n = int(self.headers.get("Content-Length") or 0)
                if 0 < n <= 2_000_000:
                    self.rfile.read(n)
                else:
                    self.close_connection = True
                return self.send_json({"error": "verboten"}, 403)
            app.set_profile(self._cookie_profile())
            try:
                body = self.read_body()
                self._post(urlparse(self.path).path, body)
            except (ConnectionError, BrokenPipeError):
                pass
            except Exception:
                log.exception("Fehler bei POST %s", self.path)
                try:
                    self.send_json({"error": "Interner Fehler"}, 500)
                except Exception:
                    pass

        def _post(self, path, b):
            store, lib = app.store, app.lib
            if path.startswith("/api/profil/"):
                return self._profil(path[len("/api/profil/"):], b)
            if path.startswith("/api/sonos/"):
                return self._sonos(path[len("/api/sonos/"):], b)
            if path == "/api/log":
                # Meldungen der Oberfläche ins Protokoll (z. B. warum die Apple-Music-Anmeldung scheiterte)
                log.warning("Oberfläche: %s", str(b.get("msg") or "")[:500])
                return self.send_json({"ok": True})
            if path == "/api/heartbeat":
                app.last_beat = time.time()
                app.had_beat = True
                app.bye_at = None
                return self.send_json({"ok": True, "status": lib.status, "cloud": app.cloud.public()})
            if path == "/api/bye":
                app.bye_at = time.time()
                store.flush()
                return self.send_json({"ok": True})
            if path == "/api/progress":
                iid = b.get("id")
                if not lib.get(iid):
                    return self.send_json({"error": "unbekannt"}, 404)
                pos = float(b.get("pos") or 0)
                dur = float(b.get("duration") or 0) or lib.get(iid)["duration"]
                kw = {"pos": round(pos, 2), "updated": time.time(), "changed_ms": int(time.time() * 1000)}
                if dur and pos >= dur - 20:
                    kw["finished"] = True
                store.update_item(iid, **kw)
                store.settings["last_item"] = iid
                if b.get("flush"):
                    store.flush()
                    store.save_settings()
                return self.send_json({"ok": True})
            if path == "/api/flags":
                ids = b.get("ids") if isinstance(b.get("ids"), list) else [b.get("id")]
                done = []
                for iid in ids:
                    it = lib.get(iid)
                    if not it:
                        continue
                    kw = {}
                    if "fav" in b:
                        kw["fav"] = True if b["fav"] else None
                    if "archived" in b:
                        kw["archived"] = True if b["archived"] else None
                        if b["archived"]:
                            kw["fav"] = None
                    if "kind" in b:
                        kw["kind"] = b["kind"] if b["kind"] in ("book", "podcast") else None
                    if "finished" in b:
                        if b["finished"]:
                            kw["finished"] = True
                            kw["pos"] = it["duration"]
                        else:
                            kw["finished"] = None
                            kw["pos"] = 0
                        kw["updated"] = time.time()
                    kw["changed_ms"] = int(time.time() * 1000)
                    store.update_item(iid, **kw)
                    done.append(app.light(it))
                store.flush()
                if "ids" in b:
                    return self.send_json({"items": done})
                if not done:
                    return self.send_json({"error": "unbekannt"}, 404)
                return self.send_json(done[0])
            if path == "/api/bookmark":
                iid = b.get("id")
                if not lib.get(iid):
                    return self.send_json({"error": "unbekannt"}, 404)
                st = store.item(iid, create=True)
                bms = st.setdefault("bookmarks", [])
                act = b.get("action")
                now = int(time.time() * 1000)
                if act == "add":
                    bms.append({"id": uuid.uuid4().hex[:10], "pos": round(float(b.get("pos") or 0), 2),
                                "note": str(b.get("note") or "")[:500], "created": time.time(), "changed_ms": now})
                    bms.sort(key=lambda x: x["pos"])
                elif act == "delete":
                    for x in bms:
                        if x["id"] == b.get("bid"):
                            x.update(deleted=True, changed_ms=now)
                elif act == "edit":
                    for x in bms:
                        if x["id"] == b.get("bid"):
                            x.update(note=str(b.get("note") or "")[:500], changed_ms=now)
                store.mark_dirty()
                store.flush()
                return self.send_json({"bookmarks": visible_bookmarks(st)})
            if path == "/api/settings":
                s = store.settings
                shared = app.main_store.settings     # Bibliotheksordner (auf dem Heimserver für alle gleich)
                rescan = False
                for k in ("folders", "podcast_folders"):
                    if k in b and isinstance(b[k], list):
                        new = [str(x).strip() for x in b[k] if str(x).strip()]
                        if new != shared.get(k):
                            shared[k] = new
                            rescan = True
                if "music_folders" in b and isinstance(b["music_folders"], list):
                    new = [str(x).strip() for x in b["music_folders"] if str(x).strip()]
                    if new != shared.get("music_folders"):
                        shared["music_folders"] = new
                        app.main_store.save_settings()
                        app.musik.start_scan()
                if "sonos_hosts" in b and isinstance(b["sonos_hosts"], list):
                    shared["sonos_hosts"] = [str(x).strip() for x in b["sonos_hosts"] if str(x).strip()][:10]
                    app.main_store.save_settings()
                if "music_src" in b and b["music_src"] in ("own", "apple", "jukebox"):
                    s["music_src"] = b["music_src"]
                if "recursive" in b and bool(b["recursive"]) != shared.get("recursive"):
                    shared["recursive"] = bool(b["recursive"])
                    rescan = True
                for k in ("theme", "view", "sort"):
                    if k in b and isinstance(b[k], str):
                        s[k] = b[k]
                if "music" in b:
                    s["music"] = bool(b["music"])
                for k in ("speed", "volume"):
                    if k in b:
                        try:
                            s[k] = float(b[k])
                        except (TypeError, ValueError):
                            pass
                for k in ("skip_back", "skip_fwd"):
                    if k in b:
                        try:
                            s[k] = max(5, min(300, int(b[k])))
                        except (TypeError, ValueError):
                            pass
                store.save_settings()
                if rescan and shared is not s:
                    app.main_store.save_settings()
                if rescan:
                    lib.start_scan()
                return self.send_json({"settings": app.settings_view(), "rescan": rescan})
            if path == "/api/open":
                p = str(b.get("path") or "")
                if p and os.path.isfile(p):
                    app.pending_open = p
                    return self.send_json({"ok": True})
                return self.send_json({"ok": False}, 404)
            if path == "/api/pending":
                p = app.pending_open
                if not p:
                    return self.send_json({})
                iid = lib.find_or_add_file(p)
                if iid is None:
                    return self.send_json({"wait": True})
                app.pending_open = None
                if not iid:
                    return self.send_json({"error": f"Datei konnte nicht gelesen werden: {os.path.basename(p)}"})
                return self.send_json({"id": iid})
            if path == "/api/cloud":
                return self.send_json(app.cloud.public())
            if path == "/api/musik/token":
                # Apple-Music-Zugang: das Token stellt player.menet.ch aus (der Schlüssel bleibt dort).
                # Profile ohne eigene Verbindung (z. B. «Gast» für die Jukebox-Suche) nehmen die eines anderen Profils –
                # es ist nur der App-Schlüssel, nicht das Apple-Konto der Person.
                cl = app.cloud
                if not cl.token and app.server_mode and app.profiles:
                    cl = next((c for c in (app.cloud_for(x["id"]) for x in app.profiles.list) if c.token), cl)
                if not cl.token:
                    return self.send_json({"error": "Für Apple Music zuerst in den Einstellungen mit player.menet.ch verbinden."})
                # Adresse, unter der die Seite offen ist – nur wenn sie zu dieser Anfrage passt (gleicher Name wie im Host-Kopf)
                origin = str(b.get("origin") or "").strip().lower()
                host = (self.headers.get("Host") or "").lower()
                if not re.fullmatch(r"https?://[a-z0-9.\-]+(:\d+)?", origin) or origin.split("://", 1)[1].split(":")[0] != host.split(":")[0]:
                    origin = ""
                try:
                    return self.send_json(cl.music_token(origin))
                except Exception as e:
                    return self.send_json({"error": str(e)})
            if path == "/api/cloud/pair":
                try:
                    name = None
                    if app.server_mode:
                        pr = app.profiles.find(app.profile_id)
                        name = f"MyPlayer Heimserver ({pr['name']})" if pr else "MyPlayer Heimserver"
                    return self.send_json(app.cloud.pair(str(b.get("code") or ""), name=name))
                except Exception as e:
                    return self.send_json({"error": str(e)}, 400)
            if path == "/api/cloud/unpair":
                return self.send_json(app.cloud.unpair())
            if path == "/api/cloud/sync":
                return self.send_json(app.cloud.sync())
            if path == "/api/cloud/upload":
                ids = [i for i in (b.get("ids") or []) if lib.get(i)]
                n = app.cloud.enqueue(ids)
                return self.send_json({"added": n} | app.cloud.public())
            if path == "/api/cloud/cancel":
                app.cloud.cancel_uploads()
                return self.send_json(app.cloud.public())
            if path == "/api/cloud/delete":
                try:
                    ok = app.cloud.delete_remote(b.get("id"))
                    return self.send_json({"ok": ok} | app.cloud.public())
                except Exception as e:
                    return self.send_json({"error": str(e)}, 400)
            if path == "/api/update/check":
                return self.send_json(app.updater.check(force=bool(b.get("force"))))
            if path == "/api/update/apply":
                store.settings["resume_play"] = VERSION if b.get("playing") else None
                # lief Apple Music: Warteschlange, Titel und Stelle merken (nach dem Neustart dort weiter)
                store.settings["resume_music"] = ({"version": VERSION, **b["music"]} if isinstance(b.get("music"), dict) else None)
                store.flush(force=True)
                store.save_settings()
                ok, msg = app.updater.apply(lambda: app.quit_event.set())
                if not ok:
                    store.settings.pop("resume_play", None)
                    store.settings.pop("resume_music", None)
                return self.send_json({"ok": ok, "error": msg, "update": app.updater.public()})
            if path == "/api/musik/jukebox":
                jb, cmd = app.jukebox, b.get("cmd")
                who = ""
                if app.server_mode and app.profiles:
                    pr = app.profiles.find(app.profile_id)
                    who = pr["name"] if pr else ""
                try:
                    if cmd == "toggle":
                        jb.toggle(str(b.get("id") or ""), who, b.get("meta"))
                    elif cmd == "album":
                        jb.add_many([str(x) for x in b.get("ids") or []][:200], who, b.get("metas"))
                    elif cmd == "weiter":
                        jb.advance()
                    elif cmd == "zurueck":
                        jb.back()
                    elif cmd == "mix":
                        jb.set_mix(bool(b.get("on")), str(b.get("genre") or ""))
                    elif cmd == "leeren":
                        jb.clear()
                except ValueError as e:
                    return self.send_json({"error": str(e)}, 400)
                return self.send_json(jb.state())
            if path == "/api/musik/neu-einlesen":
                app.musik.start_scan()
                return self.send_json(app.musik.public_status())
            if path == "/api/rescan":
                lib.start_scan()
                return self.send_json({"ok": True})
            if path == "/api/pickfolder":
                return self.send_json({"path": pick_folder(b.get("title") or "Ordner wählen", b.get("start") or "")})
            if path == "/api/reveal":
                it = lib.get(b.get("id"))
                if it and sys.platform == "win32":
                    target = it["tracks"][0]["path"] if not it["folder"] else it["path"]
                    subprocess.Popen(["explorer", "/select,", os.path.normpath(target)])
                return self.send_json({"ok": bool(it)})
            if path == "/api/fenster" and app.server_mode:
                return self.send_json({"ok": False})
            if path == "/api/fenster":
                # Mini-Player: grosses Fenster verkleinern bzw. wieder nach vorne holen
                from . import fenster
                a = str(b.get("aktion") or "")
                if a == "mini_oeffnen":
                    ok = fenster.mini_oeffnen(f"http://127.0.0.1:{self.server.server_address[1]}/mini", os.path.join(store.dir, "edge-profil"))
                    return self.send_json({"ok": ok})
                ok = {"minimieren": fenster.minimieren, "vorne": fenster.nach_vorne, "mini": fenster.mini_platzieren}.get(a, lambda: False)()
                return self.send_json({"ok": ok})
            if path == "/api/opendata":
                if sys.platform == "win32":
                    os.startfile(store.dir)
                return self.send_json({"ok": True})
            return self.not_found()

    return Handler


def pick_folder(title, start):
    """Öffnet den Windows-Ordnerdialog (über tkinter in eigenem Prozess)."""
    fd, out = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    try:
        exe = sys.executable
        if exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
            exe = exe[:-10] + "pythonw.exe"
        r = subprocess.run([exe, "-c", PICK_SCRIPT, out, title, start if os.path.isdir(start or "") else ""],
                           timeout=600, creationflags=NO_WINDOW, capture_output=True)
        if r.returncode != 0:
            log.warning("Ordnerdialog: %s", r.stderr.decode("utf-8", "replace")[-500:])
            return None
        with open(out, "r", encoding="utf-8") as f:
            p = f.read().strip()
        return os.path.normpath(p) if p else ""
    except Exception as e:
        log.warning("Ordnerdialog fehlgeschlagen: %s", e)
        return None
    finally:
        try:
            os.remove(out)
        except OSError:
            pass


def lan_origin(app):
    """Adresse des Heimservers im Heimnetz (für den QR-Code der Jukebox, auch wenn man selbst über Tailscale da ist)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 9))       # es wird nichts gesendet – nur die eigene Adresse Richtung Heimnetz ermitteln
        ip = s.getsockname()[0]
        s.close()
    except OSError:
        return ""
    return "" if ip.startswith("127.") else f"http://{ip}:{getattr(app, 'port', 48219)}"


def allowed_names():
    """Namen, unter denen der Heimserver aufgerufen werden darf (zusätzlich zu IP-Adressen)."""
    names = {"localhost"}
    hn = socket.gethostname().lower()
    if hn:
        names |= {hn, hn + ".local", hn + ".lan", hn + ".home", hn + ".fritz.box", hn + ".home.arpa"}
    for n in (os.environ.get("MYPLAYER_HOSTS") or "").split(","):
        if n.strip():
            names.add(n.strip().lower())
    return names


def start_server(app, port):
    handler = make_handler(app)
    if app.server_mode:
        # Heimserver: fester Port, im ganzen Heimnetz erreichbar
        httpd = ThreadingHTTPServer(("0.0.0.0", port), handler)
        httpd.daemon_threads = True
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        return httpd, port
    for p in [port] + [0]:
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", p), handler)
            break
        except OSError:
            continue
    httpd.daemon_threads = True
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, httpd.server_address[1]
