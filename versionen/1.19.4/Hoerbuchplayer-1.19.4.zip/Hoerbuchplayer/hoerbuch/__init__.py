VERSION = "1.19.4"
APP_NAME = "MyPlayer"
