/* MyPlayer – Oberfläche */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const SPEEDS = [0.7, 1.0, 1.2, 1.5, 1.7, 2.0];
const SKIP = 30;

const S = {
  settings: {}, items: [], byId: {},
  kind: "book", fav: false, arch: false, q: "", view: "library",
  scanning: false, dataDir: "", openShows: new Set(), showPick: {}, sel: new Set(), selAnchor: null,
};

/* ---------------- Hilfsfunktionen ---------------- */
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function icon(id, cls = "") { return `<svg class="${cls}"><use href="#i-${id}"/></svg>`; }
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.round(sec % 3600 / 60);
  if (h && m === 60) return `${h + 1} h`;
  if (h) return m ? `${h} h ${m} min` : `${h} h`;
  if (sec < 60) return `${sec} s`;
  return `${Math.max(1, m)} min`;
}
function fmtSpeed(v) { return (Math.round(v * 10) / 10).toFixed(1).replace(/\.0$/, ".0") + "×"; }
function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }
function pct(it) { if (it.finished) return 100; return it.duration ? Math.min(100, it.pos / it.duration * 100) : 0; }
function coverHTML(it, big = false, phIcon = null) {
  const ic = phIcon || (it && it.kind === "podcast" ? "mic" : "book");
  if (it && it.cover) return `<img loading="lazy" src="/cover/${it.cover}${big ? "?big=1" : ""}" alt="" onerror="this.remove()"><div class="ph" style="z-index:-1">${icon(ic)}</div>`;
  return `<div class="ph">${icon(ic)}</div>`;
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  if (!r.ok) {   // Meldung des Programms zeigen statt nur der Nummer
    let msg = `${path}: ${r.status}`;
    try { const j = await r.json(); if (j && j.error) msg = j.error; } catch (e) { }
    throw new Error(msg);
  }
  return r.json();
}
function toast(msg, action, fn, ms = 4200) {
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `<span>${esc(msg)}</span>${action ? `<button>${esc(action)}</button>` : ""}`;
  if (action) el.querySelector("button").onclick = () => { fn(); el.remove(); };
  $("#toasts").append(el);
  setTimeout(() => el.remove(), ms);
}

/* ---------------- Bibliothek ---------------- */
async function loadLibrary() {
  const d = await api("/api/library");
  S.items = d.items;
  S.byId = Object.fromEntries(d.items.map(i => [i.id, i]));
  if (P.item && S.byId[P.item.id]) {
    const li = S.byId[P.item.id];
    if (P.playing || P.wantPlay) li.pos = P.pos();          // laufender Titel: Position kommt vom Player
    else if (Math.abs(li.pos - P.pos()) > 5) P.seek(li.pos, false);   // anderswo weitergehört (player.menet.ch)
  }
  setScan(d.status);
  renderLibrary();
}

function setScan(st) {
  const was = S.scanning;
  S.scanning = !!st.running;
  $("#scanInfo").hidden = !S.scanning;
  if (S.scanning) $("#scanText").textContent = st.total ? `Lese Bibliothek … ${st.done} / ${st.total}` : "Suche Dateien …";
  if (was && !S.scanning) loadLibrary();
}

function visibleItems() {
  const q = norm(S.q).trim();
  let list = S.items.filter(i => {
    if (S.arch ? !i.archived : i.archived) return false;
    if (S.fav && !i.fav) return false;
    if (S.kind !== "all" && i.kind !== S.kind) return false;
    if (q) {
      const hay = norm([i.title, i.author, i.narrator, i.show, i.genre].join(" "));
      if (!q.split(/\s+/).every(w => hay.includes(w))) return false;
    }
    return true;
  });
  const sort = S.settings.sort || "recent";
  const byTitle = (a, b) => a.title.localeCompare(b.title, "de", { numeric: true, sensitivity: "base" });
  const cmp = {
    recent: (a, b) => (b.updated || 0) - (a.updated || 0) || byTitle(a, b),
    title: byTitle,
    author: (a, b) => (a.author || "~").localeCompare(b.author || "~", "de", { sensitivity: "base" }) || byTitle(a, b),
    added: (a, b) => (b.added || 0) - (a.added || 0),
    duration: (a, b) => (b.duration || 0) - (a.duration || 0),
    progress: (a, b) => pct(b) - pct(a) || byTitle(a, b),
  }[sort] || byTitle;
  return list.sort(cmp);
}

function metaLine(it) {
  if (it.finished) return `<span class="okc">Gehört</span><span>·</span><span>${fmtDur(it.duration)}</span>`;
  if (it.pos > 5) return `<span class="acc">${Math.floor(pct(it))} %</span><span>·</span><span>noch ${fmtDur(it.duration - it.pos)}</span>`;
  return `<span>${fmtDur(it.duration)}</span>`;
}

function cardHTML(it) {
  const p = pct(it);
  const playing = P.item && P.item.id === it.id;
  return `<div class="card${playing ? " playing" : ""}${S.sel.has(it.id) ? " selected" : ""}" tabindex="0" data-id="${it.id}">
    <div class="cv">${coverHTML(it)}${it.cover ? "" : `<div class="ph-t">${esc(it.title)}</div>`}
      <div class="hover"></div>
      <button class="sel-o" data-act="select" title="Auswählen (oder Strg + Klick)">${icon("check")}</button>
      <div class="badges">${playing ? `<span class="bdg now">${P.playing ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("pause")}</span>` : ""}${it.fav ? `<span class="bdg fav">${icon("heart-f")}</span>` : ""}${it.finished ? `<span class="bdg done">${icon("check")}</span>` : ""}${it.on_server ? `<span class="bdg cloud" title="Auf player.menet.ch">${icon("cloud")}</span>` : ""}</div>
      <button class="play-o" data-act="play" title="Abspielen">${icon("play")}</button>
      <button class="more-o" data-act="menu" title="Mehr">${icon("more")}</button>
      ${p > 0 && !it.finished ? `<div class="bar"><i style="width:${p}%"></i></div>` : ""}
    </div>
    <div class="t" title="${esc(it.title)}">${esc(it.title)}</div>
    <div class="a">${esc(it.author || it.show || "")}</div>
    <div class="m">${metaLine(it)}</div>
  </div>`;
}

function rowHTML(it, inShow = false) {
  const p = pct(it);
  const playing = P.item && P.item.id === it.id;
  const sub = inShow ? (it.date ? esc(String(it.date).slice(0, 10)) : "") : esc(it.author || it.show || "");
  const fresh = inShow && !it.finished && it.pos < 5;
  return `<div class="row${playing ? " playing" : ""}${S.sel.has(it.id) ? " selected" : ""}" data-id="${it.id}">
    <div class="rc">${coverHTML(it)}<button class="sel-o" data-act="select" title="Auswählen (oder Strg + Klick)">${icon("check")}</button></div>
    <div class="rt"><b title="${esc(it.title)}">${fresh ? '<i class="ep-new" title="Noch nicht gehört"></i>' : ""}${esc(it.title)}</b><span>${sub}</span></div>
    ${inShow ? "" : `<div class="ra">${esc(it.narrator ? "Gelesen von " + it.narrator : it.kind === "podcast" ? "Podcast" : (it.nchapters > 1 ? it.nchapters + " Kapitel" : ""))}</div>`}
    <div class="rp">${it.finished ? `<span class="okc" style="color:var(--ok);font-weight:600">${icon("check")}</span><span>Gehört</span>` : `<div class="pb"><i style="width:${p}%"></i></div><span>${Math.floor(p)} %</span>`}</div>
    <div class="rd">${fmtDur(it.duration)}</div>
    <div class="rb"><button class="icon-btn${it.fav ? " fav-on" : ""}" data-act="fav" title="Favorit">${icon(it.fav ? "heart-f" : "heart")}</button><button class="icon-btn" data-act="menu" title="Mehr">${icon("more")}</button></div>
  </div>`;
}

function renderLibrary() {
  _renderLibrary();
  if (S.sel.size) { const vis = new Set(domIds()); for (const id of [...S.sel]) if (!vis.has(id)) S.sel.delete(id); }
  refreshSel();
}
function _renderLibrary() {
  const body = $("#libBody"), head = $("#libHead");
  if (S.kind === "music") { renderMusic(body, head); return; }
  const noFolders = !(S.settings.folders || []).length;
  if (noFolders) {
    head.innerHTML = "";
    body.innerHTML = `<div class="empty"><div class="big">${icon("headphones")}</div><h2>Willkommen!</h2>
      <p>Wähle den Ordner, in dem deine Hörbücher liegen (z.&nbsp;B. den Libation-Ordner). Du kannst später weitere Ordner und Podcast-Ordner hinzufügen.</p>
      <button class="btn primary" id="firstFolder">${icon("folder")}Ordner wählen</button></div>`;
    $("#firstFolder").onclick = async () => {
      const p = await pickFolder("Hörbuch-Ordner wählen");
      if (p) { await saveSettings({ folders: [p] }); toast("Bibliothek wird eingelesen …"); }
    };
    return;
  }
  const items = visibleItems();
  const names = { book: "Hörbücher", podcast: "Podcasts", all: "Alle Titel" };
  let title = S.arch ? "Archiv" : S.fav ? "Favoriten" : names[S.kind];
  if (S.arch && S.kind !== "all") title += ` · ${names[S.kind]}`;
  if (S.fav && !S.arch && S.kind !== "all") title += ` · ${names[S.kind]}`;
  const total = items.reduce((a, i) => a + (i.duration || 0), 0);
  head.innerHTML = `<h2>${esc(title)}</h2><span class="sub">${items.length} ${items.length === 1 ? "Titel" : "Titel"}${items.length ? " · " + fmtDur(total) : ""}</span>`;

  if (!items.length) {
    let msg = S.scanning ? "Die Bibliothek wird gerade eingelesen …" : "Hier ist (noch) nichts.";
    if (S.q) msg = `Nichts gefunden für «${esc(S.q)}».`;
    else if (S.arch) msg = "Im Archiv liegt noch nichts. Fertig gehörte Titel kannst du über das Menü (⋯) archivieren.";
    else if (S.fav) msg = "Noch keine Favoriten. Markiere Titel mit dem Herz, um sie dir für später zu merken.";
    else if (S.kind === "podcast") msg = "Keine Podcasts gefunden. In den Einstellungen kannst du Ordner als Podcast-Ordner markieren.";
    body.innerHTML = `<div class="empty"><div class="big">${icon(S.arch ? "archive" : S.fav ? "heart" : "search")}</div><p>${msg}</p></div>`;
    return;
  }

  if (S.kind === "podcast" && !S.q) {
    // nach Sendung gruppieren
    const groups = new Map();
    for (const it of items) {
      const k = it.show || "Ohne Sendung";
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(it);
    }
    // Neueste zuerst: Datum, dann Folgennummer im Titel (Episode 329 vor 328), dann Dateidatum
    const epSort = (a, b) => String(b.date || "").localeCompare(String(a.date || "")) ||
      b.title.localeCompare(a.title, "de", { numeric: true, sensitivity: "base" }) || (b.added - a.added);
    let html = "";
    const keys = [...groups.keys()].sort((a, b) => {
      const ra = Math.max(...groups.get(a).map(i => i.updated || 0)), rb = Math.max(...groups.get(b).map(i => i.updated || 0));
      return rb - ra || a.localeCompare(b, "de");
    });
    S.showPick = {};
    for (const k of keys) {
      const eps = groups.get(k).sort(epSort);
      const coverIt = eps.find(e => e.cover) || eps[0];
      const started = eps.filter(e => !e.finished && e.pos > 5);
      const fresh = eps.filter(e => !e.finished && e.pos <= 5).length;
      const last = [...eps].filter(e => e.updated).sort((a, b) => b.updated - a.updated)[0];
      // "Weiterhören": zuletzt angefangene Folge, sonst neueste ungehörte
      const pick = started.sort((a, b) => (b.updated || 0) - (a.updated || 0))[0] || eps.find(e => !e.finished) || eps[0];
      S.showPick[k] = pick.id;
      const isOpen = S.openShows.has(k);
      const playingHere = P.item && eps.some(e => e.id === P.item.id);
      const parts = [`${eps.length} ${eps.length === 1 ? "Folge" : "Folgen"}`];
      if (fresh) parts.push(`${fresh} ungehört`);
      if (started.length) parts.push(`${started.length} angefangen`);
      if (!fresh && !started.length) parts.push("alle gehört");
      const kk = esc(k);
      html += `<section class="show${isOpen ? " open" : ""}${playingHere ? " playing" : ""}">
        <div class="show-h" data-show="${kk}" title="${isOpen ? "Zuklappen" : "Aufklappen"}">
          <div class="sc">${coverHTML(coverIt, false, "mic")}</div>
          <div class="show-t"><h3>${kk}</h3><div class="sub">${parts.join(" · ")}</div>
            ${last ? `<div class="last">Zuletzt: ${esc(last.title)}</div>` : ""}</div>
          <button class="pill show-play" data-showplay="${kk}" title="${esc(pick.title)}">${icon("play")}${started.length ? "Weiterhören" : "Neueste Folge"}</button>
          <span class="chev">${icon("chev-up")}</span>
        </div>
        ${isOpen ? `<div class="list">${eps.map(e => rowHTML(e, true)).join("")}</div>` : ""}</section>`;
    }
    body.innerHTML = html;
  } else if ((S.settings.view || "grid") === "list") {
    body.innerHTML = `<div class="list-head"><span></span><span>Titel</span><span class="ra">Info</span><span>Fortschritt</span><span class="r rd">Dauer</span><span></span></div>
      <div class="list">${items.map(i => rowHTML(i)).join("")}</div>`;
  } else {
    body.innerHTML = `<div class="grid">${items.map(cardHTML).join("")}</div>`;
  }
}

function libClick(e) {
  const sp = e.target.closest("[data-showplay]");
  if (sp) { e.stopPropagation(); const id = S.showPick[sp.dataset.showplay]; if (id) openItem(id, true); return; }
  const sh = e.target.closest("[data-show]");
  if (sh) {
    const k = sh.dataset.show;
    if (S.openShows.has(k)) S.openShows.delete(k); else S.openShows.add(k);
    renderLibrary(); return;
  }
  const el = e.target.closest("[data-id]");
  if (!el) return;
  const id = el.dataset.id;
  const act = e.target.closest("[data-act]")?.dataset.act;
  if (act === "menu") { e.stopPropagation(); return itemMenu(id, e.target.closest("[data-act]")); }
  if (act === "fav") { e.stopPropagation(); return setFlags(id, { fav: !S.byId[id].fav }); }
  // Auswahl: Häkchen, Strg+Klick, Umschalt+Klick – oder normaler Klick, sobald schon etwas ausgewählt ist
  if (e.shiftKey && S.selAnchor) { e.preventDefault(); return selectRange(id); }
  if (act === "select" || e.ctrlKey || e.metaKey || (S.sel.size && act !== "play")) return toggleSel(id);
  openItem(id, true);
}

/* ---------------- Mehrfachauswahl ---------------- */
function domIds() { return $$("#libBody [data-id]").map(el => el.dataset.id); }
function toggleSel(id) {
  if (S.sel.has(id)) S.sel.delete(id); else S.sel.add(id);
  S.selAnchor = id;
  refreshSel();
}
function selectRange(id) {
  const ids = domIds(), a = ids.indexOf(S.selAnchor), b = ids.indexOf(id);
  if (a < 0 || b < 0) return toggleSel(id);
  for (const x of ids.slice(Math.min(a, b), Math.max(a, b) + 1)) S.sel.add(x);
  refreshSel();
}
function clearSel() { S.sel.clear(); S.selAnchor = null; refreshSel(); }
function refreshSel() {
  $$("#libBody [data-id]").forEach(el => el.classList.toggle("selected", S.sel.has(el.dataset.id)));
  const n = S.sel.size, bar = $("#selBar");
  document.body.classList.toggle("has-sel", n > 0);
  $("#libBody").classList.toggle("selecting", n > 0);
  if (!n) { bar.hidden = true; return; }
  bar.hidden = false;
  $("#selCount").textContent = `${n} ausgewählt`;
}
function selMenuEntries() {
  const ids = [...S.sel];
  const allFav = ids.every(i => S.byId[i]?.fav), allArch = ids.every(i => S.byId[i]?.archived);
  return [
    { label: `${ids.length} Titel ausgewählt` },
    { icon: "mic", text: "Als Podcast markieren", fn: () => bulk({ kind: "podcast" }) },
    { icon: "book", text: "Als Hörbuch markieren", fn: () => bulk({ kind: "book" }) },
    { icon: "refresh", text: "Art automatisch bestimmen", fn: () => bulk({ kind: "auto" }) },
    "-",
    { icon: allFav ? "heart-f" : "heart", text: allFav ? "Aus Favoriten entfernen" : "Zu Favoriten", fn: () => bulk({ fav: !allFav }) },
    { icon: "archive", text: allArch ? "Aus dem Archiv holen" : "Ins Archiv verschieben", fn: () => bulk({ archived: !allArch }) },
    { icon: "check", text: "Als gehört markieren", fn: () => bulk({ finished: true }) },
    ...(S.cloud && S.cloud.connected && S.cloud.admin ? [{ icon: "cloud-up", text: "Auf player.menet.ch hochladen", fn: () => { const ids = [...S.sel]; clearSel(); cloudUpload(ids); } }] : []),
    "-",
    { icon: "x", text: "Auswahl aufheben", fn: clearSel },
  ];
}
async function bulk(flags) {
  const ids = [...S.sel];
  if (!ids.length) return;
  const prev = ids.map(i => ({ id: i, kind: S.byId[i]?.kind, manual: S.byId[i]?.kind_manual }));
  const d = await api("/api/flags", { ids, ...flags });
  for (const u of d.items) { if (S.byId[u.id]) Object.assign(S.byId[u.id], u); if (P.item && P.item.id === u.id) { Object.assign(P.item, u); renderPlayerMeta(); } }
  const n = d.items.length;
  const what = "kind" in flags ? (flags.kind === "podcast" ? "gelten jetzt als Podcast" : flags.kind === "book" ? "gelten jetzt als Hörbuch" : "werden wieder automatisch eingeordnet")
    : "fav" in flags ? (flags.fav ? "sind jetzt Favoriten" : "sind keine Favoriten mehr")
    : "archived" in flags ? (flags.archived ? "sind jetzt im Archiv" : "sind wieder in der Bibliothek")
    : "sind als gehört markiert";
  clearSel();
  renderLibrary();
  if ("archived" in flags || "kind" in flags) toast(`${n} Titel ${what}.`, "Rückgängig", async () => {
    const back = "archived" in flags ? { archived: !flags.archived } : null;
    if (back) { await api("/api/flags", { ids, ...back }); }
    else { // Art einzeln zurücksetzen auf vorherigen Zustand
      for (const it of prev) await api("/api/flags", { id: it.id, kind: it.manual ? it.kind : "auto" });
    }
    await loadLibrary();
  }, 7000);
  else toast(`${n} Titel ${what}.`);
}

/* ---------------- Touch: lange drücken = auswählen ---------------- */
// Auf dem Handy öffnet ein Antippen das Buch; ca. eine halbe Sekunde gedrückt halten startet die Auswahl (wie beim iPhone üblich).
const LONGPRESS_MS = 550;
let lp = null, lpFired = false;
function bindLongPress() {
  const body = $("#libBody");
  body.addEventListener("pointerdown", e => {
    if (e.pointerType === "mouse") return;
    const el = e.target.closest("[data-id]");
    if (!el || e.target.closest("[data-act=menu],[data-act=fav],[data-showplay]")) return;
    lpFired = false;
    lp = { x: e.clientX, y: e.clientY, t: setTimeout(() => {
      lpFired = true; lp = null;
      if (!S.sel.has(el.dataset.id)) toggleSel(el.dataset.id);
      try { navigator.vibrate && navigator.vibrate(15); } catch (err) { }
      if (S.sel.size === 1) toast("Auswahl: weitere Titel antippen. Fertig mit ✕ unten.", null, null, 3500);
    }, LONGPRESS_MS) };
  });
  const cancel = () => { if (lp) { clearTimeout(lp.t); lp = null; } };
  body.addEventListener("pointermove", e => { if (lp && Math.hypot(e.clientX - lp.x, e.clientY - lp.y) > 10) cancel(); });
  body.addEventListener("pointerup", cancel);
  body.addEventListener("pointercancel", cancel);
  // der Klick nach dem langen Drücken soll nicht gleich wieder abwählen oder das Buch öffnen
  body.addEventListener("click", e => { if (lpFired) { lpFired = false; e.stopPropagation(); e.preventDefault(); } }, true);
}

/* ---------------- Kontextmenü ---------------- */
function showMenu(entries, x, y) {
  const m = $("#menu");
  m.innerHTML = entries.map((en, i) => en === "-" ? "<hr>" : en.label && !en.fn ? `<div class="lbl">${esc(en.label)}</div>` :
    `<button data-i="${i}">${en.icon ? icon(en.icon) : '<svg></svg>'}<span>${esc(en.text)}</span>${en.checked ? icon("check", "chk") : ""}</button>`).join("");
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + "px";
  m.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
  m.onclick = ev => { const b = ev.target.closest("button"); if (!b) return; hideMenu(); entries[+b.dataset.i].fn(); };
}
function hideMenu() { $("#menu").hidden = true; }

function itemMenu(id, anchor, at) {
  const it = S.byId[id];
  if (!it) return;
  let x, y;
  if (at) { x = at.x; y = at.y; } else { const r = anchor.getBoundingClientRect(); x = r.left; y = r.bottom + 4; }
  const kindName = it.auto_kind === "book" ? "Hörbuch" : "Podcast";
  showMenu([
    { icon: "play", text: P.item && P.item.id === id ? (P.playing ? "Pause" : "Weiterhören") : (it.pos > 5 && !it.finished ? "Weiterhören" : "Abspielen"), fn: () => P.item && P.item.id === id ? togglePlay() : openItem(id, true) },
    { icon: "chapters", text: "Kapitel anzeigen", fn: () => openItem(id, false) },
    "-",
    { icon: it.fav ? "heart-f" : "heart", text: it.fav ? "Aus Favoriten entfernen" : "Zu Favoriten", fn: () => setFlags(id, { fav: !it.fav }) },
    { icon: "archive", text: it.archived ? "Aus dem Archiv holen" : "Ins Archiv verschieben", fn: () => setFlags(id, { archived: !it.archived }) },
    { icon: "check", text: it.finished ? "Als ungehört markieren (von vorne)" : "Als gehört markieren", fn: () => setFlags(id, { finished: !it.finished }) },
    "-",
    { label: "Art des Titels" },
    { icon: "book", text: "Hörbuch", checked: it.kind === "book" && it.kind_manual, fn: () => setFlags(id, { kind: "book" }) },
    { icon: "mic", text: "Podcast", checked: it.kind === "podcast" && it.kind_manual, fn: () => setFlags(id, { kind: "podcast" }) },
    { icon: "refresh", text: `Automatisch (${kindName}: ${it.kind_reason})`, checked: !it.kind_manual, fn: () => setFlags(id, { kind: "auto" }) },
    "-",
    { icon: "explorer", text: "Im Explorer zeigen", fn: () => api("/api/reveal", { id }) },
    ...(S.cloud && S.cloud.connected && S.cloud.admin ? ["-", it.on_server
      ? { icon: "cloud", text: "Vom Server entfernen …", fn: () => cloudDelete(id) }
      : { icon: "cloud-up", text: "Auf player.menet.ch hochladen", fn: () => cloudUpload([id]) }] : []),
  ], x, y);
}

async function setFlags(id, flags) {
  const it = S.byId[id];
  const upd = await api("/api/flags", { id, ...flags });
  Object.assign(it, upd);
  if (P.item && P.item.id === id) {
    Object.assign(P.item, upd);
    if ("finished" in flags) { P.seek(flags.finished ? P.total : 0, false); }
    renderPlayerMeta();
  }
  if ("archived" in flags) toast(flags.archived ? `«${it.title}» ist jetzt im Archiv.` : `«${it.title}» ist wieder in der Bibliothek.`, "Rückgängig", () => setFlags(id, { archived: !flags.archived }));
  if ("kind" in flags) toast(`«${it.title}» gilt jetzt als ${upd.kind === "book" ? "Hörbuch" : "Podcast"}.`);
  renderLibrary();
}

/* ---------------- Player-Kern ---------------- */
const audio = new Audio();
audio.preload = "auto";

const P = {
  item: null, tracks: [], chapters: [], total: 0, trackIdx: 0, pendingSeek: null,
  playing: false, wantPlay: false, lastSave: 0, loadingId: null,
  pos() {
    if (!this.item) return 0;
    const t = this.tracks[this.trackIdx];
    const local = this.pendingSeek != null ? this.pendingSeek : audio.currentTime || 0;
    return (t ? t.offset : 0) + local;
  },
  layout() { // Versätze der Dateien neu berechnen
    let off = 0;
    for (const t of this.tracks) { t.offset = off; off += t.duration; }
    this.total = off || this.item.duration;
    if (this.item.folder) this.chapters.forEach((c, i) => { c.start = this.tracks[i] ? this.tracks[i].offset : c.start; });
    this.chapters.forEach((c, i) => { c.end = i + 1 < this.chapters.length ? this.chapters[i + 1].start : this.total; });
  },
  chapterIdx(t = this.pos()) {
    let i = 0;
    for (let k = 0; k < this.chapters.length; k++) if (this.chapters[k].start <= t + 0.25) i = k;
    return i;
  },
  loadTrack(i, at, play) {
    this.trackIdx = i;
    this.pendingSeek = at;
    this.wantPlay = play;
    audio.src = `/media/${this.item.id}/${i}`;
    audio.load();
  },
  seek(t, play = this.playing || this.wantPlay) {
    if (!this.item) return;
    t = Math.max(0, Math.min(t, this.total - 0.5));
    let i = this.tracks.length - 1;
    for (let k = 0; k < this.tracks.length; k++) if (t < this.tracks[k].offset + this.tracks[k].duration) { i = k; break; }
    const local = t - this.tracks[i].offset;
    if (i !== this.trackIdx || !audio.src) this.loadTrack(i, local, play);
    else if (this.pendingSeek != null) this.pendingSeek = local;
    else audio.currentTime = local;
    updateUI(true);
    saveSoon();
  },
};

audio.addEventListener("loadedmetadata", () => {
  const t = P.tracks[P.trackIdx];
  if (t && isFinite(audio.duration) && audio.duration > 0 && Math.abs(audio.duration - t.duration) > 1) {
    t.duration = audio.duration; P.layout(); renderChapters(); renderTicks();
  }
  if (P.pendingSeek != null) { try { audio.currentTime = P.pendingSeek; } catch (e) { } }
  P.pendingSeek = null;
  applySpeed();
  if (P.wantPlay) audio.play().catch(err => { console.warn(err); P.wantPlay = false; updatePlayState(); });
});
audio.addEventListener("play", () => { P.playing = true; P.wantPlay = true; updatePlayState(); });
audio.addEventListener("pause", () => { P.playing = false; if (!audio.ended) P.wantPlay = false; updatePlayState(); saveProgress(); });
audio.addEventListener("timeupdate", () => { updateUI(); checkSleep(); if (P.playing && Date.now() - P.lastSave > 5000) saveProgress(); });
audio.addEventListener("ended", () => {
  if (P.trackIdx + 1 < P.tracks.length) { P.loadTrack(P.trackIdx + 1, 0, true); return; }
  P.playing = false; P.wantPlay = false;
  saveProgress(true, P.total);
  updatePlayState();
  const it = S.byId[P.item.id];
  if (it) { it.finished = true; it.pos = it.duration; renderLibrary(); }
  if (S.sleep && S.sleep.mode === "chapter") clearSleep();
  toast(`«${P.item.title}» fertig gehört.`, "Ins Archiv", () => setFlags(P.item.id, { archived: true }), 9000);
});
audio.addEventListener("error", () => {
  if (!audio.src || !P.item) return;
  const code = audio.error ? audio.error.code : 0;
  const why = code === 4 ? "Dieses Format kann nicht abgespielt werden." : "Die Datei konnte nicht geladen werden.";
  toast(`Fehler: ${why}`, null, null, 7000);
  P.playing = false; P.wantPlay = false; updatePlayState();
});

function applySpeed() { const s = S.settings.speed || 1; audio.defaultPlaybackRate = s; audio.playbackRate = s; }

async function saveProgress(flush = false, posOverride) {
  if (!P.item) return;
  P.lastSave = Date.now();
  const pos = posOverride ?? P.pos();
  const li = S.byId[P.item.id];
  if (li) { li.pos = pos; li.updated = Date.now() / 1000; if (pos < li.duration - 20 && li.finished && P.playing) li.finished = false; }
  try { await api("/api/progress", { id: P.item.id, pos, duration: P.total, flush }); } catch (e) { console.warn(e); }
}
const saveSoon = debounce(() => saveProgress(), 900);

async function openItem(id, play) {
  if (P.item && P.item.id === id) {
    if (play && !P.playing) togglePlay();
    showView("player");
    return;
  }
  if (P.item) { audio.pause(); await saveProgress(true); }
  P.loadingId = id;
  const it = await api("/api/item?id=" + encodeURIComponent(id));
  if (P.loadingId !== id) return;
  P.item = it;
  P.tracks = it.tracks.map(t => ({ duration: t.duration, offset: 0 }));
  P.chapters = it.chapters.map(c => ({ title: c.title, start: c.start }));
  P.layout();
  P.trackIdx = -1;
  let start = it.finished ? 0 : (it.pos || 0);
  if (start >= P.total - 3) start = 0;
  if (it.finished && play) { // neu anfangen
    setFlags(id, { finished: false }).catch(() => { });
  }
  renderPlayer();
  P.seek(start, play);
  showView(play || S.view === "player" ? "player" : "player");
  S.settings.last_item = id;
  renderLibrary();
}

function togglePlay() {
  if (!P.item) return;
  if (audio.paused) {
    if (P.trackIdx < 0 || !audio.src) { P.seek(P.pos(), true); return; }
    if (P.pos() >= P.total - 1) P.seek(0, true);
    P.wantPlay = true;
    audio.play().catch(e => console.warn(e));
  } else audio.pause();
}
function skip(d) { if (P.item) P.seek(P.pos() + d); }
function prevChapter() {
  if (!P.item) return;
  const t = P.pos(), i = P.chapterIdx(t);
  const ch = P.chapters[i];
  if (t - ch.start > 3 * (S.settings.speed || 1) || i === 0) P.seek(ch.start);
  else P.seek(P.chapters[i - 1].start);
}
function nextChapter() {
  if (!P.item) return;
  const i = P.chapterIdx();
  if (i + 1 < P.chapters.length) P.seek(P.chapters[i + 1].start);
}

/* ---------------- Player-Ansicht ---------------- */
function showView(v) {
  S.view = v;
  $("#libView").hidden = v !== "library";
  $("#playerView").hidden = v !== "player";
  $("#mini").hidden = !(v === "library" && P.item);
  if (v === "player") scrollToCurrentChapter(true);
}

function renderPlayer() {
  const it = P.item;
  $("#plCover").innerHTML = coverHTML(it, true);
  $("#plBg").style.backgroundImage = it.cover ? `url(/cover/${it.cover})` : "none";
  $("#miniCover").innerHTML = coverHTML(it);
  $("#miniTitle").textContent = it.title;
  renderPlayerMeta();
  renderChapters();
  renderBookmarks();
  renderTicks();
  updateMediaSession();
  updateUI(true);
}
function renderPlayerMeta() {
  const it = P.item;
  $("#plKind").textContent = it.kind === "podcast" ? (it.show ? "Podcast · " + it.show : "Podcast") : "Hörbuch";
  $("#plTitle").textContent = it.title;
  const by = [it.author, it.narrator ? "gelesen von " + it.narrator : ""].filter(Boolean).join(" · ");
  $("#plAuthor").textContent = by;
  $("#plFav").classList.toggle("on", !!it.fav);
  $("#plFav").innerHTML = icon(it.fav ? "heart-f" : "heart");
}
function renderChapters() {
  const ol = $("#chapterList");
  $("#chCount").textContent = P.chapters.length;
  ol.innerHTML = P.chapters.map((c, i) => `<li data-i="${i}"><span class="n">${i + 1}</span><span class="ct" title="${esc(c.title)}">${esc(c.title)}</span><span class="cd">${fmtClock(c.end - c.start)}</span><span class="cp" style="width:0"></span></li>`).join("");
  P._lastCh = -1;
}
function renderTicks() {
  const el = $("#ticks");
  if (!P.item || P.chapters.length < 2 || P.chapters.length > 150) { el.innerHTML = ""; return; }
  el.innerHTML = P.chapters.slice(1).map(c => `<i style="left:calc(7px + (100% - 14px) * ${c.start / P.total})"></i>`).join("");
}
function renderBookmarks() {
  const bms = P.item.bookmarks || [];
  $("#bmCount").textContent = bms.length || "";
  const ul = $("#bookmarkList");
  if (!bms.length) { ul.innerHTML = `<li class="side-empty" style="display:block;cursor:default">Noch keine Lesezeichen.<br>Mit <kbd>B</kbd> oder dem Knopf oben setzt du eins an der aktuellen Stelle.</li>`; return; }
  ul.innerHTML = bms.map(b => {
    const ch = P.chapters[P.chapterIdx(b.pos)];
    return `<li data-bid="${b.id}" data-pos="${b.pos}"><span class="bt">${fmtClock(b.pos)}</span><span class="bx"><button class="icon-btn sm" data-bact="edit" title="Notiz bearbeiten">${icon("edit")}</button><button class="icon-btn sm" data-bact="del" title="Löschen">${icon("trash")}</button></span>
      <span class="bc">${esc(ch ? ch.title : "")}</span>${b.note ? `<span class="bn">${esc(b.note)}</span>` : ""}</li>`;
  }).join("");
}
function scrollToCurrentChapter(center) {
  const li = $(`#chapterList li[data-i="${P.chapterIdx()}"]`);
  if (li) li.scrollIntoView({ block: center ? "center" : "nearest" });
}

let dragging = null;
function setSlider(el, frac) { el.value = Math.round(frac * 1000); el.style.setProperty("--p", (frac * 100).toFixed(2) + "%"); }

function updateUI(force) {
  if (!P.item) return;
  const t = P.pos(), sp = S.settings.speed || 1;
  const ci = P.chapterIdx(t), ch = P.chapters[ci] || { start: 0, end: P.total, title: "" };
  const cl = Math.max(0.001, ch.end - ch.start), ce = Math.max(0, t - ch.start);
  if (dragging !== "ch") setSlider($("#chSlider"), ce / cl);
  if (dragging !== "tot") setSlider($("#totSlider"), t / P.total);
  $("#chElapsed").textContent = fmtClock(ce);
  $("#chRemain").textContent = "-" + fmtClock((cl - ce) / sp);
  $("#chInfo").textContent = P.chapters.length > 1 ? `Kapitel ${ci + 1} von ${P.chapters.length}` : "";
  $("#totElapsed").textContent = fmtClock(t);
  $("#totRemain").textContent = fmtClock(P.total);
  const left = (P.total - t) / sp;
  $("#totInfo").textContent = `${Math.floor(t / P.total * 100)} % · noch ${fmtDur(left)}${sp !== 1 ? ` bei ${fmtSpeed(sp)}` : ""}`;
  $("#plChapter").innerHTML = P.chapters.length > 1 || ch.title !== P.item.title ? `<span class="eq${P.playing ? "" : " paused"}"><i></i><i></i><i></i></span><span>${esc(ch.title)}</span>` : "";
  // Mini-Player
  $("#miniSub").textContent = (P.chapters.length > 1 ? ch.title + " · " : "") + (P.item.author || P.item.show || "");
  $("#miniProg").style.width = (t / P.total * 100) + "%";
  $("#miniTime").textContent = `${fmtClock(t)} / ${fmtClock(P.total)}`;
  $("#miniSpeed").textContent = fmtSpeed(sp);
  // Kapitelliste
  if (ci !== P._lastCh || force) {
    $$("#chapterList li").forEach((li, i) => { li.classList.toggle("cur", i === ci); li.classList.toggle("done", i < ci); if (i !== ci) li.querySelector(".cp").style.width = "0"; });
    if (P._lastCh !== -1 && ci !== P._lastCh && S.view === "player") scrollToCurrentChapter(false);
    P._lastCh = ci;
    updateMediaSession();
  }
  const cur = $(`#chapterList li[data-i="${ci}"] .cp`);
  if (cur) cur.style.width = (ce / cl * 100) + "%";
  if ("mediaSession" in navigator && navigator.mediaSession.setPositionState && P.total > 0) {
    try { navigator.mediaSession.setPositionState({ duration: P.total, position: Math.min(t, P.total), playbackRate: sp }); } catch (e) { }
  }
}

function updatePlayState() {
  const playing = P.playing || (P.wantPlay && audio.paused && P.pendingSeek != null);
  for (const b of [$("#playBtn"), $("#mPlay")]) b.innerHTML = icon(playing ? "pause" : "play");
  $$(".pl-chapter .eq").forEach(e => e.classList.toggle("paused", !P.playing));
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = P.playing ? "playing" : "paused";
  // Kachel mit Wiedergabe-Symbol aktualisieren
  if (S.view === "library") updateCardBadge();
}
function updateCardBadge() { // nur das Symbol der laufenden Kachel erneuern (kein Flackern)
  if (!P.item) return;
  const card = $(`.card[data-id="${P.item.id}"]`);
  if (!card) return;
  const it = S.byId[P.item.id] || P.item;
  card.querySelector(".badges").innerHTML = `<span class="bdg now">${P.playing ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("pause")}</span>${it.fav ? `<span class="bdg fav">${icon("heart-f")}</span>` : ""}${it.on_server ? `<span class="bdg cloud" title="Auf player.menet.ch">${icon("cloud")}</span>` : ""}`;
}

function renderSpeed() {
  const cur = S.settings.speed || 1;
  $("#speedSeg").innerHTML = SPEEDS.map(s => `<button data-s="${s}" class="${Math.abs(s - cur) < 0.01 ? "on" : ""}">${s.toFixed(1)}</button>`).join("");
}
function setSpeed(s) {
  S.settings.speed = s; applySpeed(); renderSpeed(); updateUI(true);
  saveSettingsSoon({ speed: s });
}
function setVolume(v) {
  v = Math.max(0, Math.min(1, v));
  S.settings.volume = v; audio.volume = v; audio.muted = false;
  $("#volSlider").value = Math.round(v * 100);
  $("#volSlider").style.setProperty("--p", v * 100 + "%");
  $("#muteBtn").innerHTML = icon(v === 0 ? "mute" : "vol");
  saveSettingsSoon({ volume: v });
}

/* ---------------- Lesezeichen ---------------- */
async function addBookmark() {
  if (!P.item) return;
  const pos = P.pos();
  const note = await askText("Lesezeichen setzen", `Bei ${fmtClock(pos)} – ${P.chapters[P.chapterIdx(pos)]?.title || ""}`, "Notiz (optional)", "");
  if (note === null) return;
  const d = await api("/api/bookmark", { id: P.item.id, action: "add", pos, note });
  P.item.bookmarks = d.bookmarks; renderBookmarks();
  const li = S.byId[P.item.id]; if (li) li.nbookmarks = d.bookmarks.length;
  toast("Lesezeichen gesetzt.", "Anzeigen", () => sideTab("bookmarks"));
}
async function bookmarkAction(e) {
  const li = e.target.closest("li[data-bid]");
  if (!li) return;
  const bid = li.dataset.bid, act = e.target.closest("[data-bact]")?.dataset.bact;
  if (act === "del") {
    const d = await api("/api/bookmark", { id: P.item.id, action: "delete", bid });
    P.item.bookmarks = d.bookmarks; renderBookmarks(); return;
  }
  if (act === "edit") {
    const b = P.item.bookmarks.find(x => x.id === bid);
    const note = await askText("Notiz bearbeiten", fmtClock(b.pos), "Notiz", b.note || "");
    if (note === null) return;
    const d = await api("/api/bookmark", { id: P.item.id, action: "edit", bid, note });
    P.item.bookmarks = d.bookmarks; renderBookmarks(); return;
  }
  P.seek(+li.dataset.pos, true);
  if (!P.playing) togglePlay();
}
function sideTab(t) {
  $$(".side-tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  $("#chapterList").hidden = t !== "chapters";
  $("#bookmarkPane").hidden = t !== "bookmarks";
}

/* ---------------- Schlaf-Timer ---------------- */
S.sleep = null;
function sleepDialog() {
  const opts = [5, 10, 15, 20, 30, 45, 60, 90];
  openModal(`<h2>Schlaf-Timer</h2><p class="hint">Die Wiedergabe wird nach der gewählten Zeit sanft leiser und hält dann an.</p>
    <div class="sleep-opts">${opts.map(m => `<button class="btn" data-m="${m}">${m} min</button>`).join("")}</div>
    <div class="sleep-opts" style="grid-template-columns:1fr 1fr"><button class="btn" data-m="chapter">Am Ende des Kapitels</button><button class="btn" data-m="off" ${S.sleep ? "" : "disabled"}>Timer aus</button></div>
    <div class="foot"><button class="btn" data-close>Schliessen</button></div>`);
  $("#modal").onclick = e => {
    const b = e.target.closest("[data-m]");
    if (b) {
      const m = b.dataset.m;
      if (m === "off") clearSleep();
      else if (m === "chapter") S.sleep = { mode: "chapter", ch: P.chapterIdx() };
      else S.sleep = { mode: "time", end: Date.now() + m * 60000 };
      if (m !== "off") toast(m === "chapter" ? "Schlaf-Timer: hält am Ende des Kapitels an." : `Schlaf-Timer: ${m} Minuten.`);
      closeModal(); updateSleepText();
    }
    if (e.target.closest("[data-close]")) closeModal();
  };
}
function clearSleep() { S.sleep = null; audio.volume = S.settings.volume ?? 1; updateSleepText(); }
function updateSleepText() {
  const b = $("#sleepBtn");
  b.classList.toggle("on", !!S.sleep);
  if (!S.sleep) $("#sleepText").textContent = "Schlaf-Timer";
  else if (S.sleep.mode === "chapter") $("#sleepText").textContent = "Kapitelende";
  else $("#sleepText").textContent = fmtClock(Math.max(0, (S.sleep.end - Date.now()) / 1000));
}
function checkSleep() {
  if (!S.sleep || !P.playing) return;
  if (S.sleep.mode === "chapter") {
    const ci = P.chapterIdx();
    if (ci !== S.sleep.ch) {
      audio.pause(); P.seek(P.chapters[ci].start, false); clearSleep(); toast("Schlaf-Timer: angehalten. Gute Nacht!");
    }
    return;
  }
  const left = (S.sleep.end - Date.now()) / 1000;
  const vol = S.settings.volume ?? 1;
  if (left <= 0) { audio.pause(); clearSleep(); P.seek(P.pos() - 10, false); toast("Schlaf-Timer: angehalten. Gute Nacht!"); }
  else if (left < 15) audio.volume = vol * (left / 15);
}
setInterval(() => { if (S.sleep && S.sleep.mode === "time") { updateSleepText(); if (!P.playing && S.sleep.end < Date.now()) clearSleep(); } }, 1000);

/* ---------------- Dialoge ---------------- */
let modalResolve = null;
function openModal(html) { $("#modal").innerHTML = html; $("#modalWrap").hidden = false; }
function closeModal(val = null) { $("#modalWrap").hidden = true; $("#modal").onclick = null; if (modalResolve) { const r = modalResolve; modalResolve = null; r(val); } }
function askText(title, hint, label, val) {
  return new Promise(res => {
    openModal(`<h2>${esc(title)}</h2><p class="hint">${esc(hint)}</p><textarea id="askIn" placeholder="${esc(label)}">${esc(val)}</textarea>
      <div class="foot"><button class="btn" data-x>Abbrechen</button><button class="btn primary" data-ok>Speichern</button></div>`);
    modalResolve = res;
    const ta = $("#askIn"); ta.focus(); ta.select();
    ta.onkeydown = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); closeModal(ta.value.trim()); } };
    $("#modal").onclick = e => { if (e.target.closest("[data-ok]")) closeModal(ta.value.trim()); if (e.target.closest("[data-x]")) closeModal(null); };
  });
}

async function pickFolder(title, start = "") {
  toast("Ordner-Auswahl wird geöffnet … (ggf. hinter diesem Fenster)", null, null, 3000);
  try {
    const d = await api("/api/pickfolder", { title, start });
    if (d.path === null) { toast("Der Ordner-Dialog liess sich nicht öffnen – bitte Pfad von Hand einfügen."); return ""; }
    return d.path || "";
  } catch (e) { return ""; }
}

async function saveSettings(patch) {
  const d = await api("/api/settings", patch);
  S.settings = d.settings;
  renderLibrary();
  return d;
}
const _pendingSettings = {};
const _flushSettings = debounce(() => { const p = { ...(_pendingSettings) }; for (const k in _pendingSettings) delete _pendingSettings[k]; api("/api/settings", p).catch(() => { }); }, 700);
function saveSettingsSoon(patch) { Object.assign(_pendingSettings, patch); _flushSettings(); }

function settingsDialog() {
  const st = { folders: [...(S.settings.folders || [])], podcast_folders: [...(S.settings.podcast_folders || [])], recursive: S.settings.recursive !== false };
  const list = key => st[key].length ? st[key].map((f, i) => `<li>${icon("folder")}<span title="${esc(f)}">${esc(f)}</span><button class="icon-btn sm" data-del="${key}:${i}" title="Entfernen">${icon("x")}</button></li>`).join("") : `<li class="none">Noch kein Ordner</li>`;
  const draw = () => {
    openModal(`<h2>Einstellungen</h2>
      <h3>Bibliotheksordner</h3><p class="hint">Hier sucht das Programm nach Hörbüchern und Podcasts (M4B, MP3, M4A …).</p>
      <ul class="folders">${list("folders")}</ul>
      <div class="add-row"><input id="pathIn" type="text" placeholder="Pfad einfügen, z. B. D:\\Hörbücher"><button class="btn" data-add="folders">${icon("plus")}Hinzufügen</button><button class="btn" data-pick="folders">${icon("folder")}Durchsuchen …</button></div>
      <label class="switch"><input type="checkbox" id="recIn" ${st.recursive ? "checked" : ""}><span class="tr"></span><span>Unterordner einbeziehen</span></label>
      <h3>Podcast-Ordner</h3><p class="hint">Alles in diesen Ordnern gilt als Podcast – jede Datei ist eine Folge, Unterordner sind Sendungen. (Sonst entscheidet das Programm selbst: Genre «Podcast» → Podcast; M4B, Kapitelmarken oder Ordner mit mehreren Dateien eines Buchs → Hörbuch. Pro Titel kannst du es über ⋯ ändern.)</p>
      <ul class="folders">${list("podcast_folders")}</ul>
      <div class="add-row"><input id="pathIn2" type="text" placeholder="Pfad einfügen"><button class="btn" data-add="podcast_folders">${icon("plus")}Hinzufügen</button><button class="btn" data-pick="podcast_folders">${icon("folder")}Durchsuchen …</button></div>
      <div id="cloudSec">${cloudSection()}</div>
      <div id="musicSec">${musicSettingsHTML()}</div>
      <h3>Tastenkürzel</h3>
      <div class="keys">
      <span><kbd>Leertaste</kbd></span><span>Abspielen / Pause</span>
      <span><kbd>←</kbd><kbd>→</kbd></span><span>30 Sekunden zurück / vor</span>
      <span><kbd>Bild ↑</kbd><kbd>Bild ↓</kbd></span><span>Kapitelanfang bzw. voriges / nächstes Kapitel (auch Umschalt + ← / →)</span>
      <span><kbd>↑</kbd><kbd>↓</kbd></span><span>Lauter / leiser</span>
      <span><kbd>+</kbd><kbd>−</kbd></span><span>Schneller / langsamer</span>
      <span><kbd>B</kbd></span><span>Lesezeichen setzen</span>
      <span><kbd>F</kbd></span><span>Favorit an/aus</span>
      <span><kbd>M</kbd></span><span>Ton aus / an</span>
      <span><kbd>Strg</kbd>+<kbd>F</kbd></span><span>Suchen</span>
      <span><kbd>Esc</kbd></span><span>Zurück zur Bibliothek</span></div>
      <p class="hint" style="margin-top:8px">Die Medientasten der Tastatur (Play/Pause, Weiter, Zurück) funktionieren ebenfalls.</p>
      <h3>Updates</h3>
      <div class="add-row" style="align-items:center"><span class="hint" id="updStatus" style="flex:1;margin:0">${S.update && S.update.available ? `Version ${esc(S.update.latest)} ist verfügbar.` : `Du hast Version ${esc(window.VERSION)}.`}</span>
        <button class="btn" data-updcheck>${icon("refresh")}Nach Updates suchen</button></div>
      <div class="about">MyPlayer ${esc(window.VERSION)} · Deine Daten (Fortschritt, Lesezeichen …) liegen in <a id="openData">${esc(S.dataDir)}</a></div>
      <div class="foot"><button class="btn" data-rescan>${icon("refresh")}Neu einlesen</button><span style="flex:1"></span><button class="btn" data-x>Abbrechen</button><button class="btn primary" data-save>Speichern</button></div>`);
    $("#modal").onclick = async e => {
      const t = e.target;
      const del = t.closest("[data-del]");
      if (del) { const [k, i] = del.dataset.del.split(":"); st[k].splice(+i, 1); return draw(); }
      const add = t.closest("[data-add]");
      if (add) {
        const k = add.dataset.add, inp = k === "folders" ? $("#pathIn") : $("#pathIn2");
        const v = inp.value.trim().replace(/^"|"$/g, "");
        if (v && !st[k].includes(v)) st[k].push(v);
        st.recursive = $("#recIn").checked;
        return draw();
      }
      const pick = t.closest("[data-pick]");
      if (pick) {
        const k = pick.dataset.pick;
        st.recursive = $("#recIn").checked;
        const p = await pickFolder(k === "folders" ? "Bibliotheksordner wählen" : "Podcast-Ordner wählen", st[k][0] || st.folders[0] || "");
        if (p && !st[k].includes(p)) st[k].push(p);
        return draw();
      }
      if (t.closest("#openData")) return api("/api/opendata", {});
      if (t.closest("[data-music-out]")) { e.preventDefault(); await musicSignOut(); $("#musicSec").innerHTML = musicSettingsHTML(); return; }
      if (t.closest("[data-pair]")) {
        const code = $("#pairCode").value.trim();
        if (!code) return;
        const d = await api("/api/cloud/pair", { code }).catch(e => ({ error: e.message }));
        if (d.error) return toast("Verbinden fehlgeschlagen: " + d.error, null, null, 7000);
        showCloud(d); $("#cloudSec").innerHTML = cloudSection(); toast(`Verbunden mit player.menet.ch als ${d.user}.`); return;
      }
      if (t.closest("[data-csync]")) { $("#cloudSec").querySelector(".hint").textContent = "Gleiche ab …"; showCloud(await api("/api/cloud/sync", {})); $("#cloudSec").innerHTML = cloudSection(); await loadLibrary(); return; }
      if (t.closest("[data-ccancel]")) { showCloud(await api("/api/cloud/cancel", {})); $("#cloudSec").innerHTML = cloudSection(); return; }
      if (t.closest("[data-unpair]")) { if (!confirm("Verbindung zu player.menet.ch trennen?")) return; showCloud(await api("/api/cloud/unpair", {})); $("#cloudSec").innerHTML = cloudSection(); await loadLibrary(); return; }
      if (t.closest("[data-updcheck]")) {
        $("#updStatus").textContent = "Suche …";
        const u = await checkUpdate(true);
        if (!u) $("#updStatus").textContent = "Konnte nicht nachsehen.";
        else if (u.available) { closeModal(); return updateDialog(); }
        else $("#updStatus").textContent = u.error ? u.error : `Alles aktuell – Version ${window.VERSION} ist die neueste.`;
        return;
      }
      if (t.closest("[data-rescan]")) { await api("/api/rescan", {}); toast("Bibliothek wird neu eingelesen …"); pollStatus(); return closeModal(); }
      if (t.closest("[data-x]")) return closeModal();
      if (t.closest("[data-save]")) {
        st.recursive = $("#recIn").checked;
        // nicht übernommene Eingaben trotzdem mitnehmen
        for (const [id, k] of [["#pathIn", "folders"], ["#pathIn2", "podcast_folders"]]) {
          const v = $(id).value.trim().replace(/^"|"$/g, ""); if (v && !st[k].includes(v)) st[k].push(v);
        }
        const d = await saveSettings(st);
        closeModal();
        if (d.rescan) { toast("Bibliothek wird neu eingelesen …"); pollStatus(); }
      }
    };
    $("#modal").onchange = e => { if (e.target.id === "musicIn") musicSettingsChange(e.target.checked).then(() => { $("#musicSec").innerHTML = musicSettingsHTML(); }); };
  };
  draw();
}

/* ---------------- Musik (Apple Music über MusicKit JS) ---------------- */
// Gleicher Code im PC-Player (desktop/web/app.js) und im Web-Player (server/public/player/app.js).
// Das Zugangs-Token kommt von player.menet.ch (der Schlüssel bleibt dort); die Person meldet sich mit ihrer Apple-ID an.
const MUSICKIT_URL = "https://js-cdn.music.apple.com/musickit/v3/musickit.js";
const M = {
  mk: null, devToken: "", loading: null, sf: "ch",
  lists: null, recent: null, added: null, albums: null,   // Startseite (Mediathek)
  results: null, q: "",                                    // Suche
  stack: [],      // geöffnete Playlists/Alben/Interpreten (Zurück = eins weg)
  cache: {},      // Titel je Playlist/Album/Interpret
  items: {},      // angezeigte Einträge nach "typ:id"
};

function musicEnabled() { return !!S.settings.music; }
function applyMusicSetting() {
  const tab = $('#kindSeg button[data-kind="music"]');
  if (tab) tab.hidden = !musicEnabled();
  if (!musicEnabled() && S.kind === "music") { S.kind = "book"; $$("#kindSeg button").forEach(x => x.classList.toggle("on", x.dataset.kind === "book")); }
}

function loadMusicKit() {
  if (window.MusicKit && MusicKit.getInstance) return Promise.resolve();
  if (M.loading) return M.loading;
  M.loading = new Promise((res, rej) => {
    document.addEventListener("musickitloaded", () => res(), { once: true });
    const s = document.createElement("script");
    s.src = MUSICKIT_URL; s.async = true;
    s.dataset.webComponents = "";
    s.onerror = () => { M.loading = null; rej(new Error("Apple Music konnte nicht geladen werden (Internet?)")); };
    document.head.append(s);
    setTimeout(() => rej(new Error("Apple Music lädt nicht – bitte später nochmals versuchen")), 20000);
  });
  return M.loading;
}

async function musicSetup() {
  if (M.mk) return M.mk;
  const t = await api("/api/musik/token", {});
  if (!t || !t.token) throw new Error((t && t.error) || "Kein Zugang zu Apple Music");
  await loadMusicKit();
  M.devToken = t.token;
  M.mk = await MusicKit.configure({ developerToken: t.token, app: { name: "MyPlayer", build: String(window.VERSION || "1") } });
  M.mk.addEventListener("playbackStateDidChange", musicStateChanged);
  M.mk.addEventListener("nowPlayingItemDidChange", () => { renderMusicNow(); markMusicPlaying(); });
  M.mk.addEventListener("playbackTimeDidChange", () => updateMusicTime());
  M.mk.addEventListener("authorizationStatusDidChange", () => { musicForget(); if (S.kind === "music") renderLibrary(); });
  return M.mk;
}
function musicForget() { M.lists = M.recent = M.added = M.albums = M.results = null; M.q = ""; M.stack = []; M.cache = {}; }

function musicPlaying() { return !!(M.mk && M.mk.playbackState === MusicKit.PlaybackStates.playing); }
function musicStateChanged() {
  // Musik und Hörbuch nie gleichzeitig: startet Musik, pausiert das Hörbuch
  if (musicPlaying() && P.item && !audio.paused) audio.pause();
  renderMusicNow();
}
// … und startet ein Hörbuch, pausiert die Musik
audio.addEventListener("play", () => { if (musicPlaying()) M.mk.pause(); });

/* --- Hilfen --- */
function art(a, size = 160) {
  const u = a && a.attributes && a.attributes.artwork && a.attributes.artwork.url;
  return u ? u.replace("{w}", size).replace("{h}", size).replace("{f}", "jpg") : "";
}
function baseType(t) { return String(t || "").replace("library-", ""); }
function itemIds(x) {
  const p = (x && x.attributes && x.attributes.playParams) || (x && x.playParams) || {};
  return [x && x.id, p.id, p.catalogId].filter(Boolean).map(String);
}
function sameItem(x, ids) { const own = itemIds(x); return ids.some(i => own.includes(i)); }
function remember(it) { const k = `${it.type}:${it.id}`; M.items[k] = it; return k; }
function opensDetail(t) { return ["albums", "playlists", "artists"].includes(baseType(t)); }
function itemSub(it) {
  const a = it.attributes || {}, t = baseType(it.type);
  if (t === "songs") return [a.artistName, a.albumName].filter(Boolean).join(" · ");
  if (t === "albums") return [a.artistName, a.releaseDate ? String(a.releaseDate).slice(0, 4) : ""].filter(Boolean).join(" · ");
  if (t === "artists") return "Interpret";
  if (t === "stations") return "Radio";
  return a.curatorName || "Playlist";
}

// Liste über mehrere Seiten holen (Apple liefert höchstens 100 pro Abruf)
async function musicFetchAll(path, limit = 100, max = 500) {
  let out = [], next = path, q = { limit };
  while (next && out.length < max) {
    const r = await M.mk.api.music(next, q);
    const d = (r && r.data) || {};
    out = out.concat(d.data || []);
    next = d.next; q = {};
  }
  return out;
}

/* --- Darstellung: Zeilen und Kacheln --- */
function musicRow(it) {
  const a = it.attributes || {}, k = remember(it), img = art(it, 120), det = opensDetail(it.type);
  const dur = a.durationInMillis ? fmtClock(a.durationInMillis / 1000) : "";
  return `<div class="row music-row" data-mkey="${esc(k)}">
    <div class="rc">${img ? `<img loading="lazy" src="${esc(img)}" alt="">` : `<div class="ph">${icon("music")}</div>`}</div>
    <div class="rt"><b>${esc(a.name || "?")}</b><span>${esc(itemSub(it))}</span></div>
    <div class="rd">${dur}</div>
    <div class="rb">${det && baseType(it.type) !== "artists" ? `<button class="icon-btn" data-mrowplay title="Gleich abspielen">${icon("play")}</button>`
      : det ? `<span class="icon-btn">${icon("chev-left", "flip")}</span>` : `<span class="icon-btn">${icon("play")}</span>`}</div>
  </div>`;
}
function musicCard(it) {
  const a = it.attributes || {}, k = remember(it), img = art(it, 300);
  return `<div class="mcard" data-mkey="${esc(k)}" title="${esc(a.name || "")}">
    <div class="mc-cover">${img ? `<img loading="lazy" src="${esc(img)}" alt="">` : icon("music")}
      ${baseType(it.type) !== "artists" ? `<button class="mc-play" data-mrowplay title="Gleich abspielen">${icon("play")}</button>` : ""}</div>
    <b>${esc(a.name || "?")}</b><span>${esc(itemSub(it))}</span></div>`;
}
function musicSection(title, items, grid = false) {
  if (!items || !items.length) return "";
  return `<section class="music-sec"><h3>${esc(title)}</h3>${grid ? `<div class="mgrid">${items.map(musicCard).join("")}</div>`
    : `<div class="list">${items.map(i => musicRow(i)).join("")}</div>`}</section>`;
}
function trackRow(tr, i, showArtist) {
  const a = tr.attributes || {}, ok = !!a.playParams;
  const dur = a.durationInMillis ? fmtClock(a.durationInMillis / 1000) : "";
  const sub = showArtist ? [a.artistName, a.albumName].filter(Boolean).join(" · ") : "";
  return `<div class="mtrack${ok ? "" : " off"}" data-tidx="${i}" data-tids="${esc(itemIds(tr).join(","))}"${ok ? "" : ` title="Bei Apple Music nicht verfügbar"`}>
    <span class="tn"><i>${showArtist || !a.trackNumber ? i + 1 : a.trackNumber}</i>${icon("play")}</span>
    <div class="rt"><b>${esc(a.name || "?")}</b>${sub ? `<span>${esc(sub)}</span>` : ""}</div>
    <span class="rd">${dur}</span></div>`;
}

/* --- Seite «Musik» --- */
async function renderMusic(body, head) {
  head.innerHTML = `<h2>Musik</h2><span class="sub">Apple Music</span>`;
  let mk;
  try { mk = await musicSetup(); }
  catch (e) {
    body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><h2>Apple Music</h2><p>${esc(e.message)}</p></div>`;
    return;
  }
  if (!mk.isAuthorized) {
    body.innerHTML = `<div class="empty"><div class="big">${icon("music")}</div><h2>Mit Apple Music verbinden</h2>
      <p>Melde dich einmal mit deiner Apple-ID an (mit Apple-Music-Abo). Danach findest du hier deine Mediathek, zuletzt Gehörtes und die ganze Apple-Music-Bibliothek.</p>
      <button class="btn primary" id="mAuth">${icon("music")}Mit Apple Music anmelden</button></div>`;
    $("#mAuth").onclick = async () => {
      try { await mk.authorize(); renderLibrary(); }
      catch (e) { toast("Anmeldung bei Apple Music abgebrochen oder fehlgeschlagen."); }
    };
    return;
  }
  M.sf = mk.storefrontId || "ch";
  const q = (S.q || "").trim();
  if (M.stack.length && M.stack[M.stack.length - 1].q !== q) M.stack = [];   // neue Suche → zurück zur Liste
  const top = M.stack[M.stack.length - 1];
  body.innerHTML = `<div id="musicNow"></div><div id="musicBody"><div class="empty"><span class="spinner"></span></div></div>`;
  renderMusicNow();
  const mb = $("#musicBody");
  try {
    if (top) { await renderMusicDetail(mb, top.key); return; }
    if (q) {
      if (M.q !== q) {
        M.q = q; M.results = null;
        await new Promise(r => setTimeout(r, 400));
        if (M.q !== q) return;   // inzwischen weiter getippt
        const r = await mk.api.music(`/v1/catalog/${M.sf}/search`, { term: q, types: ["songs", "albums", "playlists", "artists"], limit: 10 });
        if (M.q !== q) return;
        M.results = (r.data && r.data.results) || {};
      }
      const R = M.results || {};
      const html = musicSection("Interpreten", R.artists && R.artists.data) + musicSection("Titel", R.songs && R.songs.data)
        + musicSection("Alben", R.albums && R.albums.data, true) + musicSection("Playlists", R.playlists && R.playlists.data, true);
      mb.innerHTML = html || `<div class="empty"><p>Nichts gefunden für «${esc(q)}».</p></div>`;
    } else {
      if (!M.lists) {
        const [lists, recent, added, albums] = await Promise.all([
          musicFetchAll("/v1/me/library/playlists", 100, 300).catch(() => []),
          mk.api.music("/v1/me/recent/played", { limit: 10 }).then(r => (r.data && r.data.data) || []).catch(() => []),
          mk.api.music("/v1/me/library/recently-added", { limit: 10 }).then(r => (r.data && r.data.data) || []).catch(() => []),
          musicFetchAll("/v1/me/library/albums", 100, 1000).catch(() => []),
        ]);
        const name = x => String((x.attributes && x.attributes.name) || "");
        M.lists = lists; M.recent = recent; M.added = added;
        M.albums = albums.sort((x, y) => name(x).localeCompare(name(y), "de", { sensitivity: "base" }));
      }
      mb.innerHTML = (musicSection("Zuletzt gehört", M.recent, true) + musicSection("Meine Playlists", M.lists, true)
        + musicSection("Neu in der Mediathek", M.added, true) + musicSection(`Meine Alben (${M.albums.length})`, M.albums, true))
        || `<div class="empty"><p>Deine Mediathek ist noch leer. Oben bei der Lupe kannst du in ganz Apple Music suchen und Alben hinzufügen.</p></div>`;
    }
  } catch (e) {
    mb.innerHTML = `<div class="empty"><p>Apple Music antwortet nicht: ${esc(e.message || e)}</p></div>`;
  }
}

/* --- Geöffnete Playlist / Album / Interpret --- */
async function musicLoadDetail(it) {
  const sf = M.sf, id = encodeURIComponent(it.id), t = it.type;
  const tracks = p => musicFetchAll(p, 100, 1000).catch(() => []);
  if (t === "library-playlists") return { tracks: await tracks(`/v1/me/library/playlists/${id}/tracks`), queue: { playlist: it.id } };
  if (t === "playlists") return { tracks: await tracks(`/v1/catalog/${sf}/playlists/${id}/tracks`), queue: { playlist: it.id } };
  if (t === "library-albums") return { tracks: await tracks(`/v1/me/library/albums/${id}/tracks`), queue: { album: it.id } };
  if (t === "albums") return { tracks: await tracks(`/v1/catalog/${sf}/albums/${id}/tracks`), queue: { album: it.id } };
  if (t === "artists") {
    const [top, albums] = await Promise.all([
      M.mk.api.music(`/v1/catalog/${sf}/artists/${id}/view/top-songs`, { limit: 10 }).then(r => (r.data && r.data.data) || []).catch(() => []),
      musicFetchAll(`/v1/catalog/${sf}/artists/${id}/albums`, 25, 100).catch(() => []),
    ]);
    albums.sort((x, y) => String((y.attributes || {}).releaseDate || "").localeCompare(String((x.attributes || {}).releaseDate || "")));
    return { tracks: top, albums, queue: null };
  }
  return { tracks: [], queue: null };
}

async function renderMusicDetail(mb, key) {
  const it = M.items[key];
  if (!it) { M.stack.pop(); return renderLibrary(); }
  if (!M.cache[key]) M.cache[key] = await musicLoadDetail(it);
  const D = M.cache[key], a = it.attributes || {}, t = it.type, bt = baseType(t);
  const lib = t.startsWith("library-");
  const n = D.tracks.length;
  const kind = { albums: "Album", playlists: "Playlist", artists: "Interpret" }[bt] || "";
  const info = bt === "artists" ? "" : [itemSub(it), `${n} Titel`].filter(Boolean).join(" · ");
  const img = art(it, 400);
  const showArtist = bt !== "albums" || D.tracks.some(x => (x.attributes || {}).artistName && (x.attributes || {}).artistName !== a.artistName);
  mb.innerHTML = `<button class="btn mback" data-mback>${icon("chev-left")}Zurück</button>
    <div class="mhero">
      <div class="mh-cover${bt === "artists" ? " round" : ""}">${img ? `<img src="${esc(img)}" alt="">` : icon("music")}</div>
      <div class="mh-txt"><span class="mh-kind">${kind}</span><h2>${esc(a.name || "")}</h2>${info ? `<p>${esc(info)}</p>` : ""}
        <div class="mh-btns">
          ${n ? `<button class="btn primary" data-mplayall>${icon("play")}Abspielen</button><button class="btn" data-mshuffle>${icon("refresh")}Zufällig</button>` : ""}
          ${lib ? `<span class="mh-lib">${icon("check")}In deiner Mediathek</span>`
            : (bt === "albums" || bt === "playlists") ? `<button class="btn" data-madd>${icon("plus")}Zur Mediathek hinzufügen</button>` : ""}
        </div></div></div>
    ${n ? `${bt === "artists" ? "<h3 class=\"mh-sec\">Top-Titel</h3>" : ""}<div class="mtracks">${D.tracks.map((x, i) => trackRow(x, i, showArtist)).join("")}</div>`
      : bt === "artists" ? "" : `<div class="empty"><p>Diese ${kind} ist leer.</p></div>`}
    ${bt === "artists" ? musicSection("Alben", D.albums, true) : ""}`;
  markMusicPlaying();
}

function markMusicPlaying() {
  const now = M.mk && M.mk.nowPlayingItem;
  const ids = now ? itemIds(now) : [];
  $$("[data-tids]").forEach(r => r.classList.toggle("playing", !!ids.length && r.dataset.tids.split(",").some(i => ids.includes(i))));
}

/* --- Abspielen --- */
function musicQueueFor(it) {
  const t = baseType(it.type);
  return t === "playlists" ? { playlist: it.id } : t === "albums" ? { album: it.id } : t === "stations" ? { station: it.id } : t === "songs" ? { song: it.id } : null;
}
async function musicStart(queue, opts = {}) {
  const mk = await musicSetup();
  if (P.item && !audio.paused) audio.pause();
  try { mk.shuffleMode = opts.shuffle ? 1 : 0; } catch (e) { }
  await mk.setQueue({ ...queue, ...(opts.startWith != null ? { startWith: opts.startWith } : {}), startPlaying: true });
  // Falls Apple den gewünschten Starttitel nicht übernommen hat: in der Warteschlange suchen und dorthin springen
  if (opts.want && !(mk.nowPlayingItem && sameItem(mk.nowPlayingItem, opts.want))) {
    const items = (mk.queue && mk.queue.items) || [];
    const j = items.findIndex(x => sameItem(x, opts.want));
    if (j >= 0 && mk.changeToMediaAtIndex) await mk.changeToMediaAtIndex(j);
  }
  await mk.play();
}
async function musicPlayItem(it) {
  const q = musicQueueFor(it);
  if (!q) return;
  try { await musicStart(q); } catch (e) { toast("Abspielen nicht möglich: " + (e.message || e), null, null, 6000); }
}
async function musicPlayTrack(key, idx, shuffle = false) {
  const D = M.cache[key], it = M.items[key];
  if (!D || !it) return;
  const tr = D.tracks[idx];
  if (tr && !(tr.attributes || {}).playParams) return toast("Dieser Titel ist bei Apple Music nicht verfügbar.");
  const queue = D.queue || { songs: D.tracks.filter(x => (x.attributes || {}).playParams).map(x => x.id) };
  try { await musicStart(queue, tr ? { startWith: D.queue ? idx : Math.max(0, queue.songs.indexOf(tr.id)), want: itemIds(tr) } : { shuffle }); }
  catch (e) { toast("Abspielen nicht möglich: " + (e.message || e), null, null, 6000); }
}

/* --- Zur Mediathek hinzufügen --- */
async function musicAddToLibrary(it) {
  const kind = baseType(it.type);
  const r = await fetch(`https://api.music.apple.com/v1/me/library?ids[${kind}]=${encodeURIComponent(it.id)}`, {
    method: "POST", headers: { "Authorization": "Bearer " + M.devToken, "Music-User-Token": M.mk.musicUserToken || "" },
  });
  if (!r.ok) throw new Error(r.status === 403 ? "Apple Music erlaubt das Hinzufügen nicht (Abo/Mediathek-Synchronisierung prüfen)" : `Apple Music: Fehler ${r.status}`);
  M.lists = null;   // Mediathek beim nächsten Mal neu laden
}

/* --- Leiste «Jetzt läuft» --- */
function renderMusicNow() {
  const el = $("#musicNow");
  if (!el || !M.mk) return;
  const it = M.mk.nowPlayingItem;
  if (!it) { el.innerHTML = ""; return; }
  const a = it.attributes || it;
  const img = it.artworkURL || art(it, 200);
  el.innerHTML = `<div class="music-now">
    <div class="mn-cover">${img ? `<img src="${esc(String(img).replace("{w}", 200).replace("{h}", 200))}" alt="">` : icon("music")}</div>
    <div class="mn-txt"><b>${esc(a.name || it.title || "")}</b><span>${esc(a.artistName || it.artistName || "")}</span>
      <div class="mn-bar"><i id="mnProg"></i></div></div>
    <div class="mn-ctl"><button class="ctl sm" data-mctl="prev">${icon("prev")}</button>
      <button class="ctl play sm" data-mctl="toggle">${icon(musicPlaying() ? "pause" : "play")}</button>
      <button class="ctl sm" data-mctl="next">${icon("next")}</button></div></div>`;
  updateMusicTime();
}
function updateMusicTime() {
  const bar = $("#mnProg");
  if (!bar || !M.mk) return;
  const d = M.mk.currentPlaybackDuration || 0;
  bar.style.width = d ? (M.mk.currentPlaybackTime / d * 100) + "%" : "0";
}

/* --- Klicks im Bereich «Musik» --- */
function bindMusic() {
  $("#libBody").addEventListener("click", async e => {
    if (S.kind !== "music") return;
    const t = e.target;
    const hit = sel => t.closest(sel);
    const top = M.stack[M.stack.length - 1];
    if (hit("[data-mctl]") && M.mk) {
      e.stopPropagation();
      const c = hit("[data-mctl]").dataset.mctl;
      if (c === "toggle") musicPlaying() ? M.mk.pause() : M.mk.play();
      if (c === "next") M.mk.skipToNextItem();
      if (c === "prev") M.mk.skipToPreviousItem();
      return;
    }
    if (hit("[data-mback]")) { e.stopPropagation(); M.stack.pop(); renderLibrary(); return; }
    if (hit("[data-mplayall]") && top) { e.stopPropagation(); musicPlayTrack(top.key, null); return; }
    if (hit("[data-mshuffle]") && top) { e.stopPropagation(); musicPlayTrack(top.key, null, true); return; }
    if (hit("[data-madd]") && top) {
      e.stopPropagation();
      const b = hit("[data-madd]"); b.disabled = true;
      try {
        await musicAddToLibrary(M.items[top.key]);
        b.outerHTML = `<span class="mh-lib">${icon("check")}Hinzugefügt</span>`;
        toast(`«${(M.items[top.key].attributes || {}).name}» ist jetzt in deiner Mediathek.`);
      } catch (err) { b.disabled = false; toast(err.message || String(err), null, null, 7000); }
      return;
    }
    const tr = hit("[data-tidx]");
    if (tr && top) { e.stopPropagation(); musicPlayTrack(top.key, +tr.dataset.tidx); return; }
    const row = hit("[data-mkey]");
    if (row) {
      e.stopPropagation();
      const it = M.items[row.dataset.mkey];
      if (!it) return;
      if (hit("[data-mrowplay]") || !opensDetail(it.type)) return musicPlayItem(it);
      M.stack.push({ key: row.dataset.mkey, q: (S.q || "").trim() });
      renderLibrary();
      $("#libBody").scrollTop = 0; window.scrollTo(0, 0);
    }
  }, true);
}

async function musicSignOut() {
  if (M.mk) { try { await M.mk.unauthorize(); } catch (e) { } }
  musicForget();
  toast("Von Apple Music abgemeldet.");
}

function musicSettingsHTML() {
  return `<h3>Musik</h3>
    <label class="switch"><input type="checkbox" id="musicIn" ${musicEnabled() ? "checked" : ""}><span class="tr"></span><span>Musik anzeigen (Apple Music)</span></label>
    ${musicEnabled() && M.mk && M.mk.isAuthorized ? `<p class="hint">Mit Apple Music verbunden. <a href="#" data-music-out>Abmelden</a></p>` : ""}`;
}
async function musicSettingsChange(on) {
  S.settings.music = on;
  await saveSettings({ music: on });
  applyMusicSetting();
  renderLibrary();
}
// Medientasten: läuft gerade Musik, gehört Play/Pause der Musik
function musicMediaKey() { if (musicPlaying()) { M.mk.pause(); return true; } return false; }

/* ---------------- Media Session (Medientasten) ---------------- */
function updateMediaSession() {
  if (!("mediaSession" in navigator) || !P.item) return;
  const ch = P.chapters[P.chapterIdx()];
  const art = P.item.cover ? [{ src: location.origin + "/cover/" + P.item.cover + "?big=1", sizes: "512x512" }] : [];
  navigator.mediaSession.metadata = new MediaMetadata({
    title: P.chapters.length > 1 && ch ? ch.title : P.item.title,
    artist: P.item.author || P.item.show || "",
    album: P.item.title, artwork: art,
  });
}
if ("mediaSession" in navigator) {
  const ms = navigator.mediaSession;
  const h = (a, f) => { try { ms.setActionHandler(a, f); } catch (e) { } };
  h("play", () => togglePlay()); h("pause", () => { if (!musicMediaKey()) audio.pause(); });
  h("seekbackward", () => skip(-SKIP)); h("seekforward", () => skip(SKIP));
  h("previoustrack", () => prevChapter()); h("nexttrack", () => nextChapter());
  h("seekto", d => P.seek(d.seekTime));
  h("stop", () => audio.pause());
}

/* ---------------- Ereignisse ---------------- */
function bind() {
  $("#kindSeg").onclick = e => { const b = e.target.closest("button"); if (!b) return; S.kind = b.dataset.kind; $$("#kindSeg button").forEach(x => x.classList.toggle("on", x === b)); showView("library"); renderLibrary(); };
  $("#chipFav").onclick = () => { S.fav = !S.fav; if (S.fav) S.arch = false; syncChips(); showView("library"); renderLibrary(); };
  $("#chipArch").onclick = () => { S.arch = !S.arch; if (S.arch) S.fav = false; syncChips(); showView("library"); renderLibrary(); };
  $("#search").oninput = debounce(e => { S.q = e.target.value; if (S.view !== "library") showView("library"); renderLibrary(); }, 120);
  $("#sortSel").onchange = e => { S.settings.sort = e.target.value; saveSettingsSoon({ sort: e.target.value }); renderLibrary(); };
  $("#viewBtn").onclick = () => { S.settings.view = S.settings.view === "list" ? "grid" : "list"; saveSettingsSoon({ view: S.settings.view }); syncViewBtn(); showView("library"); renderLibrary(); };
  $("#themeBtn").onclick = () => { S.settings.theme = S.settings.theme === "light" ? "dark" : "light"; applyTheme(); saveSettingsSoon({ theme: S.settings.theme }); };
  $("#settingsBtn").onclick = settingsDialog;
  $("#updPill").onclick = updateDialog;
  $("#cloudInfo").onclick = settingsDialog;
  $("#updBanner").onclick = e => {
    const b = e.target.closest("[data-u]"); if (!b) return;
    if (b.dataset.u === "notes") updateDialog();
    if (b.dataset.u === "apply") applyUpdate();
    if (b.dataset.u === "later") { S.updDismissed = S.update.latest; showUpdate(S.update); }
  };
  bindMusic();
  $("#libBody").addEventListener("click", libClick);
  bindLongPress();
  $("#libBody").addEventListener("keydown", e => { if (e.key === "Enter" && e.target.closest(".card")) openItem(e.target.closest(".card").dataset.id, true); });
  $("#libBody").addEventListener("contextmenu", e => {
    const el = e.target.closest("[data-id]"); if (!el) return; e.preventDefault();
    if (S.sel.size && !S.sel.has(el.dataset.id)) S.sel.add(el.dataset.id), refreshSel();
    if (S.sel.size > 1) return showMenu(selMenuEntries(), e.clientX, e.clientY);
    itemMenu(el.dataset.id, null, { x: e.clientX, y: e.clientY });
  });
  $("#selBar").onclick = e => {
    const b = e.target.closest("[data-sel]"); if (!b) return;
    const a = b.dataset.sel;
    if (a === "podcast" || a === "book") bulk({ kind: a });
    else if (a === "more") { const r = b.getBoundingClientRect(); showMenu(selMenuEntries(), r.left, r.top - 330); }
    else if (a === "all") { domIds().forEach(i => S.sel.add(i)); refreshSel(); }
    else if (a === "clear") clearSel();
  };
  document.addEventListener("click", e => { if (!e.target.closest("#menu") && !e.target.closest("[data-act=menu]") && !e.target.closest("#plMore") && !e.target.closest("[data-sel=more]")) hideMenu(); });
  document.addEventListener("contextmenu", e => { if (!e.target.closest("input,textarea")) e.preventDefault(); });
  $("#modalWrap").addEventListener("mousedown", e => { if (e.target.id === "modalWrap") closeModal(null); });

  $("#playBtn").onclick = togglePlay; $("#mPlay").onclick = togglePlay;
  $("#backSkip").onclick = () => skip(-SKIP); $("#mBack").onclick = () => skip(-SKIP);
  $("#fwdSkip").onclick = () => skip(SKIP); $("#mFwd").onclick = () => skip(SKIP);
  $("#prevBtn").onclick = prevChapter; $("#nextBtn").onclick = nextChapter;
  $("#backBtn").onclick = () => { showView("library"); renderLibrary(); };
  $("#miniOpen").onclick = () => showView("player");
  $("#plFav").onclick = () => P.item && setFlags(P.item.id, { fav: !P.item.fav });
  $("#plMore").onclick = e => P.item && itemMenu(P.item.id, $("#plMore"));
  $("#bmAdd").onclick = addBookmark; $("#bmAddSide").onclick = addBookmark;
  $("#bookmarkList").onclick = bookmarkAction;
  $("#sleepBtn").onclick = sleepDialog;
  $$(".side-tabs button").forEach(b => b.onclick = () => sideTab(b.dataset.tab));
  $("#chapterList").onclick = e => { const li = e.target.closest("li"); if (!li) return; P.seek(P.chapters[+li.dataset.i].start, true); if (!P.playing) togglePlay(); };
  $("#speedSeg").onclick = e => { const b = e.target.closest("button"); if (b) setSpeed(+b.dataset.s); };
  $("#volSlider").oninput = e => setVolume(e.target.value / 100);
  $("#muteBtn").onclick = () => { if (audio.volume > 0) { S._vol = audio.volume; setVolume(0); } else setVolume(S._vol || 1); };

  // Schieberegler: Kapitel & Gesamt
  const chS = $("#chSlider"), toS = $("#totSlider");
  chS.addEventListener("input", () => {
    dragging = "ch"; chS.style.setProperty("--p", chS.value / 10 + "%");
    const ch = P.chapters[P.chapterIdx()]; $("#chElapsed").textContent = fmtClock((ch.end - ch.start) * chS.value / 1000);
  });
  chS.addEventListener("change", () => { const ch = P.chapters[P.chapterIdx()]; dragging = null; P.seek(ch.start + (ch.end - ch.start) * chS.value / 1000); });
  toS.addEventListener("input", () => { dragging = "tot"; toS.style.setProperty("--p", toS.value / 10 + "%"); $("#totElapsed").textContent = fmtClock(P.total * toS.value / 1000); });
  toS.addEventListener("change", () => { dragging = null; P.seek(P.total * toS.value / 1000); });

  document.addEventListener("keydown", onKey);
  window.addEventListener("pagehide", () => {
    if (P.item) fetch("/api/progress", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: JSON.stringify({ id: P.item.id, pos: P.pos(), duration: P.total, flush: true }) });
    fetch("/api/bye", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: "{}" });
  });
}

function onKey(e) {
  if (e.target.closest("input[type=text],input[type=search],textarea,select")) {
    if (e.key === "Escape") { e.target.blur(); if (e.target.id === "search" && S.q) { e.target.value = ""; S.q = ""; renderLibrary(); } }
    return;
  }
  if (!$("#modalWrap").hidden) { if (e.key === "Escape") closeModal(null); return; }
  const k = e.key;
  if ((e.ctrlKey && k.toLowerCase() === "f") || k === "/") { e.preventDefault(); $("#search").focus(); return; }
  if (e.ctrlKey && k.toLowerCase() === "a" && S.view === "library") { e.preventDefault(); domIds().forEach(i => S.sel.add(i)); refreshSel(); return; }
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const map = {
    " ": togglePlay, "k": togglePlay,
    "ArrowLeft": () => e.shiftKey ? prevChapter() : skip(-SKIP), "ArrowRight": () => e.shiftKey ? nextChapter() : skip(SKIP),
    "j": () => skip(-SKIP), "l": () => skip(SKIP),
    "PageUp": prevChapter, "PageDown": nextChapter,
    "ArrowUp": () => setVolume((S.settings.volume ?? 1) + 0.05), "ArrowDown": () => setVolume((S.settings.volume ?? 1) - 0.05),
    "b": addBookmark, "B": addBookmark, "f": () => P.item && setFlags(P.item.id, { fav: !P.item.fav }),
    "m": () => $("#muteBtn").click(),
    "+": () => { const i = SPEEDS.findIndex(s => s >= (S.settings.speed || 1) - 0.001); setSpeed(SPEEDS[Math.min(SPEEDS.length - 1, i + 1)]); },
    "-": () => { const i = SPEEDS.findIndex(s => s >= (S.settings.speed || 1) - 0.001); setSpeed(SPEEDS[Math.max(0, i - 1)]); },
    "Escape": () => { hideMenu(); if (S.sel.size) return clearSel(); if (S.view === "player") { showView("library"); renderLibrary(); } },
  };
  if (map[k]) {
    if (k === " " && e.target.closest("button")) e.target.blur();
    e.preventDefault(); map[k]();
  }
}

function syncChips() { $("#chipFav").classList.toggle("on", S.fav); $("#chipArch").classList.toggle("on", S.arch); $("#chipFav").innerHTML = icon(S.fav ? "heart-f" : "heart") + "Favoriten"; }
function syncViewBtn() { $("#viewBtn").innerHTML = icon(S.settings.view === "list" ? "grid" : "list"); $("#viewBtn").title = S.settings.view === "list" ? "Kachelansicht" : "Listenansicht"; }
function applyTheme() { document.documentElement.dataset.theme = S.settings.theme === "light" ? "light" : "dark"; $("#themeBtn").innerHTML = icon(S.settings.theme === "light" ? "moon" : "sun"); }

let pollTimer = null;
function pollStatus() {
  clearTimeout(pollTimer);
  pollTimer = setTimeout(async () => {
    try {
      const st = await api("/api/status");
      if (st.running) { setScan(st); await loadLibrary(); pollStatus(); }
      else { setScan(st); await loadLibrary(); }
    } catch (e) { pollStatus(); }
  }, 1200);
}

/* ---------------- player.menet.ch ---------------- */
S.cloud = null;
let cloudTimer = null;
function showCloud(c) {
  const before = S.cloud;
  S.cloud = c;
  if (!c) return;
  const busy = c.uploading || (c.queue && c.queue.length);
  $("#cloudInfo").hidden = !busy;
  if (busy) {
    const u = c.uploading;
    const pctTxt = u && u.total ? ` · ${Math.floor(u.done / u.total * 100)} %` : "";
    const more = c.queue.length > 1 ? ` (noch ${c.queue.length - 1})` : "";
    $("#cloudText").textContent = u ? `Lade hoch: ${u.title}${pctTxt}${more}` : `Hochladen …${more}`;
    clearTimeout(cloudTimer); cloudTimer = setTimeout(() => api("/api/cloud").then(showCloud).catch(() => { }), 1500);
  }
  if (before && before.changes !== c.changes) loadLibrary();
  if (before && (before.uploading || (before.queue || []).length) && !busy && !c.error) toast("Hochladen fertig – die Titel sind auf player.menet.ch.");
  if (c.error && (!before || before.error !== c.error)) toast("player.menet.ch: " + c.error, null, null, 7000);
}
async function cloudUpload(ids) {
  const d = await api("/api/cloud/upload", { ids });
  toast(d.added ? `${d.added} Titel ${d.added === 1 ? "wird" : "werden"} hochgeladen. Du kannst weiterhören.` : "Schon in der Warteschlange.");
  showCloud(d);
}
async function cloudDelete(id) {
  const it = S.byId[id];
  if (!confirm(`«${it.title}» von player.menet.ch entfernen? Die Datei auf dem PC bleibt. Auf dem Handy ist das Buch danach weg (für die ganze Familie).`)) return;
  const d = await api("/api/cloud/delete", { id });
  if (d.error) toast(d.error); else { toast("Vom Server entfernt."); await loadLibrary(); }
}
function cloudSection() {
  const c = S.cloud || {};
  if (!c.connected) return `<h3>player.menet.ch</h3>
    <p class="hint">Verbinde den Player mit player.menet.ch: Hörstand und Lesezeichen werden abgeglichen und du kannst Bücher fürs Handy hochladen.
      Auf player.menet.ch → <b>Geräte</b> → «Code erzeugen», dann den Code hier eingeben.</p>
    <div class="add-row"><input id="pairCode" type="text" placeholder="Code, z. B. ABCD-EFGH" autocomplete="off"><button class="btn primary" data-pair>${icon("cloud")}Verbinden</button></div>`;
  const when = c.last_sync ? new Date(c.last_sync * 1000).toLocaleTimeString("de-CH", { hour: "2-digit", minute: "2-digit" }) : "noch nie";
  return `<h3>player.menet.ch</h3>
    <p class="hint">Verbunden als <b>${esc(c.user || "?")}</b>${c.admin ? " (Admin – darf hochladen)" : ""} · zuletzt abgeglichen: ${when}${c.error ? ` · <span style="color:#ff8a7a">${esc(c.error)}</span>` : ""}</p>
    ${c.interim_cert ? `<p class="hint" style="color:var(--accent)">⚠ Vorübergehende Zertifikat-Ausnahme aktiv: green.ch hat für player.menet.ch noch nicht das richtige Zertifikat eingespielt. Die Verbindung ist trotzdem verschlüsselt und geprüft. Sobald das richtige Zertifikat da ist, verschwindet dieser Hinweis von selbst.</p>` : ""}
    <div class="add-row"><button class="btn" data-csync>${icon("refresh")}Jetzt abgleichen</button>${c.uploading || (c.queue || []).length ? `<button class="btn" data-ccancel>${icon("x")}Hochladen stoppen</button>` : ""}<span style="flex:1"></span><button class="btn danger" data-unpair>Trennen</button></div>
    ${c.admin ? `<p class="hint" style="margin-top:8px">Hochladen: Rechtsklick auf einen Titel (oder mehrere auswählen) → «Auf player.menet.ch hochladen».</p>` : ""}`;
}

/* ---------------- Updates ---------------- */
S.update = null;
function mdLite(t) { // einfache Darstellung der Änderungsliste
  let html = "", inList = false;
  for (const raw of String(t || "").split(/\r?\n/)) {
    const line = raw.trim();
    const li = line.match(/^[-*]\s+(.*)/);
    if (li) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${esc(li[1]).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")}</li>`; continue; }
    if (inList) { html += "</ul>"; inList = false; }
    if (!line) continue;
    const h = line.match(/^#+\s+(.*)/);
    html += h ? `<h4>${esc(h[1])}</h4>` : `<p>${esc(line).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")}</p>`;
  }
  return html + (inList ? "</ul>" : "");
}
function showUpdate(u) {
  S.update = u;
  const av = !!(u && u.available);
  $("#updPill").hidden = !av;
  if (av) $("#updPillText").textContent = `Version ${u.latest}`;
  const b = $("#updBanner");
  if (!av || S.updDismissed === u.latest) { b.hidden = true; return; }
  b.hidden = false;
  b.innerHTML = `<span class="upd-ic">${icon("refresh")}</span><div class="upd-t"><b>Neue Version ${esc(u.latest)} verfügbar</b><span>Du hast ${esc(u.current)}. Das Update dauert nur einen Moment, deine Daten bleiben erhalten.</span></div>
    <button class="btn" data-u="notes">Was ist neu?</button><button class="btn primary" data-u="apply">Jetzt aktualisieren</button><button class="icon-btn sm" data-u="later" title="Später">${icon("x")}</button>`;
}
function updateDialog() {
  const u = S.update || {};
  openModal(`<h2>${u.available ? `Version ${esc(u.latest)} ist da` : "Updates"}</h2>
    <p class="hint">Installiert: ${esc(u.current || window.VERSION)}${u.latest ? ` · Neueste: ${esc(u.latest)}` : ""}</p>
    ${u.notes ? `<div class="notes">${mdLite(u.notes)}</div>` : ""}
    ${u.error ? `<p class="hint" style="color:#ff8a7a">${esc(u.error)}</p>` : ""}
    <div class="foot"><button class="btn" data-x>Schliessen</button>${u.available ? `<button class="btn primary" data-u="apply">Jetzt aktualisieren</button>` : ""}</div>`);
  $("#modal").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); if (e.target.closest("[data-u=apply]")) applyUpdate(); };
}
async function checkUpdate(force) {
  try { const u = await api("/api/update/check", { force: !!force }); showUpdate(u); return u; } catch (e) { return null; }
}
async function applyUpdate() {
  openModal(`<h2>Update wird installiert</h2><p class="hint" style="display:flex;gap:10px;align-items:center"><span class="spinner"></span>Neue Version wird heruntergeladen …</p>
    <p class="hint">Der Player schliesst sich gleich und startet von selbst neu – an derselben Stelle.</p>`);
  const playing = P.playing;
  if (P.item) { audio.pause(); await saveProgress(true); }
  try {
    const r = await api("/api/update/apply", { playing });
    if (!r.ok) { openModal(`<h2>Update nicht möglich</h2><p class="hint">${esc(r.error || "Unbekannter Fehler")}</p><div class="foot"><button class="btn" data-x>Schliessen</button></div>`); $("#modal").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); }; return; }
    $("#modal").innerHTML = `<h2>Fast fertig …</h2><p class="hint" style="display:flex;gap:10px;align-items:center"><span class="spinner"></span>Der Player startet in wenigen Sekunden neu.</p>`;
    S.updating = true;
    setTimeout(() => window.close(), 1800);
  } catch (e) { toast("Update fehlgeschlagen: " + e.message, null, null, 8000); closeModal(); }
}

let pendingBusy = false;
async function checkPending() {
  if (pendingBusy) return;
  pendingBusy = true;
  try {
    const d = await api("/api/pending", {});
    if (d.id) {
      if (!S.byId[d.id]) await loadLibrary();
      if (S.sel.size) clearSel();
      await openItem(d.id, true);
    } else if (d.error) toast(d.error, null, null, 7000);
  } catch (e) { }
  pendingBusy = false;
}

async function heartbeat() {
  try {
    const d = await api("/api/heartbeat", {});
    if (d.cloud) showCloud(d.cloud);
    if (d.status && d.status.running && !S.scanning) { setScan(d.status); pollStatus(); }
  } catch (e) { }
}

/* ---------------- Start ---------------- */
async function init() {
  bind();
  const d = await api("/api/init");
  if (d.update) showUpdate(d.update);
  api("/api/cloud").then(showCloud).catch(() => { });
  setTimeout(() => api("/api/update").then(showUpdate).catch(() => { }), 9000);
  S.settings = d.settings; S.dataDir = d.data_dir;
  applyTheme(); syncViewBtn(); syncChips(); renderSpeed(); applyMusicSetting();
  $("#sortSel").value = S.settings.sort || "recent";
  setVolume(S.settings.volume ?? 1);
  await loadLibrary();
  if (d.status.running) pollStatus();
  heartbeat(); setInterval(heartbeat, 15000);
  await checkPending(); setInterval(checkPending, 1500);
  // zuletzt gehörten Titel bereitlegen (ohne abzuspielen)
  const last = S.settings.last_item;
  const tryLast = async () => {
    if (P.item || !last || P.loadingId) return;
    if (S.byId[last]) {
      await openItem(last, !!d.resume_play);
      if (!d.resume_play) { showView("library"); renderLibrary(); }
      else toast(`Aktualisiert auf Version ${window.VERSION}. Es geht weiter, wo du warst.`);
    }
    else if (S.scanning) setTimeout(tryLast, 1500);
  };
  tryLast();
}
init().catch(e => { console.error(e); document.body.insertAdjacentHTML("beforeend", `<div class="toast" style="position:fixed;left:20px;bottom:20px">Fehler beim Start: ${esc(e.message)}</div>`); });
