#!/usr/bin/env bash
# Baut eine neue Version des PC-Players: .exe (mit Versionsnummer) + ZIP in desktop/dist/.
# Aufruf:  desktop/tools/release.sh
# Versionsnummer: desktop/hoerbuch/__init__.py · Änderungen: desktop/CHANGELOG.md
set -euo pipefail
cd "$(dirname "$0")/.."            # = desktop/
DESK=$(pwd)
VER=$(python3 -c "import re;print(re.search(r'VERSION = \"(.+?)\"', open('hoerbuch/__init__.py').read()).group(1))")
C=$(echo "$VER" | tr . ,)
sed -i -E "s/(FILEVERSION|PRODUCTVERSION) [0-9,]+/\1 $C,0/; s/(\"FileVersion\", \")[^\"]+/\1$VER/; s/(\"ProductVersion\", \")[^\"]+/\1$VER/" tools/launcher/launcher.rc
( cd tools/launcher && x86_64-w64-mingw32-windres -c 65001 launcher.rc -O coff -o launcher.res \
  && x86_64-w64-mingw32-gcc -O2 -s -municode -mwindows launcher.c launcher.res -o ../../Hoerbuchplayer.exe 2>/dev/null && rm launcher.res )
STAGE=$(mktemp -d)
mkdir -p "$STAGE/Hoerbuchplayer"
tar --exclude=./dist --exclude=__pycache__ --exclude=.venv --exclude='*.zip' -cf - . | tar -xf - -C "$STAGE/Hoerbuchplayer"
mkdir -p dist
rm -f "dist/Hoerbuchplayer-$VER.zip"
( cd "$STAGE" && zip -qr "$DESK/dist/Hoerbuchplayer-$VER.zip" Hoerbuchplayer )
rm -rf "$STAGE"
awk -v v="## $VER" '$0==v{f=1;next} /^## /{f=0} f' CHANGELOG.md > "dist/notes-$VER.md"
echo "Fertig: desktop/dist/Hoerbuchplayer-$VER.zip"
echo "Release: gh release create v$VER desktop/dist/Hoerbuchplayer-$VER.zip -R thmenet/MyPlayer-releases -t \"Version $VER\" -F desktop/dist/notes-$VER.md"
