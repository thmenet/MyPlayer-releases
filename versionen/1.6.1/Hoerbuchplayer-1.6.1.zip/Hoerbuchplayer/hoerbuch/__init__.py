VERSION = "1.6.1"
APP_NAME = "MyPlayer"
