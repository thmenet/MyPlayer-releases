"""Update-Helfer: wartet, bis der Player beendet ist, ersetzt die Programmdateien und startet neu.

Läuft aus dem entpackten Update-Ordner (nicht aus dem Programmordner), damit alle Dateien
ersetzt werden können. Die Programmumgebung (.venv) und die Daten in %APPDATA% bleiben.
"""
import argparse
import filecmp
import os
import shutil
import subprocess
import sys
import time
import traceback

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
SKIP_DIRS = {".venv", "__pycache__", ".git"}


def log_path():
    base = os.environ.get("HOERBUCH_DATA") or os.environ.get("APPDATA") or os.path.expanduser("~/.config")
    d = os.path.join(base, "Hoerbuchplayer")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "update-protokoll.txt")


def log(msg):
    try:
        with open(log_path(), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except OSError:
        pass


def wait_for_exit(pid, timeout=40):
    if sys.platform == "win32":
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if h:
            k.WaitForSingleObject(h, int(timeout * 1000))
            k.CloseHandle(h)
        time.sleep(0.8)
        return
    end = time.time() + timeout
    while time.time() < end:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.3)


def copy_tree(src, dst):
    for d, dirs, files in os.walk(src):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        rel = os.path.relpath(d, src)
        out = os.path.join(dst, rel) if rel != "." else dst
        os.makedirs(out, exist_ok=True)
        for f in files:
            if f.lower().endswith(".zip"):
                continue
            s, t = os.path.join(d, f), os.path.join(out, f)
            for attempt in range(10):
                try:
                    shutil.copy2(s, t)
                    break
                except OSError:
                    if attempt == 9:
                        raise
                    time.sleep(0.6)


def message(text):
    log(text)
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text, "MyPlayer – Update", 0x40)
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quelle", required=True)
    ap.add_argument("--ziel", required=True)
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--kein-neustart", action="store_true")
    a = ap.parse_args()
    log(f"Update gestartet: {a.quelle} -> {a.ziel}")
    if a.pid:
        wait_for_exit(a.pid)
    copy_tree(a.quelle, a.ziel)
    log("Dateien ersetzt")

    # Pakete nur neu installieren, wenn sich requirements.txt geändert hat
    try:
        req = os.path.join(a.ziel, "requirements.txt")
        marker = os.path.join(a.ziel, ".venv", "requirements.installed")
        py = os.path.join(a.ziel, ".venv", "Scripts", "python.exe")
        if os.path.exists(py) and (not os.path.exists(marker) or not filecmp.cmp(req, marker, shallow=False)):
            log("Installiere Pakete …")
            r = subprocess.run([py, "-m", "pip", "install", "--disable-pip-version-check", "-r", req],
                               capture_output=True, creationflags=NO_WINDOW)
            log(r.stdout.decode("utf-8", "replace")[-1500:] + r.stderr.decode("utf-8", "replace")[-1500:])
            if r.returncode == 0:
                shutil.copy2(req, marker)
    except Exception:
        log("Paket-Installation übersprungen:\n" + traceback.format_exc())

    # Verknüpfungen und «Öffnen mit» auffrischen (z. B. neuer Name «MyPlayer»), nur wenn installiert (Startmenü vorhanden)
    ps1 = os.path.join(a.ziel, "tools", "verknuepfungen.ps1")
    if sys.platform == "win32" and os.path.exists(ps1):
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps1, "-Ziel", a.ziel,
                                "-Desktop", "-1", "-NurWennVorhanden", "1"], capture_output=True, timeout=60, creationflags=NO_WINDOW)
            log("Verknüpfungen: " + (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()[-800:])
        except Exception:
            log("Verknüpfungen nicht aufgefrischt:\n" + traceback.format_exc())

    if a.kein_neustart:
        log("Fertig (ohne Neustart)")
        return
    exe = os.path.join(a.ziel, "Hoerbuchplayer.exe")
    if sys.platform == "win32" and os.path.exists(exe):
        subprocess.Popen([exe, "--nach-update"], cwd=a.ziel)
    else:
        pyw = os.path.join(a.ziel, ".venv", "Scripts", "pythonw.exe")
        subprocess.Popen([pyw if os.path.exists(pyw) else sys.executable, os.path.join(a.ziel, "app.py"), "--nach-update"],
                         cwd=a.ziel, creationflags=NO_WINDOW)
    log("Neu gestartet")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log(traceback.format_exc())
        message("Das Update konnte nicht abgeschlossen werden.\n\n"
                "Bitte die neueste Version von GitHub herunterladen und installieren.bat ausführen.\n"
                "Details: update-protokoll.txt im Daten-Ordner.")
