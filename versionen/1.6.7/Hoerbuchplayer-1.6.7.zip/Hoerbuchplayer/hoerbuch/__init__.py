VERSION = "1.6.7"
APP_NAME = "MyPlayer"
