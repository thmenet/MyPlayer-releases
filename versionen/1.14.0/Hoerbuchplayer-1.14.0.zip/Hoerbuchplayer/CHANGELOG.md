# Änderungen MyPlayer (PC)

## 1.14.0
- **Neu: Genres in Meine Musik.** Reiter «Genres» mit Kacheln (Rock, Pop, Blues, Jazz, Klassik …). Unordentliche Angaben in den Dateien werden zusammengefasst («Classic Rock», «Rock/Pop», alte MP3-Nummern wie «(17)» → Rock). **Weihnachten** erkennt MyPlayer zusätzlich an Titel und Album (Christmas, Jingle Bells, Stille Nacht …).
- Genre-Seite: Alben des Genres, weitere passende Titel aus anderen Alben, «Zufällig abspielen» und «Jukebox: Zufall aus …».
- **Suche findet Genres:** «Weihnachtslieder», «Rocksongs» oder «Blues» zeigen zuoberst das passende Genre.
- **Jukebox: Zufall aus einem Genre** – neben dem Knopf «Zufall» wählen, z. B. nur Weihnachten fürs Fest.
- **Apple Music:** In der Suche stehen Playlists jetzt weiter oben (gut für «Weihnachtslieder», «Blues» …).
- **Tailscale:** Der Heimserver lässt sich über `tailscale serve` mit https und von unterwegs öffnen (Anleitung Schritt 6). Der QR-Code der Jukebox zeigt dabei weiter die Adresse im Heimnetz.

## 1.13.3
- **Apple Music: genauer Grund bei Anmeldefehlern.** Scheitert die Anmeldung, steht jetzt die Meldung von Apple dabei; sie kommt auch ins Protokoll (protokoll.txt), damit wir die Ursache finden.

## 1.13.2
- **Apple Music: Anmelden geht wieder.** Seit dem Start auf «Musik» (1.13.1) wurde Apple Music beim Öffnen mehrmals gleichzeitig eingerichtet; danach scheiterte die Anmeldung («abgebrochen oder fehlgeschlagen»). Jetzt wird es nur einmal eingerichtet.

## 1.13.1
- **Start auf «Musik»:** Beim Öffnen ist zuerst der Reiter «Musik» gewählt (vorher «Hörbücher»). Ist keine Musik eingerichtet, geht es wie bisher bei den Hörbüchern los.

## 1.13.0
- **Jukebox: TV-Ansicht.** Knopf «TV» in der Jukebox: Vollbild mit grossem Cover Flow, «Jetzt läuft», den nächsten Wünschen und einem **QR-Code für Gäste**. Gedacht zum Spiegeln eines iPads oder Macs aufs Apple TV. Der Bildschirm bleibt an; Esc oder ✕ oben rechts beendet die Ansicht.
- **QR-Code / Adresse `/gast`:** Wer den Code mit der Handy-Kamera scannt, ist gleich als «Gast» angemeldet und landet in der Jukebox (nur im WLAN zu Hause).
- **Musik:** Die Reiter «Meine Musik | Apple Music» stehen jetzt gleich neben «Musik» (auf dem Handy schlanker).

## 1.12.0
- **Neu: Jukebox** (ersetzt «Blättern» in Meine Musik). Unter dem Cover stehen die Titel des Albums: antippen = hinten an die gemeinsame Playlist, nochmals antippen = wieder heraus. «Ganzes Album» hängt alle Titel an.
- **Playlist rechts** (auf dem Handy von unten), ein- und ausblendbar: «Jetzt» und «Als Nächstes», mit dem Namen, wer sich den Titel gewünscht hat. Antippen nimmt einen Titel heraus, Antippen aufs kleine Cover blättert zum Album.
- **Zufall** füllt die Playlist selbst nach; Wünsche kommen immer vor den Zufallstiteln dran. Cover Flow blättert bei jedem Titel zum passenden Album.
- **Eine Playlist für das ganze Haus:** Alle Handys und Profile sehen und füllen dieselbe Liste. Läuft die Jukebox auf Sonos, holt der Heimserver selbst den nächsten Titel – auch wenn die Liste leer war und später wieder jemand etwas wünscht.
- **Profil «Gast»** (wird automatisch angelegt): nur Musik und Jukebox, ohne Hörbücher, Podcasts und Einstellungen. Das Handy eines Gastes spielt selbst nichts ab, es wünscht nur.
- **Suche auf dem Handy:** Antippen der Lupe öffnet gleich die Tastatur.

## 1.11.2
- **Blättern: Zufall.** Neuer Knopf «Zufall» unter dem Cover: spielt zufällige Titel aus der ganzen Sammlung. Bei jedem neuen Titel blättert Cover Flow zum Album, aus dem er kommt – auch wenn die Musik auf Sonos läuft.

## 1.11.1
- **Album-Ansicht bei Sonos:** Die Markierung ▶ in der Titelliste zeigt jetzt den Titel, den die Sonos-Box gerade spielt (vorher blieb sie beim Titel stehen, mit dem die Wiedergabe gestartet wurde).
- **Handy:** Die Seite zoomt nicht mehr ungewollt hinein (z. B. beim Antippen der Suche) und startet nicht mehr zu gross.

## 1.11.0
- **Sonos: Boxen kombinieren.** In der Lautsprecher-Auswahl gibt es während der Wiedergabe den Abschnitt «Mitspielen lassen»: Mit dem Schalter spielt ein weiterer Raum gleichzeitig dasselbe (Sonos-Gruppe), Schalter aus nimmt ihn wieder heraus. Die Leiste zeigt z. B. «Wohnzimmer + Küche», die Lautstärke gilt für die ganze Gruppe.
- **Meine Musik: Blättern.** Neue Ansicht neben Alben/Interpreten/Neu: Die Alben stehen wie Platten im Regal, das gewählte Cover gross in der Mitte. Blättern mit den Pfeiltasten, dem Mausrad, durch Ziehen/Wischen, mit dem Regler darunter oder durch Klick auf ein Nachbar-Cover. Klick auf das Cover in der Mitte (oder Enter) öffnet das Album, «Abspielen» spielt es gleich ab.

## 1.10.0
- **Neu: Sonos (Heimserver).** Knopf «Lautsprecher» (im Player, in der Leiste unten bei Hörbuch und Musik): Hörbuch oder «Meine Musik» auf einen Sonos-Raum oder eine Gruppe schicken – es geht an der gleichen Stelle weiter. Die Box holt den Ton direkt vom Heimserver; Handy oder PC sind nur Fernbedienung und dürfen danach aus sein.
- **Sonos-Leiste** unten: Titel bzw. Kapitel, Fortschritt zum Ziehen, ±30 s bzw. Titel zurück/vor, Play/Pause, **Lautstärke**, Raum wechseln. Auch im Mini-Player und mit den Medientasten.
- Beim Hörbuch speichert der Heimserver den Hörstand laufend für dein Profil. «Dieses Gerät» holt die Wiedergabe an der aktuellen Stelle zurück; startest du hier etwas, endet die Wiedergabe auf Sonos.
- Wählt jemand in der Sonos-App etwas anderes, gibt MyPlayer die Box still frei.
- Meine Musik: MP3-Dateien mit zwei Infoblöcken (ID3 2.3 + 2.2) werden gelesen.

## 1.9.2
- **Meine Musik liest mehr Dateien:** FLAC-Dateien mit einem vorne angehängten MP3-Infoblock (kommt bei manchen Rip-Programmen vor) wurden übersprungen – jetzt werden sie gelesen; wenn der schnelle Weg nicht klappt, gibt es einen gründlicheren Ausweichweg. Leere oder beschädigte Dateien werden ausgelassen.

## 1.9.1
- **Meine Musik: Doppel-CDs mit der CD-Nummer im Albumtitel** («AC/DC Live, Disc 1» / «AC-DC Live, Disc 2») erscheinen jetzt als ein Album mit CD 1 und CD 2 – auch wenn die CDs in eigenen Ordnern liegen oder leicht verschieden geschrieben sind.

## 1.9.0
- **Neu: «Meine Musik».** Die eigene Musiksammlung (FLAC, MP3 …) unter Musik – neben Apple Music, umschaltbar. Alben, Interpreten und «Neu» als Kacheln mit Cover, Album-Ansicht mit allen Titeln (auch Doppel-CDs), Suche nach Titel, Album und Interpret, «Zufallsmix», Abspielen, Zufällig. Musik-Ordner in den Einstellungen (Heimserver: `/mnt/musik`).
- Musik läuft unten in der Leiste mit Zurück / Pause / Weiter und Fortschritt zum Ziehen, im Mini-Player und mit den Medientasten. Hörbuch, Apple Music und eigene Musik halten sich gegenseitig an.
- Schnelles Einlesen auch bei zehntausenden FLAC-Dateien über das Netz (nur der Dateikopf wird gelesen), danach nur noch neue Alben; alle 6 Stunden von selbst. Synology-Papierkorb und Hilfsordner werden übersprungen.
- **Heimserver auf dem Handy:** gleiche Bedienung wie player.menet.ch (Kopfzeile mit Symbolen, Suche aufklappen, Kapitel als Blatt von unten).

## 1.8.0
- **Neu: MyPlayer als Heimserver.** Derselbe Player läuft auf Wunsch ohne Fenster dauernd im Heimnetz (z. B. in einem Proxmox-Container) und liest die Hörbücher vom NAS. Alle Geräte zuhause öffnen ihn im Browser. Anleitung und Installations-Skript im Ordner `heimserver`.
- **Profile «Wer hört?»** (nur Heimserver): jede Person hat ihren eigenen Hörstand, ihre Lesezeichen, Einstellungen und ihr eigenes Konto bei player.menet.ch. Bibliotheksordner gelten für alle.
- Am PC ändert sich nichts.

## 1.7.1
- **Reiter neu geordnet:** Musik, Hörbücher, Podcasts – «Alle» ist weg. (Musik erscheint nur, wenn in den Einstellungen eingeschaltet.)

## 1.7.0
- **Eigenes Mini-Fenster «MyPlayer (mini)»:** Der Mini-Player ist jetzt ein eigenes kleines Fenster mit MyPlayer-Logo und Titel in der Titelleiste (statt der Adresse 127.0.0.1). Kompakter, immer im Vordergrund, unten rechts über der Taskleiste. Abgespielt wird weiter im grossen Fenster (das in die Taskleiste geht) – das kleine steuert es fern. Schliesst du das Mini-Fenster oder klickst ⤢, kommt das grosse zurück; schliesst du das grosse, geht das kleine mit.

## 1.6.9
- **Mini-Player in der richtigen Grösse:** Edge öffnete ihn gleich gross wie das Hauptfenster. Jetzt bringt der Player ihn auf seine kleine Grösse und setzt ihn unten rechts über die Taskleiste.
- **Nach einem Update weiterspielen – jetzt auch Apple Music:** Lief beim Update Musik, geht es nach dem Neustart mit derselben Playlist bzw. demselben Album beim gleichen Titel und an der gleichen Stelle weiter (beim Hörbuch war das schon so).

## 1.6.8
- **Mini-Player:** Neuer Knopf oben (neben Hell/Dunkel) öffnet ein kleines Fenster, das immer im Vordergrund bleibt – mit Cover, Titel, Fortschritt zum Ziehen und Zurück / Play / Vor, für Hörbuch und Apple Music. Leertaste und Pfeiltasten funktionieren darin. Am PC geht das grosse Fenster dabei in die Taskleiste; der Knopf ⤢ oder das Schliessen des Mini-Players holt es zurück. (Im Web nur in Chrome/Edge am Computer.)

## 1.6.7
- **Podcasts: älteste Folge zuerst** – Folge 1 steht oben. Innerhalb eines Jahres nach Titel, Zahlen in der richtigen Reihenfolge (#2 vor #10, Episode 133 vor 135).
- **Zertifikat von player.menet.ch ist da:** Die vorübergehende Ausnahme für das green.ch-Zertifikat ist entfernt, die Verbindung wird wieder ganz normal geprüft.

## 1.6.6
- **Das Programm heisst jetzt auch als Datei «MyPlayer.exe»** (bisher «Hoerbuchplayer.exe»). Beim Update werden Startmenü, Desktop-Verknüpfung, an die Taskleiste angeheftete Verknüpfungen und «Öffnen mit» für .m4b automatisch umgestellt; die alte Datei wird entfernt. Der Programmordner und deine Daten bleiben, wo sie sind.

## 1.6.5
- **Fortschritt unten zum Ziehen:** Den Balken über der Leiste unten kannst du mit der Maus (oder dem Finger) ziehen oder anklicken – bei Musik und Hörbuch. Beim Darüberfahren wird er dicker und zeigt einen Knopf.

## 1.6.4
- **Musik in der Leiste unten:** Läuft Apple Music, zeigt der Abspielbalken unten Cover, Titel und Interpret mit Zurück / Pause / Weiter und der Zeit. Startest du ein Hörbuch, zeigt er wieder das Hörbuch. Ein Klick auf den Titel führt zur Musik.
- **Behoben: Fenster «undefined» und langes Warten beim Starten eines Liedes.** Der Player schickte «Abspielen» doppelt an Apple. Apples eigene Fehlerfenster sind aus; stattdessen erscheint eine verständliche Meldung.

## 1.6.3
- **Musik: klarere Fehlermeldung und «Nochmals versuchen»:** Statt «Failed to fetch» steht jetzt, welche Verbindung fehlt (Player, player.menet.ch oder Apple). Mit dem Knopf «Nochmals versuchen» lädt die Seite neu, ohne den Player neu zu starten.

## 1.6.2
- **Musik lädt viel schneller:** Zuerst erscheint, was schnell da ist (Zuletzt gehört, Playlists), die Alben kommen nach und werden gleichzeitig statt nacheinander geladen. Beim nächsten Öffnen steht der letzte Stand sofort da und wird im Hintergrund aufgefrischt.
- **Cover für eigene Playlists:** Playlists ohne eigenes Bild zeigen ein Mosaik aus vier Covern ihrer Lieder (wie in Apple Music).

## 1.6.1
- **Playlists und Alben aufklappen:** Ein Klick öffnet die Playlist bzw. das Album mit allen Titeln in der richtigen Reihenfolge. Ein Klick auf einen Titel spielt ab dort; dazu «Abspielen» und «Zufällig». Der laufende Titel ist markiert.
- **Interpreten** öffnen sich mit Top-Titeln und Alben.
- **Zur Mediathek hinzufügen** für Alben und Playlists aus der Suche.
- Startseite «Musik» mit Kacheln: Zuletzt gehört, Meine Playlists, Neu in der Mediathek, Meine Alben (alphabetisch).
- Behoben: «Zuletzt gehört» blieb leer (Apple erlaubt dort höchstens 10 Einträge).

## 1.6.0
- **Musik (Apple Music):** In den Einstellungen «Musik anzeigen» einschalten – dann gibt es oben den Bereich «Musik». Einmal mit der Apple-ID anmelden (Apple-Music-Abo nötig), danach: zuletzt Gehörtes, eigene Playlists und Suche in ganz Apple Music. Braucht die Verbindung zu player.menet.ch.
- Musik und Hörbuch laufen nie gleichzeitig: Startet das eine, hält das andere an.

## 1.5.0
- **Neuer Name: MyPlayer.** Fenster, Startmenü, Desktop-Verknüpfung und «Öffnen mit» heissen jetzt «MyPlayer». Die Verknüpfungen werden beim Update selbst umbenannt.
- **Handy-Bedienung auch hier:** Auf Touch-Bildschirmen öffnet Antippen den Titel, lange drücken wählt aus.

## 1.4.3
- **Verbinden mit player.menet.ch, solange green.ch das richtige Zertifikat noch nicht eingespielt hat:** Der Player akzeptiert vorübergehend nur für player.menet.ch das Zertifikat von green.ch («*.servicehoster.ch»). Die Echtheit wird weiterhin geprüft. In den Einstellungen steht dann ein Hinweis; sobald das richtige Zertifikat da ist, wird wieder normal geprüft.

## 1.4.2
- **Verbinden mit player.menet.ch klappt auch, wenn Windows das neue Sicherheitszertifikat noch nicht kennt** (zusätzliche Zertifikatsliste «certifi»).
- Bei Verbindungsproblemen steht jetzt der genaue Grund in der Meldung.

## 1.4.1
- **Verständliche Fehlermeldungen** beim Verbinden mit player.menet.ch (statt nur einer Nummer wie «400»).

## 1.4.0
- **Verbindung zu player.menet.ch:** In den Einstellungen mit einem Code verbinden (Code auf player.menet.ch → Geräte).
- **Hochladen fürs Handy:** Rechtsklick auf einen oder mehrere Titel → «Auf player.menet.ch hochladen». Läuft im Hintergrund, setzt nach einem Abbruch fort.
- **Gemeinsamer Hörstand:** Position, Lesezeichen, Favoriten und Archiv werden mit player.menet.ch abgeglichen – am PC geht es dort weiter, wo du im Auto aufgehört hast.
- Titel auf dem Server tragen ein Wolken-Zeichen.

## 1.3.0
- **Automatische Updates:** Der Player schaut beim Start auf GitHub nach einer neuen Version und kann sich mit einem Klick selbst aktualisieren. Danach geht es an derselben Stelle weiter.
- In den Einstellungen: **Nach Updates suchen**.

## 1.2.0
- **Mehrfachauswahl:** mehrere Titel auf einmal als Podcast/Hörbuch markieren, zu Favoriten, ins Archiv.
- **Installation** mit Eintrag im Startmenü (`installieren.bat`) und eigener `Hoerbuchplayer.exe`.
- **Standard-Player für .m4b:** Doppelklick auf eine .m4b-Datei öffnet sie im Player.

## 1.1.0
- Podcasts nach Sendung gruppiert und **auf-/zuklappbar**, Knopf «Weiterhören».
- Folgen nach Folgennummer sortiert.

## 1.0.0
- Erste Version: Bibliothek, Player mit Kapiteln, Lesezeichen, Favoriten, Archiv, Schlaf-Timer.
