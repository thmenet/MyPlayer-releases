VERSION = "1.14.0"
APP_NAME = "MyPlayer"
