VERSION = "1.13.2"
APP_NAME = "MyPlayer"
