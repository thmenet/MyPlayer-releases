VERSION = "1.16.1"
APP_NAME = "MyPlayer"
