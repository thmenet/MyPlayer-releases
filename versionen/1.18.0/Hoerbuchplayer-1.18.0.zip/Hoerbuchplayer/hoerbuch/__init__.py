VERSION = "1.18.0"
APP_NAME = "MyPlayer"
