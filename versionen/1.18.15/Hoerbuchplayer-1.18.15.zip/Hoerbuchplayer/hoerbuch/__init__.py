VERSION = "1.18.15"
APP_NAME = "MyPlayer"
